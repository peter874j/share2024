# MinIO 建置完整文件  
> 適用於 **Windows 單機開發測試** 與 **Linux 分散式正式環境**  
> 固定端口：  
> - **9000**：物件儲存服務 (S3 API)  
> - **9005**：Web 管理後台

---

## **一、MinIO 介紹**
MinIO 是一個高效能、S3 API 相容的**分散式物件儲存系統**，適用於儲存非結構化資料（圖片、影片、備份檔、大數據等）。  
- **授權**：Apache License 2.0  
- **特性**：
  - 跨平台（Windows / Linux / macOS）
  - 單檔上限 5TB
  - 支援 Java / Python / Go / .NET 等 SDK
  - 兼容 AWS S3 API
  - 支援本地與雲端部署
  - 採用糾刪碼（Erasure Coding）保障資料安全性  

---

## **二、單機部署（Windows 測試環境）**
適用於本地開發測試、PoC 驗證或個人檔案伺服器。

### 1. 下載 MinIO
下載 **Server**（`minio.exe`）與 **Client**（`mc.exe`）：  
- 官方下載頁：  
  [https://minio.org.cn/download.shtml#/windows](https://minio.org.cn/download.shtml#/windows)

### 2. 建立目錄結構
假設根目錄為 `E:\minio`
```
E:\minio
 ├─ bin      （放 minio.exe, mc.exe）
 ├─ data     （存放物件資料）
 └─ logs     （存放日誌）
```

### 3. 設定環境變數（CMD）
以 **系統管理員**身份打開命令提示字元：
```cmd
setx MINIO_ROOT_USER auo
setx MINIO_ROOT_PASSWORD auo11111
```
> **帳號限制**：使用者名稱 ≥ 3 字元，密碼 ≥ 8 字元

### 4. 啟動 MinIO 服務
進入 `bin` 目錄並執行：
```cmd
minio.exe server E:\minio\data --console-address "127.0.0.1:9005" --address "127.0.0.1:9000"
```

### 5. 透過批次檔啟動（推薦）
建立 `start_minio.bat`
```bat
@echo off
set MINIO_ROOT_USER=auo
set MINIO_ROOT_PASSWORD=auo11111
.\minio.exe server E:\minio\data --console-address "127.0.0.1:9005" --address "127.0.0.1:9000" > E:\minio\logs\minio.log 2>&1
```
雙擊執行即可啟動

### 6. 存取 MinIO
- **服務端點**（S3 API）：`http://127.0.0.1:9000`
- **WebUI 管理後台**：`http://127.0.0.1:9005`  
帳號密碼為剛設定的 `MINIO_ROOT_USER` / `MINIO_ROOT_PASSWORD`

---

## **三、分散式部署（Linux 正式環境）**
正式環境建議至少 4 台 Linux 機器、每台掛載多顆硬碟（JBOD），並使用 xfs 檔案系統。

### 1. 環境建議
- **硬體一致性**：相同的 CPU、RAM、主機板、儲存設備
- **作業系統**：建議 AlmaLinux / CentOS / Ubuntu LTS
- **網路**：所有節點互通，時間同步（chronyd）
- **防火牆**：開放 TCP `9000`、`9005`

### 2. 範例節點規劃
| 節點  | IP             | 主機名稱 |
|-------|---------------|----------|
| 節點1 | 192.168.88.81 | minio1   |
| 節點2 | 192.168.88.53 | minio2   |
| 節點3 | 192.168.88.79 | minio3   |

每台機器掛載 4 顆硬碟：
```
/opt/minio/data/export1
/opt/minio/data/export2
/opt/minio/data/export3
/opt/minio/data/export4
```

---

### 3. 格式化與掛載硬碟
建立初始化腳本 `init.sh`：
```bash
#!/bin/bash
ROOT_FOLDER="/opt/minio"

mkdir -p ${ROOT_FOLDER}/data/export{1..4}

mkfs.xfs /dev/vdb -L DRIVE1
mkfs.xfs /dev/vdc -L DRIVE2
mkfs.xfs /dev/vdd -L DRIVE3
mkfs.xfs /dev/vde -L DRIVE4

mount /dev/vdb ${ROOT_FOLDER}/data/export1
mount /dev/vdc ${ROOT_FOLDER}/data/export2
mount /dev/vdd ${ROOT_FOLDER}/data/export3
mount /dev/vde ${ROOT_FOLDER}/data/export4
```

將掛載資訊寫入 `/etc/fstab`：
```
LABEL=DRIVE1 /opt/minio/data/export1 xfs defaults,noatime 0 2
LABEL=DRIVE2 /opt/minio/data/export2 xfs defaults,noatime 0 2
LABEL=DRIVE3 /opt/minio/data/export3 xfs defaults,noatime 0 2
LABEL=DRIVE4 /opt/minio/data/export4 xfs defaults,noatime 0 2
```

---

### 4. 調整系統限制
```bash
# /etc/security/limits.conf
* soft nofile 524288
* hard nofile 524288

# /etc/systemd/system.conf
DefaultLimitNOFILE=524288:524288

# /etc/systemd/user.conf
DefaultLimitNOFILE=524288:524288
```
然後重啟
```bash
reboot
```

---

### 5. 安裝 MinIO 伺服器
```bash
cd /opt/minio
wget https://dl.min.io/server/minio/release/linux-amd64/archive/minio.RELEASE.2023-07-21T21-12-44Z
mv minio.RELEASE.2023-07-21T21-12-44Z minio
chmod +x minio
mv minio /usr/local/bin/
```

---

### 6. 建立 MinIO 用戶與權限
```bash
groupadd -r minio-user
useradd -M -r -g minio-user minio-user
chown minio-user:minio-user /opt/minio/data/export{1..4}
```

---

### 7. 設定環境變數檔案 `/etc/default/minio`
```bash
MINIO_VOLUMES="http://minio{1...3}:9000/opt/minio/data/export{1...4}/minio"
MINIO_OPTS="--console-address :9005"
MINIO_ROOT_USER=minioadmin
MINIO_ROOT_PASSWORD=minio-secret-key
```

---

### 8. 建立 systemd 服務 `/usr/lib/systemd/system/minio.service`
```ini
[Unit]
Description=MinIO
After=network-online.target
Wants=network-online.target

[Service]
User=minio-user
Group=minio-user
EnvironmentFile=-/etc/default/minio
ExecStart=/usr/local/bin/minio server $MINIO_OPTS $MINIO_VOLUMES
Restart=always
LimitNOFILE=65536
TasksMax=infinity
TimeoutStopSec=infinity
SendSIGKILL=no

[Install]
WantedBy=multi-user.target
```

啟用與啟動：
```bash
systemctl enable minio
systemctl start minio
```

---

### 9. 存取 MinIO 集群
在瀏覽器輸入任一節點 IP：
- **S3 API** 端點：`http://<任一節點IP>:9000`
- **Web 後台**：`http://<任一節點IP>:9005`  
使用 `/etc/default/minio` 中設定的帳密登入。

---

## **四、MinIO 基本操作**
登入 WebUI →  
1. **建立 Bucket**（名稱只能小寫）  
2. **設定權限**：可將 bucket 設為 `public` 讓外部讀取  
3. **上傳檔案** → 透過右上角 `Upload`  
4. **預覽/下載** → 點擊檔案查看詳細資訊

---

## **五、最佳實務**
- **正式環境**：  
  - 至少 **4 節點**，每節點相同硬體  
  - 使用 **XFS** 檔案系統  
  - 資料磁碟與作業系統磁碟分離
- **備援策略**：即使部分節點故障，只要有 N/2 磁碟在線可讀，N/2+1 可寫
- **安全性**：  
  - 使用反向代理（Nginx/HAProxy）與 SSL  
  - 管理帳密務必加長且複雜
- **監控**：整合 Prometheus + Grafana 監控 I/O 與容量  
- **備份**：定期透過 `mc mirror` 或原生 `minio gateway` 備份到異地  