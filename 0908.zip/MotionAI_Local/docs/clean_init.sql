﻿None
BEGIN;

CREATE TABLE alembic_version (
    version_num VARCHAR(32) NOT NULL, 
    CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
);

-- Running upgrade  -> a7fbda5970f2

CREATE TABLE fab (
    id SERIAL NOT NULL, 
    name VARCHAR NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    deleted_at TIMESTAMP WITH TIME ZONE, 
    PRIMARY KEY (id)
);

CREATE TABLE "user" (
    id VARCHAR NOT NULL, 
    username VARCHAR NOT NULL, 
    fullname VARCHAR NOT NULL, 
    email VARCHAR NOT NULL, 
    deptno VARCHAR NOT NULL, 
    location VARCHAR, 
    token VARCHAR, 
    role VARCHAR DEFAULT 'user' NOT NULL, 
    access_key VARCHAR, 
    secret_key VARCHAR, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    PRIMARY KEY (id), 
    UNIQUE (email)
);

CREATE TABLE department (
    id SERIAL NOT NULL, 
    name VARCHAR NOT NULL, 
    fab_id INTEGER NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    deleted_at TIMESTAMP WITH TIME ZONE, 
    PRIMARY KEY (id), 
    FOREIGN KEY(fab_id) REFERENCES fab (id)
);

CREATE TABLE server (
    id SERIAL NOT NULL, 
    name VARCHAR NOT NULL, 
    ip VARCHAR NOT NULL, 
    description VARCHAR NOT NULL, 
    status BOOLEAN NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    deleted_at TIMESTAMP WITH TIME ZONE, 
    fab_id INTEGER NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(fab_id) REFERENCES fab (id)
);

CREATE TABLE cam (
    id SERIAL NOT NULL, 
    name VARCHAR NOT NULL, 
    ip VARCHAR NOT NULL, 
    port VARCHAR NOT NULL, 
    status BOOLEAN NOT NULL, 
    import_status BOOLEAN DEFAULT false NOT NULL, 
    data JSONB, 
    stream_pre_uri VARCHAR NOT NULL, 
    stream_det_uri VARCHAR NOT NULL, 
    obj_name_uri VARCHAR NOT NULL, 
    config_uri VARCHAR NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    deleted_at TIMESTAMP WITH TIME ZONE, 
    server_id INTEGER NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(server_id) REFERENCES server (id)
);

CREATE TABLE stage (
    id SERIAL NOT NULL, 
    name VARCHAR NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    deleted_at TIMESTAMP WITH TIME ZONE, 
    fab_id INTEGER NOT NULL, 
    department_id INTEGER NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(department_id) REFERENCES department (id), 
    FOREIGN KEY(fab_id) REFERENCES fab (id)
);

CREATE TABLE unit (
    id SERIAL NOT NULL, 
    name VARCHAR NOT NULL, 
    import_status VARCHAR DEFAULT 'undo' NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    deleted_at TIMESTAMP WITH TIME ZONE, 
    stage_id INTEGER NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(stage_id) REFERENCES stage (id)
);

CREATE TABLE fences (
    id SERIAL NOT NULL, 
    name VARCHAR NOT NULL, 
    drawn_area JSONB NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    deleted_at TIMESTAMP WITH TIME ZONE, 
    unit_id INTEGER NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(unit_id) REFERENCES unit (id)
);

CREATE TABLE logics (
    id SERIAL NOT NULL, 
    state VARCHAR NOT NULL, 
    name VARCHAR, 
    mode VARCHAR, 
    expression TEXT, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    deleted_at TIMESTAMP WITH TIME ZONE, 
    unit_id INTEGER NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(unit_id) REFERENCES unit (id)
);

CREATE TABLE objects (
    id SERIAL NOT NULL, 
    name VARCHAR NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    deleted_at TIMESTAMP WITH TIME ZONE, 
    unit_id INTEGER, 
    PRIMARY KEY (id), 
    FOREIGN KEY(unit_id) REFERENCES unit (id)
);

CREATE TABLE report (
    id SERIAL NOT NULL, 
    data JSONB, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    unit_id INTEGER NOT NULL, 
    source VARCHAR DEFAULT 'webhook' NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(unit_id) REFERENCES unit (id)
);

CREATE TABLE unit_cam (
    id SERIAL NOT NULL, 
    unit_id INTEGER NOT NULL, 
    cam_id INTEGER NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    deleted_at TIMESTAMP WITH TIME ZONE, 
    PRIMARY KEY (id), 
    FOREIGN KEY(cam_id) REFERENCES cam (id), 
    FOREIGN KEY(unit_id) REFERENCES unit (id), 
    UNIQUE (cam_id), 
    CONSTRAINT uq_unit_cam_cam_id UNIQUE (cam_id)
);

CREATE TABLE conditions (
    id SERIAL NOT NULL, 
    type VARCHAR NOT NULL, 
    name VARCHAR NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    deleted_at TIMESTAMP WITH TIME ZONE, 
    unit_id INTEGER NOT NULL, 
    fence_id INTEGER, 
    PRIMARY KEY (id), 
    FOREIGN KEY(fence_id) REFERENCES fences (id), 
    FOREIGN KEY(unit_id) REFERENCES unit (id)
);

CREATE TABLE report_item (
    id SERIAL NOT NULL, 
    cycle_count INTEGER, 
    cycle_start_time TIMESTAMP WITH TIME ZONE, 
    work_id VARCHAR, 
    extra_data JSONB, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
    report_id INTEGER NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(report_id) REFERENCES report (id) ON DELETE CASCADE
);

CREATE INDEX idx_reportitem_report_time ON report_item (report_id, cycle_start_time);

CREATE INDEX idx_reportitem_time_report ON report_item (cycle_start_time, report_id);

CREATE INDEX ix_report_item_cycle_start_time ON report_item (cycle_start_time);

CREATE INDEX ix_report_item_work_id ON report_item (work_id);

CREATE TABLE condition_object (
    id SERIAL NOT NULL, 
    object_id INTEGER NOT NULL, 
    condition_id INTEGER NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(condition_id) REFERENCES conditions (id), 
    FOREIGN KEY(object_id) REFERENCES objects (id), 
    CONSTRAINT uix_object_condition UNIQUE (object_id, condition_id)
);

INSERT INTO alembic_version (version_num) VALUES ('a7fbda5970f2') RETURNING alembic_version.version_num;

COMMIT;

