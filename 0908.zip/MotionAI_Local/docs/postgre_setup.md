# PostgreSQL 建置與使用完整指南（Windows 10/11 64位）

> 本指南整合了 **PostgreSQL 15.8 與 17** 在 **Windows 系統** 上的安裝、環境設定、指令教學與常見問題，涵蓋從下載到使用的完整流程。  

---

## 1️⃣ PostgreSQL 介紹

**PostgreSQL** 是一款 **開源的物件關聯式資料庫管理系統（ORDBMS）**，以高擴展性、穩定性與標準 SQL 支援聞名。

**主要特性：**
- 支援標準 SQL 及進階功能（視圖、觸發器、外鍵、事務控制、MVCC 多版本並發控制）
- 支援多種資料類型（JSONB、數組、UUID、GIS 類型等）
- 擴展性高，可自行撰寫函數或安裝外掛（如 PostGIS、TimescaleDB）

---

## 2️⃣ 下載與安裝

### 2.1 下載

- [PostgreSQL 官方下載頁](https://www.postgresql.org/download/windows/)
- [EDB 下載頁](https://www.enterprisedb.com/downloads/postgres-postgresql-downloads)

挑選 **Windows x86-64** 安裝程式版本（通常建議最新版，這裡示例以 **15.8** / **17** 為主）。

---

### 2.2 安裝流程（保姆級步驟）

1. **執行下載好的 `.exe` 安裝檔**  

2. **Next**

3. **選擇安裝路徑**（建議非 C 槽）

4. **全選元件**
   - PostgreSQL Server
   - pgAdmin 4（圖形化管理工具）
   - Stack Builder（附加套件管理）

5. **設定資料目錄**（預設會在安裝目錄下建立 `data` 資料夾）

6. **設定 `postgres` 帳戶密碼**（請牢記）

7. **設定 Port（預設 5432）**

8. **語言**（建議 English，避免部分模組中文化錯誤）

9. **確認資訊 → Install**

10. 安裝完成 → **取消勾選 Stack Builder（可之後再用）**  

---

## 3️⃣ 環境變數設定（方便命令列使用）

1. 取得 PostgreSQL **bin** 目錄路徑，例如：
   ```
   D:\PostgreSQL\15\bin
   ```
2. **在 Windows 搜尋 → 高級系統設定 → 環境變數**
3. 編輯 `Path` → 新增該 bin 路徑
4. 可選：新增 `PGHOME`（值為 PostgreSQL 安裝路徑）

驗證：
```powershell
psql --version
```

---

## 4️⃣ PostgreSQL 基本使用

### 4.1 啟動 / 停止服務
```powershell
services.msc   # 在服務中找到 PostgreSQL，啟動或停止
```
或
```powershell
pg_ctl start   -D "資料目錄路徑"
pg_ctl stop    -D "資料目錄路徑"
```

---

### 4.2 連線資料庫
```powershell
psql -U postgres -p 5432
```
常用 psql 命令：
| 命令 | 說明 |
|------|------|
| `\l` | 列出所有資料庫 |
| `\c dbname` | 切換資料庫 |
| `\dt` | 列出所有表格 |
| `\d tablename` | 查看表結構 |
| `\q` | 離開 psql |

---

### 4.3 基本 SQL 操作（CRUD）

```sql
-- 建表
CREATE SEQUENCE users_id_seq;
CREATE TABLE users (
  id INT DEFAULT nextval('users_id_seq'),
  name VARCHAR(100),
  age INT,
  email VARCHAR(255)
);

-- C：新增
INSERT INTO users (name, age, email)
VALUES ('John Doe', 30, 'johndoe@example.com');

-- R：查詢
SELECT * FROM users;
SELECT name, email FROM users WHERE age > 25 ORDER BY age DESC;

-- U：更新
UPDATE users SET age = 31 WHERE name = 'John Doe';

-- D：刪除
DELETE FROM users WHERE name = 'John Doe';
```

---

## 5️⃣ pgAdmin 圖形化管理

1. 開啟 pgAdmin 4
2. `Servers` → `Add New Server`
3. 填寫：
   - Host: `localhost`
   - User: `postgres`
   - Password: 安裝時設定的密碼
4. 建立資料庫 → Create → Database
5. 在 `Query Tool` 輸入 SQL，使用 F5 執行

---

## 6️⃣ Python 連接 PostgreSQL

需安裝套件：
```bash
pip install psycopg2
```

範例程式：
```python
import psycopg2

conn = psycopg2.connect(
    host="localhost",
    port=5432,
    dbname="postgres",
    user="postgres",
    password="root"  # 改為你的密碼
)

cur = conn.cursor()

cur.execute("SELECT * FROM users;")
print(cur.fetchall())

# 新增資料
cur.execute("INSERT INTO users (name, age) VALUES (%s, %s)", ("Charlie", 28))
conn.commit()

cur.close()
conn.close()
```

---

## 7️⃣ 備份與還原

### 備份單一資料庫
```bash
pg_dump -U postgres -d mydb > mydb.sql
```

### 還原
```bash
psql -U postgres -d newdb -f mydb.sql
```

---

## 8️⃣ 常見問題

| 問題 | 解決方式 |
|------|----------|
| 安裝後沒有 PostgreSQL 服務 | 重新安裝，確保安裝過程無誤 |
| 連線失敗（本地） | 驗證服務是否啟動、防火牆設定、帳密是否正確 |
| 中文語系錯誤 | 安裝時選擇 English 語系 |
| Port 被占用 | 修改 `postgresql.conf` 中的 `port` 參數 |

---

## 9️⃣ PostgreSQL vs MySQL（簡要對照）

| 特性 | PostgreSQL | MySQL |
|------|------------|-------|
| 目標 | 標準相容 & 擴展性 | 簡單 & 效率 |
| 資料型態 | 豐富（JSONB、GIS、自定義型態） | 基礎類型 |
| 複雜查詢 | 強 | 較弱（8.0+ 加強） |
| 並發控制 | MVCC，高效 | 行鎖，效能較低 |
| 擴展功能 | 多（PostGIS, TimescaleDB） | 較少 |
| 預設隔離層級 | Read Committed | Repeatable Read |

---

## 🔟 事務（Transaction）基礎

**ACID 特性：**
- **A** 原子性
- **C** 一致性
- **I** 隔離性
- **D** 持久性

```sql
BEGIN;
UPDATE accounts SET balance = balance - 100 WHERE id = 1;
UPDATE accounts SET balance = balance + 100 WHERE id = 2;
COMMIT;
-- ROLLBACK; 可回滾
```
