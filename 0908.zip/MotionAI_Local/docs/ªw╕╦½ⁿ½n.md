# 📌 作業觀察平台-本地版 — 安裝與配置指南

本指南將本地服務建置流程分為 **MinIO → PostgreSQL → 資料初始化 → 關鍵資料新增 → 服務啟動** 五大步驟，確保在 Windows 環境中可順利運行。

---

## 1️⃣ MinIO 環境建置
依照 [docs/minio_setup.md](docs/minio_setup.md) 指示：

1. **下載必要檔案**  
   - `minio.exe`（Server）  
   - `mc.exe`（Client）

2. **建立目錄結構**（範例路徑）  
   ```
   E:\minio\bin
   E:\minio\data
   E:\minio\logs
   ```

3. **設定環境變數**（CMD）：  
   ```cmd
   setx MINIO_ROOT_USER auo
   setx MINIO_ROOT_PASSWORD auo11111
   ```

4. **啟動服務**：  
   ```cmd
   minio.exe server E:\minio\data --console-address "127.0.0.1:9005" --address "127.0.0.1:9000"
   ```

5. **批次檔啟動（可選）** → 建立 `start_minio.bat`：  
   ```bat
   @echo off
   set MINIO_ROOT_USER=auo
   set MINIO_ROOT_PASSWORD=auo11111
   .\minio.exe server E:\minio\data --console-address "127.0.0.1:9005" --address "127.0.0.1:9000" > E:\minio\logs\minio.log 2>&1
   ```

---

## 2️⃣ PostgreSQL 環境建置
依照 [docs/postgre_setup.md](docs/postgre_setup.md) 指南（推薦 **v15.8** 或 **v17**）：

1. **下載與安裝**（Windows x64 版本），記錄安裝時設定的 `postgres` 管理員密碼。  
2. 將 **PostgreSQL bin 路徑** 新增至系統 PATH：  
   ```
   D:\PostgreSQL\<version>\bin
   ```
3. 驗證環境 (需 16.2+)：  
   ```powershell
   psql --version
   ```

---

## 3️⃣ 建立專案資料庫並初始化資料表

1. **建立資料庫**：
   ```sql
   CREATE DATABASE opsview;
   ```
2. **匯入初始化 SQL**（於 `opsview` 資料庫中執行）：  
   ```bash
   psql -U postgres -d opsview -f docs/clean_init.sql
   ```

---

## 4️⃣ 新增 Super Admin 使用者

1. 參考 [src/database/models/user.py](src/database/models/user.py) 欄位定義。  
2. 使用以下範例 SQL 新增帳號：  

```sql
INSERT INTO public."user" (
    id, username, fullname, email, deptno, token, role, access_key, secret_key, location
) VALUES (
    9999999,
    'admin',
    '超級管理員',
    'admin@auo.com',
    'MAMCC1',
    NULL,
    'super_admin',
    NULL,
    NULL,
    'L8A'
);
```

---

## 5️⃣ 新增預設 Fab

1. 參考 [src/database/models/fab.py](src/database/models/fab.py) 欄位定義。  
2. 使用以下範例 SQL 新增資料：  

```sql
INSERT INTO public."fab" (
    name
) VALUES (
    'L8A'
);
```

---

## 6️⃣ 啟動服務

於系統中分別執行以下可執行檔（確保兩者同時運行）：
```bash
opsview_backend.exe
opsview_scheduler.exe
```

---

✅ **完成以上步驟後，即可於本地啟動並使用作業觀察平台-本地版。**