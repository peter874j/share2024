#!/bin/sh

# Function: Linux/FreeBSD 之 SCS 偵測（USB storage 插入記錄、Root 密碼檢查、資訊回報）
# Creattion Date: 2016/12/07
# Creator: Wei-Jih Lee
# Modification Date: 
# Modified By: 
# Reason For Modification: 

# 請確認系統有 curl 或 ftp 指令可供使用
# 需透過 cron，以 root 身份每三小時執行一次
# 執行 crontab -e 編輯 root 之 crontab，加入下行（scs.sh 放置於 /usr/local/bin）
# 0	*/3	*	*	*	/bin/sh /usr/local/bin/scs.sh > /dev/null 2>&1


PATH=/sbin:/usr/sbin:/bin:/usr/bin:/usr/local/bin:/usr/local/sbin
export PATH

REV_DATE="20200928"
SH_FILE="scs.sh"

MY_FILE="$0"

[ -d /tmp ] && TMP_FILE="/tmp/${SH_FILE}" || TMP_FILE="/root/${SH_FILE}"

HAS_CURL=`which curl`
HAS_FTP=`which ftp`

if [ -n "${HAS_CURL}" ]; then
	"${HAS_CURL}" -s -B -o "${TMP_FILE}" "ftp://linuxscs:linuxscs@10.10.60.180/SCS/${SH_FILE}"
elif [ -n "${HAS_FTP}" ]; then
	"${HAS_FTP}" -n 10.10.60.180 << END_SCRIPT > /dev/null 2>&1
quote USER linuxscs
quote PASS linuxscs
ascii
get "SCS/${SH_FILE}" "${TMP_FILE}"
quit
END_SCRIPT
else
	exit
fi

if [ -f "${TMP_FILE}" ]; then
  NEW_DATE=`sed -n 's/REV_DATE="\([0-9]*\)"/\1/p' "${TMP_FILE}"`
  [ "${NEW_DATE}" \> "${REV_DATE}" ] && ( mv "${TMP_FILE}" "${MY_FILE}"; /bin/sh "${MY_FILE}"; exit )
fi

OS_TYPE=`uname`
OS_ARCH=`uname -m`

COUNT=1

while [ ${COUNT} -le 27 ]; do
	eval COL${COUNT}=""
	COUNT=`expr ${COUNT} + 1`
done

COL4="Security_OK"
COL8="DeviceLock_OK"
USB_DEV=""
NET_IFS=""

case ${OS_TYPE} in
Linux)
	CHECK_TIME=`date --date='1 hours ago' '+%b_%e_%T' | sed 's/ //g'`
	for NET_IF in `grep ':' /proc/net/dev | cut -d':' -f1`; do
	        MAC_ADDR=`ip link show ${NET_IF} | sed -n 's/.*link\/ether //p' | cut -d' ' -f1 | sed -e's/://g' -e 's/ //g'`
	        if [ -z "${MAC_ADDR}" ]; then
	        	MAC_ADDR=`ifconfig ${NET_IF} | sed -n 's/.*HWaddr //p' | sed -e's/://g' -e 's/ //g'`
	        fi
	        if [ -z "${MAC_ADDR}" ]; then
	        	MAC_ADDR=`ifconfig ${NET_IF} | grep 'ether .*Ethernet' | sed -n 's/.*ether //p' | cut -d' ' -f1 | sed -e's/://g' -e 's/ //g'`
	        fi
		if [ -n "${MAC_ADDR}" ]; then
			eval MAC_ADDR_${NET_IF}="${MAC_ADDR}"
			eval IP_ADDR_${NET_IF}=`ifconfig ${NET_IF} | sed -n 's/.*inet addr://p' | grep 'Bcast' | cut -d' ' -f1`
			NET_IFS="${NET_IFS} ${NET_IF}"
		fi
	done
	COL10=`grep 'model name' /proc/cpuinfo | uniq | sed -r 's/model name\s+:\s+//'`
	case ${OS_ARCH} in
	x86_64)
		COL15="${OS_TYPE} 64-bit"
		;;
	i[3456]86)
		COL15="${OS_TYPE} 32-bit"
		;;
	esac
	[ -f "/etc/redhat-release" ] && COL16=`cat /etc/redhat-release` || COL16=''
	[ -f "/etc/os-release" ] && COL16=`grep PRETTY_NAME /etc/os-release | cut -d'"' -f2` || COL16=''
	HDD=''
	COL23=0
	for HDD_SIZE in `fdisk -l 2> /dev/null | sed -n 's/Disk \/dev\/\(.*\):.* \([0-9]*\) bytes/\1,\2/p' | grep 'd[a-z],'`; do
		DEV_NAME=`echo "${HDD_SIZE}" | cut -d',' -f1`
		SIZE=`echo "${HDD_SIZE}" | cut -d',' -f2`
		DEV_MAJOR=`grep "${DEV_NAME}\$" /proc/partitions | cut -c1-4`
		if [ -z "${DEV_MAJOR}" ] || [ ${DEV_MAJOR} -ge 253 ]; then
			continue
		fi
		[ -n "${SIZE}" ] && HDD="${HDD}"`echo "scale=0;${SIZE}/1073741824" | bc`'GB ' || HDD="${HDD}Unknown "
		COL23=$((${COL23}+1))
	done
	COL22=`echo "${HDD}" | sed 's/\(.*\) $/\1/'`
	MEMORY=`sed -n 's/MemTotal://p' /proc/meminfo | sed -e 's/ //g' -e 's/kB//'`
	COL24=`echo "scale=2;${MEMORY}/1048576" | bc`'GB'
	if [ -f "/var/log/messages" ]; then
		USB_LOGS=`grep -A3 'SCSI emulation for USB Mass Storage devices' /var/log/messages | sed -n 's/^\(.* [0-9][0-9]:[0-9][0-9]:[0-9][0-9]\) .*Vendor: \(.*\) Model: \(.*\) Rev:.*/\1|\2\3/p' | sed -e 's/  *$//' -e 's/  */_/g'`
	elif [ -f "/var/log/syslog" ]; then
		USB_LOGS=`grep -A3 'SCSI emulation for USB Mass Storage devices' /var/log/syslog | sed -n 's/^\(.* [0-9][0-9]:[0-9][0-9]:[0-9][0-9]\) .*Vendor: \(.*\) Model: \(.*\) Rev:.*/\1|\2\3/p' | sed -e 's/  *$//' -e 's/  */_/g'`
	fi
	for USB_LOG in ${USB_LOGS}; do
		[ "`echo "${USB_LOG}" | cut -d'|' -f1`" \> "${CHECK_TIME}" ] && USB_DEV="${USB_DEV} "`echo "${USB_LOG}" | cut -d'|' -f2`
	done
	[ -n "${USB_DEV}" ] && ( COL4="Security_Risk"; COL8=${USB_DEV} )
	COL27=0
	( cut -d: -f1,3 /etc/passwd | grep ':0$' | cut -d: -f1 | grep -v 'root' > /dev/null 2>&1 ) && COL27=1
	( cut -d: -f1,2 /etc/shadow | grep ':$' > /dev/null 2>&1 ) && COL27=2
	;;
FreeBSD)
	CHECK_TIME=`date -v-3H '+%b_%e_%T'`
	for NET_IF in `ifconfig -l`; do
		MAC_ADDR=`ifconfig ${NET_IF} | sed -n 's/.*ether //p' | sed 's/://g' | tr 'a-z' 'A-Z'`
		if [ -n "${MAC_ADDR}" ]; then
			eval MAC_ADDR_${NET_IF}="${MAC_ADDR}"
			eval IP_ADDR_${NET_IF}=`ifconfig ${NET_IF} | sed -n 's/.*inet //p' | grep 'broadcast' | cut -d' ' -f1`
			NET_IFS="${NET_IFS} ${NET_IF}"
		fi
	done
	COL10=`sed -n 's/CPU: //p' /var/run/dmesg.boot | sed -E 's/ \(.+Hz.+CPU\)//' | uniq`
	case ${OS_ARCH} in
	amd64)
		COL15="${OS_TYPE} 64-bit"
		;;
	i386)
		COL15="${OS_TYPE} 32-bit"
		;;
	esac
	COL16=`uname -r`
	HDD=''
	COL23=0
	for DISK in `fdisk -s | sed -n 's/^\/dev\/\([a-z]*[0-9]*\):.*/\1/p'`; do
		HDD_SIZE=`sed -n "s/${DISK}:.*[ (]\([0-9]*\)MB[ )].*/\1/p" /var/run/dmesg.boot | uniq`
		[ -n "${HDD_SIZE}" ] && HDD="${HDD}"`echo "scale=0;${HDD_SIZE}/1024" | bc`'GB ' || HDD="${HDD}Unknown "
		COL23=$((${COL23}+1))
	done
	COL22=`echo "${HDD}" | sed 's/\(.*\) $/\1/'`
	MEMORY=`sed -n -E 's/(real|avail) memory  = //p' /var/run/dmesg.boot | cut -d' ' -f1`
	COL24=`echo "scale=2;${MEMORY}/1073741824" | bc`'GB'
	USB_LOGS=`sed -n 's/^\(.* [0-9][0-9]:[0-9][0-9]:[0-9][0-9]\) .*umass.*<\(.*\), class.* on usbus.*/\1|\2/p' /var/log/messages | sed 's/ /_/g'`
	for USB_LOG in ${USB_LOGS}; do
		[ "`echo "${USB_LOG}" | cut -d'|' -f1`" \> "${CHECK_TIME}" ] && USB_DEV="${USB_DEV} "`echo "${USB_LOG}" | cut -d'|' -f2`
	done
	[ -n "${USB_DEV}" ] && ( COL4="Security_Risk"; 	COL8=${USB_DEV} )
	COL27=0
	( cut -d: -f1,3 /etc/master.passwd | grep ':0$' | cut -d: -f1 | grep -v 'root' > /dev/null 2>&1 ) && COL27=1
	( cut -d: -f1,2 /etc/master.passwd | grep ':$' > /dev/null 2>&1 ) && COL27=2
	;;
*)
	;;
esac

for NET_IF in ${NET_IFS}; do
	eval COL13="\$IP_ADDR_${NET_IF}"
	eval COL14="\$MAC_ADDR_${NET_IF}"
	case ${COL13} in
	10\.10\.78\.*)
		OL3="other" ;;
	10\.10\.*\.*)
		COL3="HY" ;;
	10\.30\.*\.*)
		COL3="LK" ;;
	10\.82\.*\.*)
		COL3="L3A" ;;
	10\.83\.*\.*)
		COL3="L3B" ;;
	10\.84\.*\.*)
		COL3="L3C" ;;
	10\.86\.12\.* | 10\.96\.140\.*)
		COL3="VPN" ;;
	10\.86\.*\.*)
		COL3="ATC" ;;
	10\.88\.*\.*)
		COL3="LT" ;;
	10\.96\.*\.*)
		COL3="TC" ;;
	10\.36\.*\.*)
		COL3="HL" ;;
	10\.[56]\.*\.*)
		COL3="AUZ" ;;
	10\.100\.*\.*)
		COL3="AUJ" ;;
	10\.8\.*\.*)
		COL3="AUXM" ;;
	10\.44\.*\.*)
		COL3="AUCZ" ;;
	10\.45\.*\.*)
		COL3="AUK" ;;
	10\.39\.*\.*)
		COL3="AUT" ;;
	*)
		COL3="other" ;;
	esac
	
	COL1=`date '+%Y%m%d%H'`
	COL2=`hostname -s`

	LOG_FILE="${COL14},${COL2},${COL4},ver.${REV_DATE}"
	[ -d /tmp ] && TMP_FILE="/tmp/${LOG_FILE}" || TMP_FILE="/root/${LOG_FILE}"
	echo -n > ${TMP_FILE}
	COUNT=1
	while [ ${COUNT} -le 26 ]; do
		eval echo -n "\$COL${COUNT}," >> ${TMP_FILE}
		COUNT=`expr ${COUNT} + 1`
	done
	echo ${COL27} >> ${TMP_FILE}

	if [ -n "${HAS_CURL}" ]; then
		"${HAS_CURL}" -s -T "${TMP_FILE}" "ftp://linuxscs:linuxscs@10.10.60.180/${LOG_FILE}"
	elif [ -n "${HAS_FTP}" ]; then
		"${HAS_FTP}" -n 10.10.60.180 << END_SCRIPT > /dev/null 2>&1
quote USER linuxscs
quote PASS linuxscs
put "${TMP_FILE}" "${LOG_FILE}"
quit
END_SCRIPT
	fi

done
