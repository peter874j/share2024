window.env = {
    REACT_APP_ENV: "production",
    REACT_APP_API_BACKEND_URL: "http://10.96.152.244:8000"
};