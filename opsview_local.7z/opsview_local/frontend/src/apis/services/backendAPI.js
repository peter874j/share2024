import qs from "qs";
import { backendApiClient } from "../configs/axiosConfig";
import { requestWrapper } from "../utils/customError";

class BackendAPI {
    async login(payload) {
        return await requestWrapper(() =>
            backendApiClient.client.post("/api/auth/login", payload),
        );
    }

    async getUserInfo() {
        return await requestWrapper(() =>
            backendApiClient.client.get("/api/auth/me"),
        );
    }

    async refresh(payload) {
        return await requestWrapper(() =>
            backendApiClient.client.post("/api/auth/refresh", payload),
        );
    }

    async logout() {
        return await requestWrapper(() =>
            backendApiClient.client.post("/api/auth/logout"),
        );
    }

    async getImprotStatus() {
        return await requestWrapper(() =>
            backendApiClient.client.get("/api/unit/import-stats"),
        );
    }

    /**
     * 從後端取得站點報表
     * @param {Object} params - 查詢參數
     * @param {string} params.start_at - 開始時間，ISO 格式
     * @param {string} params.end_at - 結束時間，ISO 格式
     * @param {number} params.fab_id - FAB 編號
     * @param {number} params.stage_id - Stage 編號
     * @param {number} [params.unit_ids] - 崗位（unit）ID 列表，可多次傳入，如 ?unit_ids=1&unit_ids=2
     */
    async getStageAnalysisReport({ startAt, endAt, fabId, stageId, unitIds }) {
        const params = {
            start_at: startAt,
            end_at: endAt,
            fab_id: fabId,
            stage_id: stageId,
            unit_ids: unitIds,
        };

        return await requestWrapper(() =>
            backendApiClient.client.get("/api/reports/stage-analysis-report", {
                params,
                paramsSerializer: (params) =>
                    qs.stringify(params, { arrayFormat: "repeat" }),
            }),
        );
    }

    /**
     * 從後端取得崗位報表
     * @param {Object} params - 查詢參數
     * @param {string} params.start_at - 開始時間，ISO 格式
     * @param {string} params.end_at - 結束時間，ISO 格式
     * @param {number} params.fab_id - FAB 編號
     * @param {number} params.stage_id - Stage 編號
     * @param {number} params.unit_id - 崗位（unit）ID
     */
    async getUnitAnalysisReport({ startAt, endAt, fabId, stageId, unitId }) {
        const params = {
            start_at: startAt,
            end_at: endAt,
            fab_id: fabId,
            stage_id: stageId,
            unit_id: unitId,
        };

        return await requestWrapper(() =>
            backendApiClient.client.get("/api/reports/unit-analysis-report", {
                params,
            }),
        );
    }

    async getUnitCycleDetailReport(cycleStartTime, unitId) {
        const params = {
            unit_id: unitId,
        };

        return await requestWrapper(() =>
            backendApiClient.client.get(
                `/api/reports/unit-analysis-cycle-detail/${cycleStartTime}`,
                {
                    params,
                },
            ),
        );
    }

    /**
     * 從後端取得崗位列表（支援分頁、排序、搜尋）
     * @param {Object} params - 查詢參數
     * @param {number} params.page - 第幾頁（1-based）
     * @param {number} params.limit - 每頁筆數
     * @param {string} params.sortField - 排序欄位
     * @param {"asc"|"desc"} params.sortOrder - 排序方向
     * @param {string} [params.searchKeyword] - 搜尋關鍵字（option）
     */
    async getUnitInfo({
        page,
        limit,
        sortField,
        sortOrder,
        searchKeyword = "",
    }) {
        const params = {
            page,
            limit,
            sort_field: sortField,
            sort_order: sortOrder,
        };

        if (searchKeyword) {
            params.search = searchKeyword;
        }

        return await requestWrapper(() =>
            backendApiClient.client.get("/api/unit", { params }),
        );
    }

    // 建立 unit
    async createUnit(payload) {
        return await requestWrapper(() =>
            backendApiClient.client.post("/api/unit", payload),
        );
    }

    // 更新 unit
    async updateUnit(unitId, payload) {
        return await requestWrapper(() =>
            backendApiClient.client.patch(`/api/unit/${unitId}`, payload),
        );
    }

    // 刪除 unit
    async deleteUnit(unitId) {
        return await requestWrapper(() =>
            backendApiClient.client.delete(`/api/unit/${unitId}`),
        );
    }

    // 取得導入狀態列表
    async getImportStatus() {
        return await requestWrapper(() =>
            backendApiClient.client.get("/api/unit/import-stats"),
        );
    }

    // 取得 object 列表
    async getObjects(unitId = null) {
        const params = {};

        if (unitId) {
            params.unit_id = unitId;
        }

        return await requestWrapper(() =>
            backendApiClient.client.get("/api/object", { params }),
        );
    }

    // 取得 fence 列表
    async getFences(unitId = null) {
        const params = {};

        if (unitId) {
            params.unit_id = unitId;
        }

        return await requestWrapper(() =>
            backendApiClient.client.get("/api/fences", { params }),
        );
    }

    // 建立 fence
    async createFence(payload) {
        return await requestWrapper(() =>
            backendApiClient.client.post("/api/fences", payload),
        );
    }

    // 更新 fence
    async updateFence(fenceId, payload) {
        return await requestWrapper(() =>
            backendApiClient.client.patch(`/api/fences/${fenceId}`, payload),
        );
    }

    // 刪除 fence
    async deleteFence(fenceId) {
        return await requestWrapper(() =>
            backendApiClient.client.delete(`/api/fences/${fenceId}`),
        );
    }

    // 取得 condition 列表
    async getConditions(unitId = null) {
        const params = {};

        if (unitId) {
            params.unit_id = unitId;
        }

        return await requestWrapper(() =>
            backendApiClient.client.get("/api/conditions", { params }),
        );
    }

    // 建立 condition
    async createCondition(payload) {
        return await requestWrapper(() =>
            backendApiClient.client.post("/api/conditions", payload),
        );
    }

    // 更新 condition
    async updateCondition(conditionId, payload) {
        return await requestWrapper(() =>
            backendApiClient.client.patch(
                `/api/conditions/${conditionId}`,
                payload,
            ),
        );
    }

    // 刪除 condition
    async deleteCondition(conditionId) {
        return await requestWrapper(() =>
            backendApiClient.client.delete(`/api/conditions/${conditionId}`),
        );
    }

    // 取得 logic 列表
    async getLogics(unitId = null) {
        const params = {};

        if (unitId) {
            params.unit_id = unitId;
        }

        return await requestWrapper(() =>
            backendApiClient.client.get("/api/logics", { params }),
        );
    }

    // 建立 logic
    async createLogic(payload) {
        return await requestWrapper(() =>
            backendApiClient.client.post("/api/logics", payload),
        );
    }

    // 更新 logic
    async updateLogic(logicId, payload) {
        return await requestWrapper(() =>
            backendApiClient.client.patch(`/api/logics/${logicId}`, payload),
        );
    }

    // 刪除 logic
    async deleteLogic(logicId) {
        return await requestWrapper(() =>
            backendApiClient.client.delete(`/api/logics/${logicId}`),
        );
    }

    // AI 參數更新
    async syncConfig(payload) {
        return await requestWrapper(() => 
            backendApiClient.client.post("/api/clients/sync-config", payload)
        )
    }

    // 更新 work id
    async updateReportWorkId(reportId, payload) {
        return await requestWrapper(() =>
        backendApiClient.client.patch(`/api/reports/report/${reportId}/workId`, payload)
        )
    }

    // 查詢 Fab 列表
    async getFabOptions() {
        return requestWrapper(() => backendApiClient.client.get(`/api/fab`));
    }

    // 查詢指定廠區的站點列表
    async getStageOptions(fab) {
        return requestWrapper(() =>
            backendApiClient.client.get(`/api/stage?location=${fab}`),
        );
    }

    // 查詢指定站點的崗位列表
    async getUnitOptions(fab, stage) {
        return requestWrapper(() =>
            backendApiClient.client.get(
                `/api/unit/list?location=${fab}&stage_name=${stage}`,
            ),
        );
    }

    // 查詢設備狀態列表
    async getEquipData(fabId) {
        return await requestWrapper(() =>
            backendApiClient.client.get(`/api/servers/list?fab_id=${fabId}`),
        );
    }

    // 取得用戶列表
    async getPermissions(fab) {
        return await requestWrapper(() =>
            backendApiClient.client.get(`/api/user/list?location=${fab}`),
        );
    }

    // 更新用戶角色
    async updateUserRole(userId, role) {
        return await requestWrapper(() =>
            backendApiClient.client.put(`/api/user/${userId}/role`, { role }),
        );
    }

    // 新增主機
    async addPc(fabId, pcName, pcIp) {
        return await requestWrapper(() =>
            backendApiClient.client.post("/api/servers", {
                fab_id: fabId,
                name: pcName,
                ip: pcIp,
                description: "",
                status: false,
            }),
        );
    }

    // 編輯主機
    async editPc(serverId, pcName, pcIp, status) {
        return await requestWrapper(() =>
            backendApiClient.client.patch(`/api/servers/${serverId}`, {
                name: pcName,
                ip: pcIp,
                description: "",
                status: status,
            }),
        );
    }

    // 刪除主機
    async delPc(pcId) {
        return await requestWrapper(() =>
            backendApiClient.client.delete(`/api/servers/${pcId}`),
        );
    }

    // 新增攝影機
    async addCam(serverId, stageId, unitId, camIp, aiServicePort) {
        const payload = {
            stage_id: stageId,
            unit_id: unitId,
            server_id: serverId,
            ip: camIp,
            port: aiServicePort,
        };
        return await requestWrapper(() =>
            backendApiClient.client.post("/api/cams", payload),
        );
    }

    // 編輯攝影機
    async editCam(camId, stageId, unitId, camIp, aiServicePort) {
        const payload = {
            stage_id: stageId,
            unit_id: unitId,
            ip: camIp,
            port: aiServicePort,
        };
        return await requestWrapper(() =>
            backendApiClient.client.patch(`/api/cams/${camId}`, payload),
        );
    }

    // 刪除攝影機
    async delCam(camId) {
        return await requestWrapper(() =>
            backendApiClient.client.delete(`/api/cams/${camId}`),
        );
    }

    async getStreamUrls(fabId, stageId, unitIds) {
        return await requestWrapper(() =>
            backendApiClient.client.get(
                `/api/cams/stream-list?fab_id=${fabId}&stage_id=${stageId}&unit_ids=${unitIds.join(",")}`,
            ),
        );

        // XXX: 假資料
        // return {
        //     status: true,
        //     data: unitIds.map(() => ({
        //         id: null,
        //         name: null,
        //         stream_pre_uri: "http://10.97.160.69:8001/video_stream/preview",
        //         stream_det_uri: "http://10.97.160.69:8001/video_stream/frame",
        //         unit_name: null,
        //     })),
        // };

        /*
        api ressponse
        [
            {
                id: 6,
                name: "192.168.1.4:8080",
                stream_pre_uri: "rtsp://192.168.1.4:8080/preview",
                stream_det_uri: "rtsp://192.168.1.4:8080/detail",
                unit_name: "string_unit_2",
            },
            {
                id: 30,
                name: "192.168.0.102:8001",
                stream_pre_uri: "rtsp://192.168.0.102:8001/preview",
                stream_det_uri: "rtsp://192.168.0.102:8001/detail",
                unit_name: "string_unit_2",
            },
        ];
        */
    }
}

export const backendAPI = new BackendAPI();
