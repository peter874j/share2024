// 將資料庫中的權限字串映射為顯示文字和數值
const roleMapping = {
    super_admin: { displayName: "Super Admin", value: 0 },
    admin: { displayName: "Admin", value: 1 },
    user: { displayName: "User", value: 2 },
};

// 反向映射, 用於將顯示文字轉為對應的權限字串
const roleKeyByDisplayName = {};
const roleKeyByValue = {};
for (const key in roleMapping) {
    const { displayName, value } = roleMapping[key];
    roleKeyByDisplayName[displayName] = key;
    roleKeyByValue[value] = key;
}

// 比較權限大小, 回傳大於 0 表示比較大
function RoleComparator(roleDisplayName1, roleDisplayName2) {
    return (
        roleMapping[roleKeyByDisplayName[roleDisplayName2]].value -
        roleMapping[roleKeyByDisplayName[roleDisplayName1]].value
    );
}

// 檢查是否為管理員
function getIsAdmin(currentRole) {
    return roleMapping[currentRole].value <= 1;
}

export { roleMapping, roleKeyByDisplayName, getIsAdmin, RoleComparator };
