export class CustomError extends Error {
    responseJson;

    constructor(message, responseJson) {
        super(message);
        this.responseJson = responseJson;
    }
}

/**
 * General error handling function
 * @param {object} error - Axios error object
 * @returns {string} - Error message
 */
export function handleError(error) {
    if (error.response) {
        console.error("Error response:", error.response.data);
        return (
            error.response.data?.detail?.[0]?.msg ||
            error.response.data?.message ||
            "Unknown server error."
        );
    } else if (error.request) {
        console.error("No response from server:", error.request);
        return "No response from server. Please try again later.";
    } else {
        console.error("Error message:", error?.message);
        return error?.message || "An unknown error occurred.";
    }
}

/**
 * General request wrapper
 * @param {function} apiCall - Function to make the API request
 * @returns {Promise<any>} - Request result or error message
 */
export async function requestWrapper(apiCall) {
    try {
        const response = await apiCall();
        return response;
    } catch (error) {
        console.error("Error message:", error);
        return handleError(error);
    }
}
