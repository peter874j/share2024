/* eslint-disable no-constant-condition */
import axios from "axios";
import { checkOnlineStatus } from "../../utils/checkNetwork";
import { NotificationService } from "../../components/NotificationService";
import getEnv from "../../utils/getEnv";

const BASE_URLS = {
    backend: getEnv("API_BACKEND_URL")
};

/**
 * Base API Client Class
 */
class ApiClient {
    constructor(baseURL, timeout = 5000) {
        this.client = axios.create({ baseURL, timeout });
        this.initializeRequestInterceptor();
        this.initializeResponseInterceptor();
    }

    initializeRequestInterceptor() {
        this.client.interceptors.request.use(
            async (config) => {
                await checkOnlineStatus();

                return config;
            },
            (error) => Promise.reject(error),
        );
    }

    initializeResponseInterceptor() {
        this.client.interceptors.response.use(
            (response) => response,
            async (error) => {
                if (
                    error.code === "ECONNABORTED" ||
                    error.message === "Network Error" ||
                    error.response?.status === 504
                ) {
                    console.log("Network error, retrying...");
                    return ApiClient.retryRequest(error.config);
                }
                if (error.response?.status === 400) {
                    return error.response;
                }
                return Promise.reject(error);
            },
        );
    }

    static retryRequest(originalRequest, retriesLeft = 2, delay = 1000) {
        return new Promise((resolve, reject) => {
            function attempt() {
                axios(originalRequest)
                    .then(resolve)
                    .catch((error) => {
                        if (retriesLeft === 0) {
                            reject(error);
                            return;
                        }
                        retriesLeft--;
                        setTimeout(
                            attempt,
                            delay * Math.pow(2, 2 - retriesLeft),
                        );
                    });
            }
            attempt();
        });
    }
}

/**
 * Specialized Backend API Client
 */
class BackendApiClient extends ApiClient {
    constructor() {
        super(BASE_URLS.backend, 10000);
    }

    initializeRequestInterceptor() {
        this.client.interceptors.request.use(
            async (config) => {
                await checkOnlineStatus();

                if (!config._rawData) {
                    config._rawData = config.data;
                }

                const accessToken = localStorage.getItem("accessToken");
                if (accessToken) {
                    config.headers = {
                        Authorization: `Bearer ${accessToken}`,
                    };
                }

                return config;
            },
            (error) => Promise.reject(error),
        );
    }

    initializeResponseInterceptor() {
        this.client.interceptors.response.use(
            (response) => response,
            async (error) => {
                const originalRequest = error.config;

                if (
                    error.response?.status === 401 &&
                    !originalRequest._retry &&
                    !error.response?.data?.detail?.includes("UAC")
                ) {
                    originalRequest._retry = true;
                    const refreshToken = localStorage.getItem("refreshToken");

                    /* ---------- 無 refreshToken ⇒ 直接登出 ---------- */
                    if (!refreshToken) {
                        clearAuthAndRedirect();
                        return Promise.reject(error);
                    }

                    try {
                        /* ---------- 1. 取得新 access token ---------- */
                        const { data } = await axios.post(
                            `${BASE_URLS.backend}/api/auth/refresh`,
                            { refresh_token: refreshToken },
                        );
                        const newAccessToken = data.access_token;
                        localStorage.setItem("accessToken", newAccessToken);

                        /* ---------- 2. 還原原始 payload ---------- */
                        if (originalRequest._rawData !== undefined) {
                            originalRequest.data = originalRequest._rawData; // ✨ 關鍵
                        }

                        /* ---------- 3. 更新 header 並重送 ---------- */
                        originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;
                        return this.client(originalRequest);
                    } catch (refreshError) {
                        if (refreshError.response?.status === 401) {
                            clearAuthAndRedirect();
                        }
                        return Promise.reject(refreshError);
                    }
                }

                return (
                    super.client?.interceptors?.response?.handlers[0]?.rejected?.(
                        error,
                    ) ?? Promise.reject(error)
                );
            },
        );
    }
}

function clearAuthAndRedirect() {
    localStorage.removeItem("accessToken");
    localStorage.removeItem("refreshToken");
    localStorage.removeItem("user");
    NotificationService.handleInfo("Token has expired. Please log in again.");
    window.location.href = "#/login";
}

const backendApiClient = new BackendApiClient();

export { backendApiClient, BASE_URLS };
