import React from "react";
import { UserContext } from "../utils/userContext";
import { useNavigate,  } from "react-router-dom";
import { loadFromLocalStorage } from "../utils/localStorageUtils";

export default function LandingPage() {
    const navigate = useNavigate();
    const { setLoading } = React.useContext(UserContext);

    React.useEffect(() => {
        const run = async () => {
          setLoading(true);

          const user = loadFromLocalStorage("user");
    
          if (!user) {
            navigate("/login");
          } else {
            navigate("/post");
          }
    
          setLoading(false);
        };
    
        run();
      }, []);
    
      return <></>;
}