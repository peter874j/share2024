/* eslint-disable no-unused-vars */
import React, { useContext, useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import * as Yup from "yup";
import { Formik } from "formik";
import { useTheme } from "@mui/material/styles";
import {
    Stack,
    Box,
    Divider,
    Card,
    Checkbox,
    FormControl,
    FormControlLabel,
    FormHelperText,
    IconButton,
    InputAdornment,
    InputLabel,
    OutlinedInput,
} from "@mui/material";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import whiteLogo from "../assets/images/R_B_png.png";
import blackLogo from "../assets/images/R_W_png.png";
import "../assets/css/fade.css";
import "../assets/css/gradient.css";
import { SubTitleLabel, TitleLabel } from "../components/Label";
import { SecondaryActionButton } from "../components/StyledButton";
import { UserContext } from "../utils/userContext";
import { backendAPI } from "../apis/services/backendAPI";
import WelcomeText from "../components/login/WecomeText";
import {
    saveToLocalStorage,
    loadFromLocalStorage,
} from "../utils/localStorageUtils";
import ContentDialog from "../components/ContentDialog";

export default function LoginPage() {
    const theme = useTheme();
    const navigate = useNavigate();
    const { isDarkMode, setLoading } = useContext(UserContext);
    const [checked, setChecked] = useState(
        loadFromLocalStorage("remeberMe") || false,
    );
    const [showAlert, setShowAlert] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const alertTitle = useRef("");
    const alertMessage = useRef("");

    const sxInput = {
        marginTop: 1,
        marginBottom: 1,
        "& > label": {
            top: 18,
            left: 0,

            color: theme.palette.text.gery,
            '&[data-shrink="false"]': {
                top: 5,
            },
        },
        "& > div > input": {
            padding: "30.5px 14px 11.5px !important",
        },
        "& legend": {
            display: "none",
        },

        "& fieldset": {
            top: 0,
            borderColor: theme.palette.text.gery,
        },
    };

    /**
     * Handle Initial Redirect
     *
     * Checks if a user is already authenticated (based on local storage).
     * - If authenticated, navigates to the home page or a specified URL.
     * - Otherwise, stays on the login page.
     */
    useEffect(() => {
        if (loadFromLocalStorage("user") !== null) {
            navigate("/home");
        }
    }, []);

    /**
     * Login API Call
     *
     * Sends a login request to the server with the provided account and password.
     * @param {string} account - User's account/username.
     * @param {string} password - User's password.
     * @returns {Promise} - Response from the server.
     */
    const handleLogin = async (account, password) => {
        const payload = {
            username: account,
            password: password,
        };

        const response = await backendAPI.login(payload);
        return response;
    };

    /**
     * Fetch User Info
     *
     * Fetches the authenticated user's information and saves it to local storage.
     */
    const handleGetUserInfo = async () => {
        const response = await backendAPI.getUserInfo();
        saveToLocalStorage("user", response.data);
        setLoading(false);
        navigate("/h/import");
    };

    /**
     * Remember Me
     *
     * Handles saving or clearing the user's account information based on the "Remember Me" checkbox state.
     * @param {boolean} checked - Whether the "Remember Me" option is checked.
     * @param {string} account - User's account/username.
     */
    const handleRemeberMe = (checked, account) => {
        if (checked) {
            localStorage.setItem("account", account);
            saveToLocalStorage("remeberMe", true);
        } else {
            localStorage.removeItem("account");
            saveToLocalStorage("remeberMe", false);
        }
    };

    /**
     * Toggle Password Visibility
     *
     * Toggles the visibility of the password input field.
     */
    const handleClickShowPassword = () => {
        setShowPassword(!showPassword);
    };

    /**
     * Prevent Default Mouse Down on Password Icon
     *
     * Prevents the default mouse down event when clicking the password visibility toggle icon.
     * @param {Event} event - Mouse down event.
     */
    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };
    return (
        <>
            {loadFromLocalStorage("user") === null && (
                <Box
                    sx={{
                        width: "100%",
                        display: "flex",
                        position: "relative",
                        justifyContent: "center",
                    }}
                >
                    <Box
                        sx={{
                            width: "100%",
                            height: "100vh",
                            maxWidth: "100vw",
                            display: "flex",
                            position: "relative",
                            "@media(max-width:991px)": {
                                justifyContent: "center",
                            },
                        }}
                    >
                        <Box
                            sx={{
                                m: 2,
                                mr: 5,
                                backgroundColor: theme.palette.background.histroySelected,
                                borderRadius: "1.75rem",
                                width: "55%",
                                display: "flex",
                                alignItems: "center",
                                "@media(max-width:1200px)": { width: "60%" },
                                "@media(max-width:991px)": { display: "none" },
                                "@media(max-width:479px)": { display: "none" },
                            }}
                        >
                            <Stack
                                sx={{
                                    width: "100%",
                                }}
                            >
                                <Box sx={{ pl: 7, gap: 1.5 }}>
                                    {/* <img
                                        src={isDarkMode ? blackLogo : whiteLogo}
                                        style={{
                                            width: "auto",
                                            height: "5vw",
                                        }}
                                    /> */}
                                    <TitleLabel fontSize={"88px"}>
                                        O - View
                                    </TitleLabel>
                                    <WelcomeText />
                                </Box>
                                <Divider
                                        sx={{
                                            borderStyle: "dashed",
                                            border: 0,
                                            mt: 3,
                                            height: "0.3vw",
                                            backgroundSize: "150px 1px",
                                            backgroundImage:
                                                "repeating-linear-gradient(to right, #7a7171, #7a7171 10px, transparent 10px, transparent 20px)",
                                        }}
                                    />
                            </Stack>
                        </Box>
                        <Box
                            sx={{
                                width: "35%",
                                display: "flex",
                                alignItems: "center",
                                position: "relative",
                                minWidth: "450px",
                                pl: 20,
                                "@media(max-width:1200px)": {
                                    width: "40%",
                                    pl: 10,
                                },
                                "@media(max-width:991px)": {
                                    width: "50%",
                                    pl: 0,
                                },
                                "@media(max-width:479px)": {
                                    width: "60%",
                                    pl: 0,
                                },
                            }}
                        >
                            <Box
                                className={
                                    isDarkMode
                                        ? "login_circle_1"
                                        : "login_circle_light_1"
                                }
                                width="250px"
                                height="250px"
                                sx={{
                                    position: "absolute",
                                    top: "8%",
                                    left: "8%",
                                }}
                            />
                            <Box
                                className={
                                    isDarkMode
                                        ? "login_circle_2"
                                        : "login_circle_light_2"
                                }
                                width="180px"
                                height="180px"
                                sx={{
                                    position: "absolute",
                                    bottom: "8%",
                                    right: "-8%",
                                }}
                            />
                            <Stack
                                sx={{
                                    flex: 1,
                                    alignItems: "center",
                                    width: "100%",
                                    justifyContent: "center",
                                }}
                            >
                                <Card
                                    sx={{
                                        borderRadius: "0.75rem",
                                        display: "flex",
                                        flexDirection: "column",
                                        gap: "20px",
                                        boxShadow: "none",
                                        width: "100%",
                                        padding: "30px",
                                        backdropFilter: "blur(16px)",
                                        letterSpacing: "1px",
                                        backgroundColor: "rgba(0,0,0,0.05)",
                                    }}
                                >
                                    <Stack
                                        direction="column"
                                        sx={{
                                            height: "65vh",
                                            minHeight: "550px",
                                            justifyContent: "center",
                                        }}
                                    >
                                        <TitleLabel
                                            fontSize={"32px"}
                                            sx={{
                                                "@media(maxWidth:991px)": {
                                                    fontSize: "19px",
                                                },
                                                "@media(maxWidth:479px)": {
                                                    fontSize: "19px",
                                                },
                                            }}
                                        >
                                            登入
                                        </TitleLabel>
                                        <SubTitleLabel
                                            fontSize={"16px"}
                                            sx={{
                                                pt: "32px",
                                                "@media(maxWidth:991px)": {
                                                    pt: "20px",
                                                    fontSize: "13px",
                                                },
                                                "@media(maxWidth:479px)": {
                                                    pt: "20px",
                                                    fontSize: "13px",
                                                },
                                            }}
                                        >
                                            輸入員工帳號密碼
                                        </SubTitleLabel>
                                        <Formik
                                            initialValues={{
                                                account:
                                                    localStorage.getItem(
                                                        "account",
                                                    ) || "",
                                                password: "",
                                                submit: null,
                                            }}
                                            validationSchema={Yup.object().shape(
                                                {
                                                    account: Yup.string()
                                                        .max(255)
                                                        .required("請輸入帳號"),
                                                    password: Yup.string()
                                                        .max(255)
                                                        .required("請輸入密碼"),
                                                },
                                            )}
                                            onSubmit={async (
                                                values,
                                                { setStatus, setSubmitting },
                                            ) => {
                                                const { account, password } =
                                                    values;
                                                setLoading(true);

                                                // Handle login logic
                                                const response =
                                                    await handleLogin(
                                                        account,
                                                        password,
                                                    );

                                                if (response?.status !== undefined) {
                                                    setStatus({
                                                        success: true,
                                                    });
                                                    setSubmitting(false);
                                                    localStorage.setItem(
                                                        "accessToken",
                                                        response.data
                                                            .access_token,
                                                    );
                                                    localStorage.setItem(
                                                        "refreshToken",
                                                        response.data
                                                            .refresh_token,
                                                    );
                                                    handleRemeberMe(
                                                        checked,
                                                        account,
                                                    );
                                                    handleGetUserInfo(
                                                        response.data
                                                            .access_token,
                                                    );
                                                } else {
                                                    alertTitle.current = "錯誤";
                                                    alertMessage.current =
                                                        "驗證錯誤";
                                                    setShowAlert(true);
                                                    setLoading(false);
                                                }
                                            }}
                                        >
                                            {({
                                                errors,
                                                handleBlur,
                                                handleChange,
                                                handleSubmit,
                                                isSubmitting,
                                                touched,
                                                values,
                                            }) => (
                                                <form
                                                    noValidate
                                                    onSubmit={handleSubmit}
                                                    onKeyDown={(e) => {
                                                        if (e.key === "Enter") {
                                                            e.preventDefault();
                                                            handleSubmit();
                                                        }
                                                    }}
                                                >
                                                    <FormControl
                                                        fullWidth
                                                        error={Boolean(
                                                            touched.account &&
                                                                errors.account,
                                                        )}
                                                        sx={{ ...sxInput }}
                                                    >
                                                        <InputLabel htmlFor="outlined-adornment-account-login">
                                                            帳號
                                                        </InputLabel>
                                                        <OutlinedInput
                                                            id="outlined-adornment-account-login"
                                                            value={
                                                                values.account
                                                            }
                                                            name="account"
                                                            onBlur={handleBlur}
                                                            onChange={
                                                                handleChange
                                                            }
                                                            label="Account"
                                                        />
                                                        {touched.account &&
                                                            errors.account && (
                                                                <FormHelperText
                                                                    error
                                                                    id="standard-weight-helper-text-account-login"
                                                                >
                                                                    {
                                                                        errors.account
                                                                    }
                                                                </FormHelperText>
                                                            )}
                                                    </FormControl>

                                                    <FormControl
                                                        fullWidth
                                                        error={Boolean(
                                                            touched.password &&
                                                                errors.password,
                                                        )}
                                                        sx={{ ...sxInput }}
                                                    >
                                                        <InputLabel htmlFor="outlined-adornment-password-login">
                                                            密碼
                                                        </InputLabel>
                                                        <OutlinedInput
                                                            id="outlined-adornment-password-login"
                                                            type={
                                                                showPassword
                                                                    ? "text"
                                                                    : "password"
                                                            }
                                                            value={
                                                                values.password
                                                            }
                                                            name="password"
                                                            onBlur={handleBlur}
                                                            onChange={
                                                                handleChange
                                                            }
                                                            endAdornment={
                                                                <InputAdornment position="end">
                                                                    <IconButton
                                                                        aria-label="toggle password visibility"
                                                                        onClick={
                                                                            handleClickShowPassword
                                                                        }
                                                                        onMouseDown={
                                                                            handleMouseDownPassword
                                                                        }
                                                                        edge="end"
                                                                        size="large"
                                                                    >
                                                                        {showPassword ? (
                                                                            <Visibility
                                                                                sx={{
                                                                                    color: theme
                                                                                        .palette
                                                                                        .text
                                                                                        .primary,
                                                                                }}
                                                                            />
                                                                        ) : (
                                                                            <VisibilityOff
                                                                                sx={{
                                                                                    color: theme
                                                                                        .palette
                                                                                        .text
                                                                                        .primary,
                                                                                }}
                                                                            />
                                                                        )}
                                                                    </IconButton>
                                                                </InputAdornment>
                                                            }
                                                            label="Password"
                                                        />
                                                        {touched.password &&
                                                            errors.password && (
                                                                <FormHelperText
                                                                    error
                                                                    id="standard-weight-helper-text-password-login"
                                                                >
                                                                    {
                                                                        errors.password
                                                                    }
                                                                </FormHelperText>
                                                            )}
                                                    </FormControl>
                                                    <FormControlLabel
                                                        control={
                                                            <Checkbox
                                                                checked={
                                                                    checked
                                                                }
                                                                onChange={(
                                                                    event,
                                                                ) =>
                                                                    setChecked(
                                                                        event
                                                                            .target
                                                                            .checked,
                                                                    )
                                                                }
                                                                name="checked"
                                                                color="primary"
                                                            />
                                                        }
                                                        label="記住我"
                                                    />
                                                    {errors.submit && (
                                                        <Box sx={{ mt: 3 }}>
                                                            <FormHelperText
                                                                error
                                                            >
                                                                {errors.submit}
                                                            </FormHelperText>
                                                        </Box>
                                                    )}

                                                    <Box sx={{ mt: "1vw" }}>
                                                        <SecondaryActionButton
                                                            variant="contained"
                                                            disableElevation
                                                            disabled={
                                                                isSubmitting
                                                            }
                                                            fullWidth
                                                            onClick={
                                                                handleSubmit
                                                            }
                                                        >
                                                            登入
                                                        </SecondaryActionButton>
                                                    </Box>
                                                </form>
                                            )}
                                        </Formik>

                                        <Box
                                            width="100%"
                                            sx={{
                                                pt: "32px",
                                                display: "flex",
                                                justifyContent: "center",
                                                alignItems: "center",
                                            }}
                                        >
                                            <SubTitleLabel
                                                fontSize={"0.8vw"}
                                                sx={{
                                                    textDecoration: "underline",
                                                    cursor: "pointer",
                                                    "@media(maxWidth:991px)": {
                                                        fontSize: "13px",
                                                    },
                                                    "@media(maxWidth:479px)": {
                                                        fontSize: "13px",
                                                    },
                                                }}
                                            >
                                                遇到問題?
                                            </SubTitleLabel>
                                        </Box>
                                    </Stack>
                                </Card>
                            </Stack>
                        </Box>
                    </Box>
                </Box>
            )}
            <ContentDialog
                showDialog={showAlert}
                setShowDialog={setShowAlert}
                title={alertTitle.current}
                message={alertMessage.current}
                actionLabel="確定"
                actionHandler={() => setShowAlert(false)}
            />
        </>
    );
}
