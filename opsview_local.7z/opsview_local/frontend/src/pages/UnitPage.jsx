import React, { useEffect, useState } from "react";
import { Box, Skeleton } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import SearchBar from "../components/SearchBar/SearchBar";
import { HEADER_HEIGHT } from "../constants/appConstants";
import DateRangeSection from "../components/DateRangeSection";
import TopChartSection from "../components/unitPage/TopChartSection";
import useRetrievaWidget from "../components/useRetrievaWidget";
import ChartTabSection from "../components/unitPage/ChartTabSection";
import { loadFromLocalStorage } from "../utils/localStorageUtils";
import { backendAPI } from "../apis/services/backendAPI";

export default function UnitPage() {
    const theme = useTheme();
    const [currentUser, setCurrentUser] = useState({});
    const [fab, setFab] = useState({ name: "", id: null });
    const [stage, setStage] = useState({ name: "", id: null });
    const [units, setUnits] = useState([{ name: "", id: null }]);
    const [startDate, setStartDate] = useState();
    const [endDate, setEndDate] = useState();
    const [mode, setMode] = useState("week");
    const [cycleTimeComponent, setCycleTimeComponent] = useState(null);
    const [workTimeComponent, setWorkTimeComponent] = useState(null);
    const [idleTimeComponent, setIdleTimeComponent] = useState(null);
    const [cycleTimeList, setCycleTimeList] = useState([]);
    const [workTimeList, setWorkTimeList] = useState([]);
    const [idleTimeList, setIdleTimeList] = useState([]);
    const [loading, setLoading] = useState(false);
    const [hasData, setHasData] = useState(false);

    useEffect(() => {
        const user = loadFromLocalStorage("user");
        if (user) {
            setCurrentUser(user);
        } else {
            console.error("No user data found in localStorage.");
        }
    }, []);

    useEffect(() => {
        if (stage?.id !== null && units[0]?.id !== null) {
            fetchReprotData(
                startDate?.toISOString(),
                endDate?.toISOString(),
                fab?.id,
                stage?.id,
                units[0]?.id,
            );
        }
    }, [startDate, endDate, stage, units]);

    const fetchReprotData = async (startAt, endAt, fabId, stageId, unitId) => {
        setLoading(true);
        try {
            const response = await backendAPI.getUnitAnalysisReport({
                startAt,
                endAt,
                fabId,
                stageId,
                unitId,
            });
    
            if (response?.status !== undefined && response.data) {
                const data = response.data;
                setCycleTimeComponent(data.cycle_time_component || {});
                setWorkTimeComponent(data.work_time_component || {});
                setIdleTimeComponent(data.idle_time_component || {});
                setCycleTimeList(data.cycle_time_data_list || []);
                setWorkTimeList(data.work_time_data_list || []);
                setIdleTimeList(data.idle_time_data_list || []);
                setHasData(true);
            } else {
                setHasData(false);
            }
        } catch (err) {
            console.error("API Error", err);
            setHasData(false);
        } finally {
            setLoading(false);
        }
    };
    
    useRetrievaWidget({
        userId: "eric123",
        userName: "Eric",
        depno: "mamcc1",
        apiKey: "rMfCQfP90rOlFswQGkO96Va44oj2PT4Z",
        mode: "project",
        onApiResponse: (e) => {
            console.log("客製 Response:", e.detail);
        },
    });

    const ChartSkeleton = () => (
        <Skeleton
            variant="rectangular"
            animation="wave"
            height={310}
            sx={{ width: "100%", borderRadius: 2 }}
        />
    );

    return (
        <Box
            sx={{
                display: "flex",
                flexDirection: "column",
                gap: 1,
                height: `calc(100vh - ${HEADER_HEIGHT})`,
                overflow: "hidden",
                p: 3,
                pt: 5,
                width: "95%",
            }}
        >
            <SearchBar
                fab={fab}
                setFab={setFab}
                stage={stage}
                setStage={setStage}
                units={units}
                setUnits={setUnits}
                isMultiUnit={false}
                currentUser={currentUser}
            />

            {/* 日期選擇區塊 */}
            <DateRangeSection
                startDate={startDate}
                endDate={endDate}
                setStartDate={setStartDate}
                setEndDate={setEndDate}
                mode={mode}
                setMode={setMode}
            />

            {/* Cycle chart */}
            <Box
                sx={{
                    width: "100%",
                    pt: 3,
                    px: 3,
                    backgroundColor: theme.palette.background.paper1,
                    borderRadius: 2,
                }}
            >
                {loading ? (
                    <ChartSkeleton />
                ) : !hasData ? (
                    <Box sx={{ p: 5, textAlign: "center" }}>該區間無資料</Box>
                ) : (
                    <TopChartSection 
                        cycleTime={cycleTimeComponent}    
                        workTime={workTimeComponent}
                        idleTime={idleTimeComponent}
                    />
                )}
                    </Box>
            {/* Tab chart */}
            <Box
                sx={{
                    width: "100%",
                    pt: 3,
                    px: 3,
                    backgroundColor: theme.palette.background.paper1,
                    borderRadius: 2,
                }}
            >
                {loading ? (
                    <ChartSkeleton />
                ) : !hasData ? (
                    <Box sx={{ p: 5, textAlign: "center" }}>該區間無資料</Box>
                ) : (
                    <ChartTabSection 
                        cycleList={cycleTimeList}
                        workList={workTimeList}
                        idleList={idleTimeList}
                        unitId={units[0]?.id}
                    />
                )}
            </Box>
            <div id="rag-widget-root"></div>
        </Box>
    );
}
