import React from "react";
import { Box } from "@mui/material";
import TopChartSection from "../components/importStatus/TopChartSection";
import BottomTableSection from "../components/importStatus/BottomTableSection";
import { HEADER_HEIGHT } from "../constants/appConstants";

export default function ImportStatusPage() {
    return (
        <Box
            sx={{
                display: "flex",
                flexDirection: "column",
                gap: 1,
                height: `calc(100vh - ${HEADER_HEIGHT})`,
                overflow: "hidden",
                mt: 3,
                p: 3,
            }}
        >
            <Box sx={{ flex: "0 0 auto" }}>
                <TopChartSection />
            </Box>

            <Box
                sx={{
                    flex: "1 1 auto",
                    overflow: "auto",
                    minHeight: 0,
                }}
            >
                <BottomTableSection />
            </Box>
        </Box>
    );
}
