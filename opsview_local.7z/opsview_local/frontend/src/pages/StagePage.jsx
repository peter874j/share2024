import React, { useEffect, useMemo, useState } from "react";
import { Box, Skeleton } from "@mui/material";
import ReactECharts from "echarts-for-react";
import { useTheme } from "@mui/material/styles";
import SearchBar from "../components/SearchBar/SearchBar";
import { HEADER_HEIGHT } from "../constants/appConstants";
import DateRangeSection from "../components/DateRangeSection";
import { useChartToolbox } from "../components/useChartToolbox";
import useRetrievaWidget from "../components/useRetrievaWidget";
import { loadFromLocalStorage } from "../utils/localStorageUtils";
import { backendAPI } from "../apis/services/backendAPI";
import { handleDownloadCSV } from "../utils/handleDownloadCSV";

export default function StagePage() {
    const theme = useTheme();
    const [fab, setFab] = useState({ name: "", id: null });
    const [stage, setStage] = useState({ name: "", id: null });
    const [units, setUnits] = useState([{ name: "", id: null }]);
    const [startDate, setStartDate] = useState();
    const [endDate, setEndDate] = useState();
    const [mode, setMode] = useState("week");
    const [loading, setLoading] = useState(false);
    const [hasData, setHasData] = useState(false);
    const [boxData, setBoxData] = useState([]);
    const [unitNames, setUnitNames] = useState([]);
    const [lineBarData, setLineBarData] = useState([]);

    const user = loadFromLocalStorage("user");

    useEffect(() => {
        if (stage?.id !== null && units[0]?.id !== null) {
            fetchReprotData(
                startDate?.toISOString(),
                endDate?.toISOString(),
                fab?.id,
                stage?.id,
                units?.map((unit) => unit.id),
            );
        }
    }, [startDate, endDate, stage, units]);

    const fetchReprotData = async (startAt, endAt, fabId, stageId, unitIds) => {
        setLoading(true);
        try {
            const response = await backendAPI.getStageAnalysisReport({
                startAt,
                endAt,
                fabId,
                stageId,
                unitIds,
            });
    
            if (
                response?.status !== undefined &&
                Array.isArray(response.data) &&
                response.data.length > 0
            ) {
                const box = [];
                const units = [];
                const workData = [];
                const opIdleData = [];
                const eqIdleData = [];
                const baselineData = [];
    
                response.data.forEach((item) => {
                    const {
                        unit_name,
                        boxplot_worktime_stats,
                        avg_worktime_stats,
                    } = item;
                    units.push(unit_name);
                    box.push([
                        boxplot_worktime_stats.minimum,
                        boxplot_worktime_stats.q1,
                        boxplot_worktime_stats.median,
                        boxplot_worktime_stats.q3,
                        boxplot_worktime_stats.maximum,
                    ]);
                    workData.push(avg_worktime_stats.work);
                    opIdleData.push(avg_worktime_stats.op_idle);
                    eqIdleData.push(avg_worktime_stats.eq_idle);
                    baselineData.push(avg_worktime_stats.baseline);
                });
    
                setBoxData(box);
                setUnitNames(units);
                setLineBarData([
                    { 
                        name: "Work",
                        type: "bar",
                        stack: "total",
                        data: workData,
                        barMaxWidth: 50,
                    },
                    {
                        name: "OP_nonWork",
                        type: "bar",
                        stack: "total",
                        data: opIdleData,
                        barMaxWidth: 50,
                    },
                    {
                        name: "EQ_nonWork",
                        type: "bar",
                        stack: "total",
                        data: eqIdleData,
                        barMaxWidth: 50,
                    },
                    {
                        name: "Avg_Cycle",
                        type: "line",
                        data: baselineData,
                        lineStyle: { type: "dashed", color: "gray", width: 2 },
                        symbol: "none",
                    },
                ]);
                setHasData(true);
            } else {
                setHasData(false);
            }
        } catch (err) {
            console.error("API Error", err);
            setHasData(false);
        } finally {
            setLoading(false);
        }
    };    

    useRetrievaWidget({
        userId: "eric123",
        userName: "Eric",
        depno: "mamcc1",
        apiKey: "rMfCQfP90rOlFswQGkO96Va44oj2PT4Z",
        mode: "project",
        onApiResponse: (e) => {
            console.log("客製 Response:", e.detail);
        },
    });

    const boxPlotOption = useMemo(
        () => ({
            title: {
                text: "跨崗離群比較",
                left: "left",
                top: "top",
                textStyle: {
                    fontSize: "22px",
                    color: theme.palette.text.primary,
                    fontWeight: "bold",
                }
            },
            tooltip: {
                trigger: "item",
                formatter: (params) => {
                  const [ _, min, q1, median, q3, maximum ] = params.data;
                  return `
                    <b>${params.name}</b><br/>
                    Max: ${maximum}<br/>
                    Q3: ${q3}<br/>
                    Median: ${median}<br/>
                    Q1: ${q1}<br/>
                    Min: ${min}
                  `;
                },
            },
            xAxis: {
                type: "category",
                data: unitNames,
                axisLabel: { color: "#ccc" },
                axisLine: { lineStyle: { color: "#888" } },
            },
            yAxis: {
                type: "value",
                axisLabel: { color: "#ccc" },
                axisLine: { lineStyle: { color: "#888" } },
            },
            series: [
                {
                    name: "Box",
                    type: "boxplot",
                    data: boxData,
                },
            ],
            toolbox: useChartToolbox(handleDownloadCSV),
        }),
        [boxData, unitNames, theme],
    );    

    const lineBarOption = useMemo(
        () => ({
            title: {
                text: "跨崗作業週期組成比較",
                left: "left",
                top: "top",
                textStyle: {
                    fontSize: "22px",
                    color: theme.palette.text.primary,
                    fontWeight: "bold",
                }
            },
            tooltip: { trigger: "axis", axisPointer: { type: "shadow" } },
            legend: {
                bottom: 0,
                textStyle: {
                    color: "#ccc",
                },
            },
            xAxis: {
                type: "category",
                data: unitNames,
                axisLabel: { color: "#ccc" },
                axisLine: { lineStyle: { color: "#888" } },
            },
            yAxis: {
                type: "value",
                axisLabel: { color: "#ccc" },
                axisLine: { lineStyle: { color: "#888" } },
            },
            series: lineBarData,
            toolbox: useChartToolbox(handleDownloadCSV),
        }),
        [lineBarData, unitNames, theme],
    );    

    const ChartSkeleton = () => (
        <Skeleton
            variant="rectangular"
            animation="wave"
            height={310}
            sx={{ width: "100%", borderRadius: 2 }}
        />
    );

    return (
        <Box
            sx={{
                display: "flex",
                flexDirection: "column",
                gap: 2,
                height: `calc(100vh - ${HEADER_HEIGHT})`,
                overflow: "hidden",
                p: 3,
                pt: 5,
                width: "95%",
            }}
        >
            <SearchBar
                fab={fab}
                setFab={setFab}
                stage={stage}
                setStage={setStage}
                units={units}
                setUnits={setUnits}
                isMultiUnit={true}
                currentUser={user}
            />

            {/* 日期選擇區塊 */}
            <DateRangeSection
                startDate={startDate}
                endDate={endDate}
                setStartDate={setStartDate}
                setEndDate={setEndDate}
                mode={mode}
                setMode={setMode}
            />

            {/* Chart 1 - Boxplot */}
            <Box
                sx={{
                    width: "100%",
                    pt: 3,
                    px: 3,
                    backgroundColor: theme.palette.background.paper1,
                    borderRadius: 2,
                }}
            >
                {loading ? (
                    <ChartSkeleton />
                ) : !hasData ? (
                    <Box sx={{ p: 5, textAlign: "center" }}>該區間無資料</Box>
                ) : (
                    <ReactECharts
                        option={boxPlotOption}
                        style={{ width: "100%", height: 310 }}
                    />
                )}
            </Box>

            {/* Chart 2 - Line + Bar */}
            <Box
                sx={{
                    width: "100%",
                    pt: 3,
                    px: 3,
                    backgroundColor: theme.palette.background.paper1,
                    borderRadius: 2,
                }}
            >
                {loading ? (
                    <ChartSkeleton />
                ) : !hasData ? (
                    <Box sx={{ p: 5, textAlign: "center" }}>該區間無資料</Box>
                ) : (
                    <ReactECharts
                        option={lineBarOption}
                        style={{ width: "100%", height: 310 }}
                    />
                )}
            </Box>
            <div id="rag-widget-root"></div>
        </Box>
    );
}
