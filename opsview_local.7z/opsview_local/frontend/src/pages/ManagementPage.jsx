import { useEffect, useState } from "react";
import SearchBar from "../components/SearchBar/SearchBar";
import { Box } from "@mui/material";
import PermissionTable from "../components/ManagementPage/PermissionTable";
import { backendAPI } from "../apis/services/backendAPI";
import { saveToLocalStorage } from "../utils/localStorageUtils";
import { NotificationService } from "../components/NotificationService";

export default function ManagementPage() {
    const [currentUser, setCurrentUser] = useState({}); // 當前使用者資訊
    const [fab, setFab] = useState({
        name: "",
        id: null,
    }); // 選擇的廠區
    const [permissions, setPermissions] = useState([]); // 權限列表

    // 向後端更新用戶權限, 並重新取得用戶列表
    const updatePermissions = (userId, role) => {
        backendAPI
            .updateUserRole(userId, role)
            .then((resp) => {
                if (!resp.status) {
                    throw new Error(resp);
                }
                // 更新權限列表
                setPermissions((prevPermissions) =>
                    prevPermissions.map((permission) =>
                        permission.id === userId
                            ? { ...permission, role: role }
                            : permission,
                    ),
                );
                NotificationService.handleSuccess("權限更新成功");
            })
            .catch((error) => {
                console.error("權限更新失敗: ", error);
                NotificationService.handleError(
                    `權限更新失敗 (User ID: ${userId}, Role: ${role}): ${error.message}`,
                );
            });
    };

    // 頁面刷新, 呼叫 API 取得當前使用者資訊, 並更新至 localStorage
    useEffect(() => {
        backendAPI
            .getUserInfo()
            .then((resp) => {
                const user = resp.data;
                saveToLocalStorage("user", resp.data);
                setCurrentUser(user);
                // console.log("當前使用者:", user);
            })
            .catch((error) => {
                console.error("載入使用者資訊失敗:", error);
            });
    }, []);

    useEffect(() => {
        const fabName = fab.name;
        if (fabName) {
            backendAPI
                .getPermissions(fabName)
                .then((resp) => {
                    setPermissions(resp.data);
                    console.log(`載入 ${fabName} 用戶列表完成: `, resp.data);
                })
                .catch((error) => {
                    console.error("載入用戶列表失敗: ", error);
                    NotificationService.handleError(
                        `載入  ${fabName}  用戶列表失敗: ${error.message}`,
                    );
                });
        }
    }, [fab?.name]);

    return (
        <Box
            sx={{
                display: "flex",
                flexDirection: "column",
                mt: 3,
                p: 3,
            }}
        >
            <SearchBar
                fab={fab}
                setFab={setFab}
                currentUser={currentUser}
            ></SearchBar>
            <Box
                sx={{
                    marginTop: 1,
                    display: "flex",
                    justifyContent: "center",
                }}
            >
                <PermissionTable
                    permissions={permissions}
                    currentUser={currentUser}
                    updatePermissions={updatePermissions}
                ></PermissionTable>
            </Box>
        </Box>
    );
}
