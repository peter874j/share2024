import React, { useContext, useEffect, useState } from "react";
import { Outlet, useLocation, useNavigate } from "react-router-dom";
import { styled, useTheme } from "@mui/material/styles";
import { Box, AppBar, Toolbar } from "@mui/material";
import Sidebar from "../components/sideBar/SideBar";
import {
    COLLAPSED_SIDE_BAR_WIDTH,
    HEADER_HEIGHT,
    SIDE_BAR_WIDTH,
} from "../constants/appConstants";
import { UserContext } from "../utils/userContext";
import Header from "../components/Header";
import sideBarItem from "../components/ListItem";
import { loadFromLocalStorage } from "../utils/localStorageUtils";
import { backendAPI } from "../apis/services/backendAPI";

const Main = styled("main", { shouldForwardProp: (prop) => prop !== "open" })(
    ({ theme, open }) => ({
        flexGrow: 1,
        px: theme.spacing(3),
        transition: theme.transitions.create(["margin", "width"], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
        marginLeft: open
            ? `${SIDE_BAR_WIDTH}px`
            : `${COLLAPSED_SIDE_BAR_WIDTH}px`,
        [theme.breakpoints.down(768)]: {
            marginLeft: "0px",
            width: "100%",
        },
        width: open
            ? `calc(100% - ${SIDE_BAR_WIDTH}px)`
            : `calc(100% - ${COLLAPSED_SIDE_BAR_WIDTH}px)`,
        overflowY: "hidden",
    }),
);

export const AppBarStyled = styled(AppBar, {
    shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
    transition: theme.transitions.create(["margin", "width"], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
    }),
    width: open
        ? `calc(100% - ${SIDE_BAR_WIDTH}px)`
        : `calc(100% - ${COLLAPSED_SIDE_BAR_WIDTH}px)`,
    marginLeft: open ? `${SIDE_BAR_WIDTH}px` : `${COLLAPSED_SIDE_BAR_WIDTH}px`,
    [theme.breakpoints.down(768)]: {
        width: "100%",
        marginLeft: "0px",
    },
    height: `${HEADER_HEIGHT}px`,
    zIndex: theme.zIndex.drawer - 1,
    bgcolor: theme.palette.primary.light,
}));

export default function MainPage() {
    const theme = useTheme();
    const navigate = useNavigate();
    const { sideBarOpen, setSideBarOpen } =
        useContext(UserContext);
    const [updateTrigger, setUpdateTrigger] = useState(0);
    const [loading, setLoading] = useState(true);
    const location = useLocation();
    const currentPath = location.pathname;
    const user = loadFromLocalStorage("user");

    useEffect(() => {
        setLoading(true);
        if (user === null) {
            setLoading(false);
            navigate("/login");
        } else {
            setLoading(false);
        }
    }, [updateTrigger]);

    const currentItem = sideBarItem.items.find((item) =>
        currentPath === item.url
    );
    
    /**
     * Toggle the visibility of the sidebar.
     */
    const handleToggleSidebar = () => {
        setSideBarOpen((prev) => !prev);
    };

    return (
        <>
            {loading ? (
                <></>
            ) : (
                <>
                    {currentItem && (
                        <AppBarStyled
                            position="fixed"
                            open={sideBarOpen}
                            elevation={0}
                            sx={{
                                bgcolor: (theme) =>
                                    theme.palette.background.default,
                            }}
                        >
                            <Toolbar>
                                <Header title={currentItem?.title} />
                            </Toolbar>
                        </AppBarStyled>
                    )}

                    <Box
                        sx={{
                            width: sideBarOpen
                                ? SIDE_BAR_WIDTH
                                : COLLAPSED_SIDE_BAR_WIDTH,
                            transition: theme.transitions.create("width", {
                                easing: theme.transitions.easing.sharp,
                                duration:
                                    theme.transitions.duration.leavingScreen,
                            }),
                        }}
                    >
                        <Sidebar />
                    </Box>

                    <Main open={sideBarOpen}>
                        <Outlet />
                    </Main>
                </>
            )}
        </>
    );
}
