import { Box } from "@mui/material";
import { useEffect, useRef, useState } from "react";
import EquipTable from "../components/EquipmentPage/EquipTable";
import FilterBar from "../components/EquipmentPage/FilterBar";
import SearchBar from "../components/SearchBar/SearchBar";
import { backendAPI } from "../apis/services/backendAPI";
import { loadFromLocalStorage } from "../utils/localStorageUtils";

function getTotalUnitSet(stageUnit) {
    const totalUnitSet = new Set();
    for (const unitSet of Object.values(stageUnit)) {
        for (const unit of unitSet) {
            totalUnitSet.add(unit);
        }
    }
    return totalUnitSet;
}

export default function EquipmentPage() {
    const [currentUser, setCurrentUser] = useState({}); // 當前使用者資訊
    const [fab, setFab] = useState({
        name: "",
        id: null,
    }); // 選擇的廠區

    const [equipDatas, setEquipDatas] = useState([]);
    const preSelectStages = useRef([]); // 前次選擇的站點
    const stageUnit = useRef({}); // 站點對應崗位

    // 載入設備資料
    const loadEquipDatas = () => {
        if (fab?.id) {
            backendAPI
                .getEquipData(fab.id)
                .then((resp) => {
                    // 資料前處理
                    const processedData = resp.data.map((data) => {
                        return {
                            pcId: data.id,
                            pcName: data.name,
                            pcIp: data.ip,
                            pcStatus: data.status,
                            cameras: data.cams.map((cam) => {
                                const unit = cam.units;
                                return {
                                    camId: cam.id,
                                    stage: unit ? unit.stage.name : "(未綁定)",
                                    unit: unit ? unit.name : "(未綁定)",
                                    camIp: cam.ip,
                                    camStatus: cam.status,
                                    aiServicePort: cam.port,
                                };
                            }),
                        };
                    });
                    setEquipDatas(processedData);
                    console.log(
                        `載入 ${fab.name} 設備資料完成: `,
                        processedData,
                    );
                })
                .catch((error) => {
                    console.error(`載入 ${fab.name} 設備資料失敗: `, error);
                });
        }
    };

    // 初始化設備資料
    useEffect(loadEquipDatas, [fab.name]);

    const [filterOptions, setFilterOptions] = useState({
        stage: [],
        unit: [],
        pcStatus: [],
        camStatus: [],
    });

    const [filterSelects, setFilterSelects] = useState({
        stage: [],
        unit: [],
        pcStatus: [],
        camStatus: [],
    });

    // 統計篩選選項, 並建立站點崗位對應表
    function getFilterOptions(equipDatas) {
        const stageSet = new Set();
        const updateStageUnit = {};

        for (const equipData of equipDatas) {
            for (const camera of equipData.cameras) {
                const stage = camera.stage;
                const unit = camera.unit;
                stageSet.add(stage);

                // 將崗位加到對應的站點
                if (!Object.keys(updateStageUnit).includes(stage)) {
                    updateStageUnit[stage] = new Set();
                }
                updateStageUnit[stage].add(unit);
            }
        }
        stageUnit.current = updateStageUnit;
        return {
            stage: [...stageSet],
            unit: [],
            pcStatus: ["Online", "Offline"],
            camStatus: ["Online", "Offline"],
        };
    }

    useEffect(() => {
        const user = loadFromLocalStorage("user");
        if (user) {
            setCurrentUser(user);
        } else {
            console.error("No user data found in localStorage.");
        }
    }, []);

    // 設備狀態資料更新時, 更新篩選選項
    useEffect(() => {
        let filterOptions = getFilterOptions(equipDatas);
        filterOptions = {
            ...filterOptions,
            unit: [...getTotalUnitSet(stageUnit.current)],
        };
        setFilterOptions(filterOptions);
        setFilterSelects(filterOptions); // 預設全部顯示
    }, [equipDatas]);

    // 站點篩選更新時, 更新崗位選項
    useEffect(() => {
        let filterOptions = getFilterOptions(equipDatas);
        const unitOptions = [];
        // 僅顯示已選擇站點對應的崗位
        for (const selectStage of filterSelects.stage) {
            unitOptions.push(...stageUnit.current[selectStage]);
        }
        filterOptions = {
            ...filterOptions,
            unit: unitOptions,
        };
        setFilterOptions(filterOptions);

        // 新選擇站點, 全選底下的所有崗位
        const newStages = filterSelects.stage.filter(
            (stage) => !preSelectStages.current.includes(stage),
        );
        // 要用 Set 新增元素, 避免與預設全選邏輯衝突
        const filterSelectsUnit = new Set(filterSelects.unit);
        for (const newStage of newStages) {
            stageUnit.current[newStage].forEach((addUnit) =>
                filterSelectsUnit.add(addUnit),
            );
        }

        // 移除沒有選擇的站點, 其底下的所有崗位
        const validSelectsUnit = [...filterSelectsUnit].filter((selectUnit) =>
            filterOptions.unit.includes(selectUnit),
        );
        setFilterSelects({ ...filterSelects, unit: validSelectsUnit }); // 更新選擇的崗位
        preSelectStages.current = filterSelects.stage; // 更新前次選擇的站點
    }, [filterSelects.stage]);

    return (
        <Box
            sx={{
                mt: 3,
                p: 3,
            }}
        >
            <SearchBar
                fab={fab}
                setFab={setFab}
                currentUser={currentUser}
            ></SearchBar>
            <Box
                sx={{
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                }}
            >
                <FilterBar
                    filterOptions={filterOptions}
                    filterSelects={filterSelects}
                    setFilterSelects={setFilterSelects}
                />
                <EquipTable
                    fab={fab}
                    currentUser={currentUser}
                    equipDatas={equipDatas}
                    filterSelects={filterSelects}
                    setEquipDatas={setEquipDatas}
                    loadEquipDatas={loadEquipDatas}
                />
            </Box>
        </Box>
    );
}
