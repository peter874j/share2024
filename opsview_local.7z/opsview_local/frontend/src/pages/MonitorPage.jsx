import { useEffect, useRef, useState } from "react";
import { Box, CardMedia, Grid } from "@mui/material";

import SearchBar from "../components/SearchBar/SearchBar";
import CameraThumbnail from "../components/MonitorPage/CameraThumbnail";
import ContentDialog from "../components/ContentDialog";
import { loadFromLocalStorage } from "../utils/localStorageUtils";
import { backendAPI } from "../apis/services/backendAPI";

export default function MonitorPage() {
    const [currentUser, setCurrentUser] = useState({}); // 當前使用者資訊
    const [fab, setFab] = useState({ name: "", id: null }); // 選擇的廠區
    const [stage, setStage] = useState({ name: "", id: null }); // 選擇的站點
    const [units, setUnits] = useState([{ name: "", id: null }]); // 選擇的崗位列表

    const [dialogOpen, setDialogOpen] = useState(false); // 彈出視窗開啟狀態
    const playUnitIdRef = useRef(null); // 播放中的崗位
    const [streamUrls, setStreamUrls] = useState({}); // 攝影機串流網址

    useEffect(() => {
        const user = loadFromLocalStorage("user");
        if (user) {
            setCurrentUser(user);
        } else {
            console.error("No user data found in localStorage.");
        }
    }, []);

    useEffect(() => {
        if (!fab?.id || !stage?.id || units.length === 0) return;
        // 清空舊的串流 URL
        setStreamUrls({});
        units.forEach((unit) => {
            if (unit.id) {
                backendAPI
                    .getStreamUrls(fab.id, stage.id, [unit.id])
                    .then((resp) => {
                        if (!resp.status) {
                            throw new Error(resp);
                        }
                        if (resp.data.length === 0) {
                            throw new Error(`No stream URL found.`);
                        }

                        // 理論上是每個崗位只會有一顆鏡頭
                        const streamUrl = resp.data[0].stream_det_uri;

                        setStreamUrls((prevUrls) => ({
                            ...prevUrls,
                            [unit.id]: streamUrl,
                        }));
                    })
                    .catch((error) => {
                        console.error(
                            `Error fetching stream URL for ${unit.name}, unitId ${unit.id}:`,
                            error,
                        );
                        setStreamUrls((prevUrls) => ({
                            ...prevUrls,
                            [unit.id]: null,
                        }));
                    });
            }
        });
    }, [fab?.id, stage?.id, units]);

    return (
        <div>
            <Box sx={{ mt: 3, p: 3 }}>
                <SearchBar
                    fab={fab}
                    setFab={setFab}
                    stage={stage}
                    setStage={setStage}
                    units={units}
                    setUnits={setUnits}
                    isMultiUnit={true}
                    currentUser={currentUser}
                />
                {/* 攝影機縮圖 */}
                <Box sx={{ height: "80vh" }}>
                    <Grid
                        container
                        spacing={3}
                        sx={{
                            maxHeight: "100%",
                            paddingRight: 2,
                            overflow: "auto",
                        }}
                    >
                        {units
                            .filter((unit) => unit.id && unit.name)
                            .map((unit) => (
                                <Grid
                                    key={unit.id}
                                    size={{ xs: 12, md: 6, lg: 4 }}
                                >
                                    <CameraThumbnail
                                        unit={unit.name}
                                        handleDialogOpen={() => {
                                            playUnitIdRef.current = unit;
                                            setDialogOpen(true);
                                        }}
                                        url={streamUrls[unit.id]}
                                    />
                                </Grid>
                            ))}
                    </Grid>
                </Box>
            </Box>

            {/* 彈窗顯示攝影機畫面 */}
            <ContentDialog
                maxWidth="100%"
                showDialog={dialogOpen}
                setShowDialog={setDialogOpen}
                title={`攝影機畫面：${playUnitIdRef.current?.name}`}
                content={
                    <CardMedia
                        component="img"
                        src={
                            dialogOpen
                                ? streamUrls[playUnitIdRef.current?.id]
                                : null
                        } // 當彈出視窗關閉時釋放串流資源
                        title={streamUrls[playUnitIdRef.current?.id]}
                        sx={{ maxHeight: "70vh", objectFit: "contain" }}
                    ></CardMedia>
                }
            ></ContentDialog>
        </div>
    );
}
