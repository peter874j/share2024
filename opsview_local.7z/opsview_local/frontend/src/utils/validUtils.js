export const isValidIp = (ipStr) => {
    const ipRegex =
        /^(25[0-5]|2[0-4][0-9]|1?[0-9]{1,2})(\.(25[0-5]|2[0-4][0-9]|1?[0-9]{1,2})){3}$/;
    return ipRegex.test(ipStr);
};

export const isValidPort = (portStr) => {
    const portipRegex = /^\d+$/;
    if (!portipRegex.test(portStr)) {
        return false;
    }

    const port = Number(portStr);
    return port >= 0 && port <= 65535;
};
