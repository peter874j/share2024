/**
 * 將 UTC 日期時間轉換為使用者的時區
 * @param {string} utcDateString - UTC 時間字串 (例如: "2025-08-04T10:29:42.850000Z")
 * @param {string} [timeZone] - 使用者的時區，預設為瀏覽器的時區
 * @returns {string} - 轉換後的日期時間字串
 */
export const convertUTCToUserTimezone = (
    utcDateString,
    timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone,
) => {
    // 確保輸入是有效的 UTC 字串
    const utcDate = new Date(utcDateString);

    if (isNaN(utcDate)) {
        return "";
    }

    // 使用 Intl.DateTimeFormat 格式化日期
    const formatter = new Intl.DateTimeFormat("en-US", {
        timeZone,
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false, // 24小時制
    });

    // 格式化並返回結果
    const parts = formatter.formatToParts(utcDate);
    const formattedDate = parts.map((part) => part.value).join("");

    return formattedDate;
};
