const sortFunc = (a, b) => {
    // 拆分字串為多段字母與數字
    const extractParts = (str) => {
        const regex = /([a-zA-Z_]+|\d+)/g; // 匹配字母段或數字段
        const parts = str.match(regex) || [];
        return parts.map((part) => (isNaN(part) ? part : parseInt(part, 10))); // 將數字轉為整數
    };

    const aParts = extractParts(a);
    const bParts = extractParts(b);

    // 逐段比較
    for (let i = 0; i < Math.max(aParts.length, bParts.length); i++) {
        const aPart = aParts[i] || ""; // 若無值則視為空字串
        const bPart = bParts[i] || "";

        if (typeof aPart === "number" && typeof bPart === "number") {
            // 數字比較
            if (aPart !== bPart) {
                return aPart - bPart;
            }
        } else {
            // 字串比較（忽略大小寫）
            const comparison = aPart
                .toString()
                .toLowerCase()
                .localeCompare(bPart.toString().toLowerCase());
            if (comparison !== 0) {
                return comparison;
            }
        }
    }

    return 0; // 若完全相同則返回 0
};

export { sortFunc };
