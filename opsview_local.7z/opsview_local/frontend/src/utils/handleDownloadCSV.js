export const handleDownloadCSV = (echartsInstance) => {
    const option = echartsInstance.getOption();
    const seriesList = option.series;
    const chartType = seriesList[0]?.type;

    if (chartType === "pie") {
        downloadPieCSV(seriesList);
    } else if (chartType === "boxplot") {
        downloadBoxplotCSV(seriesList);
    } else if (["bar", "line"].includes(chartType)) {
        downloadBarOrLineCSV(option);
    } else {
        alert("不支援此圖表類型的 CSV 匯出");
    }
};

// 圓餅圖
const downloadPieCSV = (seriesList) => {
    const series = seriesList[0];
    const rows = [["Label", "Value"]];

    series.data.forEach((item) => {
        rows.push([item.name, item.value]);
    });

    triggerCSVDownload(rows, "pie_chart.csv");
};

// 盒鬚圖
const downloadBoxplotCSV = (seriesList) => {
    const series = seriesList[0];
    const rows = [["Index", "Min", "Q1", "Median", "Q3", "Max"]];

    series.data.forEach((item, idx) => {
        rows.push([`Box ${idx + 1}`, ...item]);
    });

    triggerCSVDownload(rows, "boxplot_chart.csv");
};

// 直條圖 / 折線圖 / 推疊圖
const downloadBarOrLineCSV = (option) => {
    const xAxisData = option.xAxis?.[0]?.data || [];
    const seriesList = option.series;

    const headers = ["X", ...seriesList.map((s) => s.name)];
    const rows = [headers];

    const rowCount = Math.max(...seriesList.map((s) => s.data?.length));

    for (let i = 0; i < rowCount; i++) {
        const xLabel = xAxisData[i] ?? `Row ${i + 1}`;
        const row = [xLabel];

        for (const s of seriesList) {
            const d = s.data[i];
            if (typeof d === "object") {
                row.push(d?.value ?? d?.name ?? JSON.stringify(d));
            } else {
                row.push(d ?? "");
            }
        }

        rows.push(row);
    }

    triggerCSVDownload(rows, "bar_line_chart.csv");
};

// 共用下載函數
const triggerCSVDownload = (rows, fileName = "chart.csv") => {
    const csv = rows.map((r) => r.join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], {
        type: "text/csv;charset=utf-8;",
    });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = fileName;
    a.click();
};
