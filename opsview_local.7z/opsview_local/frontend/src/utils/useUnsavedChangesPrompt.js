import { useEffect } from "react";
import { useBlocker, useBeforeUnload } from "react-router-dom";

export function useUnsavedChangesPrompt(when) {
    const blocker = useBlocker(when);

    useEffect(() => {
        if (blocker.state === "blocked") {
            const ok = window.confirm("尚有未儲存變更，確定要離開嗎？");
            ok ? blocker.proceed() : blocker.reset();
        }
    }, [blocker]);

    useBeforeUnload((e) => {
        if (!when) return;
        e.preventDefault();
        e.returnValue = "";
    });
}
