const getEnv = (key, fallback = "") => {
    if (process.env.NODE_ENV === "development") {
        return process.env[`REACT_APP_${key}`] || fallback;
    } else {
        return window?.env?.[`REACT_APP_${key}`] || fallback;
    }
};

export default getEnv;