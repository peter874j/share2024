import { NotificationService } from "../components/NotificationService";

export const checkOnlineStatus = () => {
    if (!navigator.onLine) {
        const errorMessage = "您當前處於離線狀態，請檢查您的網路連線！";
        NotificationService.handleError(errorMessage);
        return Promise.reject(new Error(errorMessage));
    }
    return Promise.resolve();
};
