/**
 * Save an object to localStorage under a specified key.
 * @param {string} key - The key under which the object will be stored.
 * @param {Object} obj - The object to save to localStorage.
 */
export const saveToLocalStorage = (key, obj) => {
    try {
        const serializedObj = JSON.stringify(obj);
        localStorage.setItem(key, serializedObj);
    } catch (error) {
        console.error("Error saving to localStorage", error);
    }
};

/**
 * Load an object from localStorage by its key.
 * @param {string} key - The key of the object to load from localStorage.
 * @returns {Object|null} The parsed object from localStorage, or null if not found or an error occurs.
 */
export const loadFromLocalStorage = (key) => {
    try {
        const serializedObj = localStorage.getItem(key);
        if (serializedObj === null) {
            return null;
        }
        return JSON.parse(serializedObj);
    } catch (error) {
        console.error("Error loading from localStorage", error);
        return null;
    }
};
