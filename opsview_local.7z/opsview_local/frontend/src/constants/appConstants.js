export const getDesignTokens = (isDarkMode) => ({
    palette: {
        mode: isDarkMode ? "dark" : "light",
        primary: {
            main: isDarkMode ? "#E0E0E0" : "#4A4A4A",
        },
        secondary: {
            main: isDarkMode ? "#d39361" : "#a5b8c5",
        },
        background: {
            default: isDarkMode ? "#2E2828" : "#f6f5f0",
            paper1: isDarkMode
                ? "rgba(112, 144, 176, 0.08)"
                : "rgba(204, 204, 204, 0.55)",
            paper2: isDarkMode ? "#645d66" : "#645d66",
            drawer: isDarkMode ? "#333033" : "#E0E0E0",
            dialog: isDarkMode ? "#4A4A4A" : "#B0B0B0",
            primaryButton: isDarkMode ? "#E0E0E0" : "#4A4A4A",
            secondaryButton: isDarkMode ? "#696969" : "#8A8A8A",
            iconButton: isDarkMode ? "#333033" : "#cccccc",
            tab: isDarkMode ? "#B0B0B0" : "#5A5A5A",
            histroySelected: isDarkMode
                ? "rgba(74, 74, 74, 0.5)"
                : "rgba(204, 204, 204, 0.7)",
            copyCode: "#424242",
            divider: isDarkMode ? "rgba(112, 144, 176, 0.4)" : "#333033",
        },
        text: {
            primary: isDarkMode ? "#EDEDED" : "#4A4A4A",
            secondary: isDarkMode ? "#d7d7d7" : "#2E2820",
            sideBarHeader: isDarkMode ? "#F0F0F0" : "#4A4A4A",
            primaryButton: isDarkMode ? "#4A4A4A" : "#E0E0E0",
            secondaryButton: isDarkMode ? "#F0F0F0" : "#F0F0F0",
            switch: isDarkMode ? "#EDEDED" : "#bdbdbd",
        },
        icon: {
            default: isDarkMode ? "#E0E0E0" : "#4A4A4A",
            hover: isDarkMode ? "#E0E0E0" : "#4A4A4A",
            emoji1: isDarkMode ? "#7AB8C5" : "#4D715A",
            emoji2: isDarkMode ? "#D9C699" : "#B3757A",
            emoji3: isDarkMode ? "#BFA0B3" : "#A66E42",
            emoji4: isDarkMode ? "#8FA699" : "#486A83",
        },
        avatar: {
            default: isDarkMode ? "#486a83" : "#618fa3",
            logo: isDarkMode ? "#ebebeb" : "#6d899b",
        },
    },
    typography: {
        fontFamily: '"Roboto","Helvetica",sans-serif',
        fontWeightLight: 100,
        fontWeightRegular: 400,
        fontWeightMedium: 500,
        fontWeightBold: 900,
    },
});

export const COLLAPSED_SIDE_BAR_WIDTH = 80;
export const HEADER_HEIGHT = 50;
export const SIDE_BAR_WIDTH = 270;
export const SERVER_ERROR = "server-error";