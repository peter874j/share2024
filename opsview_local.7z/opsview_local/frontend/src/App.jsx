import "@fontsource/roboto";
import { useMemo, useState, useEffect } from "react";
import {
  createHashRouter,
  RouterProvider,
  Navigate,
} from "react-router-dom";
import { ToastContainer } from "react-toastify";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import CssBaseline from "@mui/material/CssBaseline";
import { getDesignTokens } from "./constants/appConstants";
import { UserContext } from "./utils/userContext";
import Loading from "./components/Loading";
import MainPage from "./pages/MainPage";
import ImportStatusPage from "./pages/ImportStatusPage";
import LoginPage from "./pages/LoginPage";
import MonitorPage from "./pages/MonitorPage";
import StagePage from "./pages/StagePage";
import UnitPage from "./pages/UnitPage";
import EquipmentPage from "./pages/EquipmentPage";
import ManagementPage from "./pages/ManagementPage";
import ManageSection from "./components/importStatus/management/ManageSection";
import LandingPage from "./pages/LandingPage";

function App() {
  /** ----------- UI State ----------- **/
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const savedMode = localStorage.getItem("isDarkMode");
    return savedMode ? JSON.parse(savedMode) : true;
});
  const [sideBarOpen, setSideBarOpen] = useState(true);
  const [loading, setLoading] = useState(false);

  /** ----------- Theme ----------- **/
  const theme = useMemo(
    () => createTheme(getDesignTokens(isDarkMode)),
    [isDarkMode],
  );

  useEffect(() => {
    localStorage.setItem("isDarkMode", JSON.stringify(isDarkMode));
  }, [isDarkMode]);

  /** ----------- Context Value ----------- **/
  const ctxValue = useMemo(
    () => ({
      loading,
      setLoading,
      isDarkMode,
      setIsDarkMode,
      sideBarOpen,
      setSideBarOpen,
    }),
    [loading, isDarkMode, sideBarOpen],
  );

  /** ----------- Data Router ----------- **/
  const router = useMemo(
    () =>
      createHashRouter([
        { path: "/", element: <LandingPage /> },

        {
          path: "/h",
          element: <MainPage />,
          children: [
            { index: true, element: <ImportStatusPage /> }, 
            { path: "unit/:unitId", element: <ManageSection /> },
            { path: "stage", element: <StagePage /> },             
            { path: "unit", element: <UnitPage /> },
            { path: "monitor", element: <MonitorPage /> },
            { path: "equipment", element: <EquipmentPage /> },
            { path: "management", element: <ManagementPage /> },
          ],
        },

        { path: "/login", element: <LoginPage /> },
        { path: "*", element: <Navigate to="/h" replace /> },
      ]),
    [],
  );

  /** ----------- Render ----------- **/
  return (
    <ThemeProvider theme={theme}>
      <UserContext.Provider value={ctxValue}>
        <CssBaseline/>
        <ToastContainer/>
        <RouterProvider
          router={router}
          fallbackElement={<Loading enabled />}
        />

        <Loading enabled={loading} />
      </UserContext.Provider>
    </ThemeProvider>
  );
}

export default App;
