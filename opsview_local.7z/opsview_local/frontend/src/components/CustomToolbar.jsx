import React from "react";
import { Toolbar } from "@mui/x-data-grid";
import { TextField, InputAdornment } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import CancelIcon from "@mui/icons-material/Cancel";
import IconButton from "@mui/material/IconButton";

const CustomToolbar = ({ searchInput, setSearchInput }) => {
    const handleChange = (e) => setSearchInput(e.target.value);

    const handleClear = () => setSearchInput("");

    return (
        <Toolbar sx={{ display: "flex", justifyContent: "flex-end" }}>
            <TextField
                size="small"
                placeholder="Search..."
                value={searchInput}
                onChange={handleChange}
                sx={{ width: 260 }}
                InputProps={{
                    startAdornment: (
                        <InputAdornment position="start">
                            <SearchIcon fontSize="small" />
                        </InputAdornment>
                    ),
                    endAdornment: searchInput ? (
                        <InputAdornment position="end">
                            <IconButton size="small" onClick={handleClear}>
                                <CancelIcon fontSize="small" />
                            </IconButton>
                        </InputAdornment>
                    ) : null,
                }}
            />
        </Toolbar>
    );
};

export default CustomToolbar;
