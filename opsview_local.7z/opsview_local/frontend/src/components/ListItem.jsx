
import RestoreOutlinedIcon from "@mui/icons-material/RestoreOutlined";
import WebhookOutlinedIcon from "@mui/icons-material/WebhookOutlined";
import HelpOutlineIcon from "@mui/icons-material/HelpOutline";
import LogoutIcon from "@mui/icons-material/Logout";
import ManageAccountsIcon from "@mui/icons-material/ManageAccounts";
import IosShareOutlinedIcon from "@mui/icons-material/IosShareOutlined";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import DeleteForeverOutlinedIcon from "@mui/icons-material/DeleteForeverOutlined";
import ArchiveOutlinedIcon from "@mui/icons-material/ArchiveOutlined";
import { MenuBookOutlined } from "@mui/icons-material";
import { Groups2Rounded, SettingsApplicationsRounded, RemoveRedEyeRounded, CommentOutlined, NewReleasesOutlined, DonutSmallRounded, CandlestickChartRounded, StackedLineChartRounded } from "@mui/icons-material";

const iconDocument = <DonutSmallRounded />;
const iconStage = <CandlestickChartRounded />;
const iconUnit = <StackedLineChartRounded />;
const iconMonitor = <RemoveRedEyeRounded />;
const iconEquipment = <SettingsApplicationsRounded />;
const iconManagement = <Groups2Rounded />;
const iconHistory = <RestoreOutlinedIcon />;
const iconAPI = <WebhookOutlinedIcon />;

const importStatus = {
    id: "import",
    title: "導入崗位總覽",
    icon: iconDocument,
    url: "/h",
};

const stage = {
    id: "stage",
    title: "同站點分析",
    icon: iconStage,
    url: "/h/stage",
};

const unit = {
    id: "unit",
    title: "同崗位分析",
    icon: iconUnit,
    url: "/h/unit",
};

const monitor = {
    id: "monitor",
    title: "即時畫面",
    icon: iconMonitor,
    url: "/h/monitor",
};

const equipment = {
    id: "equipment",
    title: "設備管理",
    icon: iconEquipment,
    url: "/h/equipment",
};

const management = {
    id: "management",
    title: "權限管理",
    icon: iconManagement,
    url: "/h/management",
};

const sideBarItem = {
    items: [importStatus, stage, unit, monitor, equipment, management],
};

export default sideBarItem;

export const history = {
    id: "history",
    title: "History",
    icon: iconHistory,
    url: "/home",
};

const iconHelp = <HelpOutlineIcon />;
const iconLogout = <LogoutIcon />;
const iconAdvancedSetting = <ManageAccountsIcon />;
const iconArchived = <CommentOutlined />;
const iconNewRelease = <NewReleasesOutlined />;
const iconManual = <MenuBookOutlined />;

const help = {
    id: "help",
    title: "Help & FAQ",
    icon: iconHelp,
    url: "/home",
};

const advanced = {
    id: "advanced",
    title: "Advanced Settings",
    icon: iconAdvancedSetting,
    url: "/home",
};

const updated = {
    id: "updated",
    title: "Release Updates",
    icon: iconNewRelease,
    url: "/home/updates",
};

const manual = {
    id: "manual",
    title: "User Manual",
    icon: iconManual,
    url: "http://10.96.152.117:4001/-jvzuVYAaMg",
}

const logout = {
    id: "logout",
    title: "Logout",
    icon: iconLogout,
    url: "/login",
};

export const settingItem = {
    items: [advanced, updated, manual, logout],
};

const iconShare = <IosShareOutlinedIcon />;
const iconEdit = <EditOutlinedIcon />;
const iconArchive = <ArchiveOutlinedIcon />;
const iconDelete = <DeleteForeverOutlinedIcon />;

const share = {
    id: "share",
    title: "Share",
    icon: iconShare,
    url: "/home",
};

const rename = {
    id: "rename",
    title: "Rename",
    icon: iconEdit,
    url: "/home",
};

const archive = {
    id: "archive",
    title: "Archive",
    icon: iconArchive,
    url: "/home",
};

const deleted = {
    id: "delete",
    title: "Delete",
    icon: iconDelete,
    url: "/home",
};

export const historyItem = {
    items: [rename, archive, deleted],
};
