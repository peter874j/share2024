import { Typography } from "@mui/material";
import { styled } from "@mui/system";

const getFontWeight = (theme, fontWeight) => {
    if (fontWeight === "light") {
        return theme.typography.fontWeightLight;
    } else if (fontWeight === "medium") {
        return theme.typography.fontWeightMedium;
    } else if (fontWeight === "bold") {
        return theme.typography.fontWeightBold;
    } else {
        return theme.typography.fontWeightRegular;
    }
};

const TitleLabel = styled(Typography, {
    shouldForwardProp: (prop) =>
        prop !== "color" && prop !== "fontSize" && prop !== "fontWeight",
})(({ theme, color, fontSize, fontWeight }) => ({
    color: color ? color : theme.palette.text.primary,
    fontSize: fontSize ? fontSize : "19px",
    fontWeight: getFontWeight(theme, fontWeight ? fontWeight : "bold"),
    whiteSpace: "pre-wrap",
}));

const SubTitleLabel = styled(Typography, {
    shouldForwardProp: (prop) => prop !== "fontSize" && prop !== "fontWeight",
})(({ theme, color, fontSize, fontWeight }) => ({
    color: color ? color : theme.palette.text.secondary,
    fontSize: fontSize ? fontSize : "13px",
    fontWeight: getFontWeight(theme, fontWeight ? fontWeight : "medium"),
    whiteSpace: "pre-wrap",
}));

export { TitleLabel, SubTitleLabel };
