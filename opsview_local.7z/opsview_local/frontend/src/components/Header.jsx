import React from "react";
import { Box } from "@mui/material";
import { TitleLabel } from "./Label";

export default function Header({title}) {

    return (
        <>
            {title && (
                <Box>
                    <TitleLabel fontSize={"28px"}>
                        {title}
                    </TitleLabel>
                </Box>
            )}
        </>
    );
}
