import React from "react";
import ContentDialog from "../ContentDialog";
import EditUnitSection from "./EditUnitSection";

const AddDialog = ({
    dialogHandler,
    setDialogHandler,
    editUnitSectionRef,
    handleDialogSection,
    resetDialogHandler,
    fabOptions,
    departOptions,
    stagOptions,
}) => {
    return (
        <ContentDialog
            maxWidth="sm"
            showDialog={dialogHandler.show}
            setShowDialog={(updateShow) => {
                setDialogHandler({
                    ...dialogHandler,
                    show: updateShow,
                });
            }}
            title={"新增崗位"}
            content={
                <EditUnitSection
                    fabOptions={fabOptions}
                    departOptions={departOptions}
                    stagOptions={stagOptions}
                    ref={editUnitSectionRef}
                />
            }
            actionLabel="確認"
            actionHandler={handleDialogSection}
            secondaryActionLabel="取消"
            secondaryActionHandler={resetDialogHandler}
        />
    );
};

const EditDialog = ({
    dialogHandler,
    setDialogHandler,
    editUnitSectionRef,
    initState,
    handleDialogSection,
    resetDialogHandler,
    fabOptions,
    departOptions,
    stagOptions,
}) => {
    return (
        <ContentDialog
            maxWidth="sm"
            showDialog={dialogHandler.show}
            setShowDialog={(updateShow) => {
                setDialogHandler({
                    ...dialogHandler,
                    show: updateShow,
                });
            }}
            title={"編輯崗位"}
            content={
                <EditUnitSection
                    fabOptions={fabOptions}
                    departOptions={departOptions}
                    stagOptions={stagOptions}
                    initState={initState}
                    ref={editUnitSectionRef}
                />
            }
            actionLabel="確認"
            actionHandler={handleDialogSection}
            secondaryActionLabel="取消"
            secondaryActionHandler={resetDialogHandler}
        />
    );
};

const DeleteDialog = ({
    dialogHandler,
    setDialogHandler,
    handleDialogSection,
    resetDialogHandler,
    unitInfo,
}) => {
    return (
        <ContentDialog
            maxWidth="xs"
            showDialog={dialogHandler.show}
            setShowDialog={(updateShow) => {
                setDialogHandler({
                    ...dialogHandler,
                    show: updateShow,
                });
            }}
            title={"刪除崗位"}
            content={
                <div>
                    <p>確定要刪除嗎?</p>
                    <ul>
                        <li>站點: {unitInfo?.stage}</li>
                        <li>崗位: {unitInfo?.unit}</li>
                    </ul>
                </div>
            }
            actionLabel="確認"
            actionHandler={handleDialogSection}
            secondaryActionLabel="取消"
            secondaryActionHandler={resetDialogHandler}
        />
    );
};

const DialogSection = ({
    dialogHandler,
    setDialogHandler,
    editUnitSectionRef,
    handleDialogSection,
    resetDialogHandler,
    getUnitInfo,
    fabOptions,
    departOptions,
    stagOptions,
}) => {
    const dialogComponents = {
        add: AddDialog,
        edit: EditDialog,
        del: DeleteDialog,
    };

    if (!dialogHandler.show) return null;
    const DialogComponent = dialogComponents[dialogHandler.mode];
    if (!DialogComponent) return null;

    const commonProps = {
        dialogHandler,
        setDialogHandler,
        handleDialogSection,
        resetDialogHandler,
    };

    const getAdditionalProps = () => {
        switch (dialogHandler.mode) {
            case "add":
                return {
                    editUnitSectionRef,
                    fabOptions,
                    departOptions,
                    stagOptions,
                };
            case "edit":
                return {
                    editUnitSectionRef,
                    initState: getUnitInfo(),
                    fabOptions,
                    departOptions,
                    stagOptions,
                };
            case "del":
                return {
                    unitInfo: getUnitInfo(),
                };
            default:
                return {};
        }
    };

    return <DialogComponent {...commonProps} {...getAdditionalProps()} />;
};

export default DialogSection;
