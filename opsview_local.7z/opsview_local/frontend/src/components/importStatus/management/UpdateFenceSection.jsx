import React, {
    forwardRef,
    useImperativeHandle,
    useRef,
    useState,
} from "react";
import { useTheme } from "@mui/material/styles";
import { CardMedia, Box, TextField, Typography } from "@mui/material";
import { Stage, Layer, Line, Circle, Text } from "react-konva";
import { TitleLabel } from "../../Label";
import { useParams } from "react-router-dom";

const UpdateFenceSection = forwardRef(({ videoUrl, fence = {}, fences }, ref) => {
    const { unitId } = useParams();
    const SCALE = 3.2;
    const theme = useTheme();    
    const [videoSize, setVideoSize] = useState({ width: 800, height: 450 });
    const [hasShownIntersectionError, setHasShownIntersectionError] =
        useState(false);
    const scaleDownPoints = (points) => points.map((val) => val / SCALE);
    const flattenToPairs = (flatPoints) => {
        const pairs = [];
        for (let i = 0; i < flatPoints.length; i += 2) {
            pairs.push([flatPoints[i], flatPoints[i + 1]]);
        }
        return pairs;
    };

    const pairsToFlat = (pairPoints) => pairPoints.flat();

    const [points, setPoints] = useState(() =>
        fence?.drawn_area
        ? scaleDownPoints(pairsToFlat(fence.drawn_area))
        : []
    );

    const [formData, setFormData] = useState(() => ({
        ...fence,
        drawn_area: fence?.drawn_area ?? [],
        unit_id: parseInt(fence.unit_id ?? unitId),
    }));

    const [errors, setErrors] = useState({
        name: false,
        drawn_area: false,
    });

    const updatePoints = (newFlatPoints) => {
        setPoints(newFlatPoints);
        const newPairPoints = flattenToPairs(newFlatPoints);
        setFormData((prev) => ({
            ...prev,
            drawn_area: newPairPoints,
        }));
    };

    const handleDragMove = (e, index) => {
        const x = e.target.x();
        const y = e.target.y();

        const newPoints = [...points];
        newPoints[index * 2] = x;
        newPoints[index * 2 + 1] = y;

        if (willCauseIntersection(newPoints)) {
            e.target.x(points[index * 2]);
            e.target.y(points[index * 2 + 1]);

            // ❗ 只在第一次碰撞時顯示錯誤
            if (!hasShownIntersectionError) {
                alert("這樣會產生交叉線段，請選擇其他位置");
                setHasShownIntersectionError(true);
            }

            return;
        }

        // 如果沒有交叉，就重設錯誤狀態
        if (hasShownIntersectionError) {
            setHasShownIntersectionError(false);
        }

        updatePoints(newPoints);
    };

    const handlePointContextMenu = (e, index) => {
        e.evt.preventDefault();
        if (points.length <= 6) return;
        const newPoints = [...points];
        newPoints.splice(index * 2, 2);
        updatePoints(newPoints);
    };

    const handleStageClick = (e) => {
        const { x, y } = e.target.getStage().getPointerPosition();
        if (willCauseIntersection(points, [x, y], points.length / 2)) {
            alert("這樣會產生交叉線段，請選擇其他位置");
            return;
        }
        updatePoints([...points, x, y]);
    };

    useImperativeHandle(ref, () => ({
        validate: () => {
            const nameTrimmed = formData?.name?.trim();
            const isNameEmpty = nameTrimmed === "";
            const isNameInvalid = !/^[a-zA-Z0-9\s]+$/.test(nameTrimmed);
            const isNameDuplicate = fences.some(
                (fen) => fen.name === nameTrimmed && fen.name !== fence.name
            );    
    

            const newErrors = {
                name: isNameEmpty || isNameInvalid || isNameDuplicate,
                drawn_area: !(formData?.drawn_area?.length >= 3),
            };
            setErrors(newErrors);
            return !Object.values(newErrors).some(Boolean);
        },
        getData: () => {
            const scaleUpPoints = (points) => points.map((val) => val * SCALE);
            const finlaPoints = flattenToPairs(scaleUpPoints(points));

            return {
                ...formData,
                drawn_area: finlaPoints,
            }
        },
        setPoints: (newPairPoints) => {
            const flat = pairsToFlat(newPairPoints);
            updatePoints(flat);
        },
    }));

    function doLinesIntersect(p1, p2, p3, p4) {
        const cross = (a, b) => a[0] * b[1] - a[1] * b[0];
        const subtract = (a, b) => [a[0] - b[0], a[1] - b[1]];

        const d1 = subtract(p2, p1);
        const d2 = subtract(p4, p3);
        const delta = subtract(p3, p1);
        const denominator = cross(d1, d2);
        if (denominator === 0) return false;

        const t = cross(delta, d2) / denominator;
        const u = cross(delta, d1) / denominator;

        return t > 0 && t < 1 && u > 0 && u < 1;
    }

    function willCauseIntersection(
        points,
        newPoint = null,
        insertIndex = null,
    ) {
        const testPoints = [...points];
        if (newPoint && insertIndex !== null) {
            testPoints.splice(insertIndex * 2, 0, ...newPoint);
        }
        const numPoints = testPoints.length / 2;
        const segments = [];
        for (let i = 0; i < numPoints; i++) {
            const p1 = [testPoints[i * 2], testPoints[i * 2 + 1]];
            const p2 = [
                testPoints[((i + 1) % numPoints) * 2],
                testPoints[((i + 1) % numPoints) * 2 + 1],
            ];
            segments.push([p1, p2]);
        }
        for (let i = 0; i < segments.length; i++) {
            for (let j = i + 1; j < segments.length; j++) {
                if (
                    Math.abs(i - j) <= 1 ||
                    (i === 0 && j === segments.length - 1)
                )
                    continue;
                if (
                    doLinesIntersect(
                        segments[i][0],
                        segments[i][1],
                        segments[j][0],
                        segments[j][1],
                    )
                ) {
                    return true;
                }
            }
        }
        return false;
    }

    return (
        <Box sx={{ width: videoSize.width }}>
            <TextField
                label="Name"
                fullWidth
                size="small"
                value={formData.name}
                error={errors.name}
                helperText={
                    errors.name &&
                    (formData.name.trim() === ""
                        ? "必填且只能填英文/數字"
                        : fences.some(
                            (fen) =>
                                fen.name === formData.name.trim() &&
                                fen.name !== fence.name
                        )
                        ? "名稱不能重複"
                        : "必填且只能填英文/數字")
                }
                onChange={(e) =>
                    setFormData((prev) => ({ ...prev, name: e.target.value }))
                }
            />
            <Box display="flex" gap={4} sx={{ mt: 2 }}>
                <TitleLabel>🔹 點擊左鍵新增點</TitleLabel>
                <TitleLabel>🔹 點擊右鍵刪除點</TitleLabel>
                <TitleLabel>🔹 拖曳點可改變位置</TitleLabel>
            </Box>
            {errors.drawn_area && (
                <>
                    <Typography color="error">至少要三個點</Typography>
                </>
            )}
            <Box
                sx={{
                    position: "relative",
                    width: videoSize.width,
                    height: videoSize.height,
                }}
            >
                <CardMedia
                    component="img"
                    autoPlay
                    controls
                    src={videoUrl}
                    sx={{
                        borderRadius: "4px",
                        width: "100%",
                        height: "100%",
                    }}
                />

                {videoSize.width > 0 && (
                    <Stage
                        width={videoSize.width}
                        height={videoSize.height}
                        style={{ position: "absolute", top: 0, left: 0 }}
                        onClick={(e) => {
                            if (e.evt.button === 0) {
                                handleStageClick(e);
                            }
                        }}
                    >
                        <Layer>
                            {points.length >= 6 && (
                                <Line
                                    points={points}
                                    stroke="#e53935"
                                    strokeWidth={3}
                                    closed
                                    tension={0}
                                />
                            )}
                            {points.map((_, i) =>
                                i % 2 === 0 ? (
                                    <React.Fragment key={i}>
                                        <Circle
                                            x={points[i]}
                                            y={points[i + 1]}
                                            radius={6}
                                            fill="white"
                                            stroke="black"
                                            strokeWidth={1}
                                            draggable
                                            onDragMove={(e) =>
                                                handleDragMove(e, i / 2)
                                            }
                                            onContextMenu={(e) => {
                                                e.evt.preventDefault();
                                                handlePointContextMenu(
                                                    e,
                                                    i / 2,
                                                );
                                            }}
                                        />
                                        <Text
                                            x={points[i] - 20} // 稍微偏右
                                            y={points[i + 1] - 20} // 稍微偏上
                                            text={`${i / 2 + 1}.`}
                                            fontSize={16}
                                            fill={ theme.palette.text.primary }
                                        />
                                    </React.Fragment>
                                ) : null,
                            )}
                        </Layer>
                    </Stage>
                )}
            </Box>
        </Box>
    );
});

UpdateFenceSection.displayName = "UpdateFenceSection";
export default UpdateFenceSection;
