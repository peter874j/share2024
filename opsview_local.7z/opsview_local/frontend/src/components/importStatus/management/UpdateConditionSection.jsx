import React, { forwardRef, useState, useImperativeHandle } from "react";
import {
    Box,
    TextField,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Typography,
    Checkbox,
    ListItemText,
} from "@mui/material";
import { useParams } from "react-router-dom";

const UpdateConditionSection = forwardRef((props, ref) => {
    const { unitId } = useParams();
    const { objects, fences, condition = {}, conditions } = props;

    const [formData, setFormData] = useState({
        ...condition,
        name: condition.name ?? "",
        unit_id: parseInt(condition.unit_id ?? unitId),
        object_ids: condition.objects?.map(obj => obj.id) ?? [],
        fence_id: condition.fence_id ?? "",
    });

    const [errors, setErrors] = useState({
        name: false,
        objectId: false,
        fenceId: false,
    });

    useImperativeHandle(ref, () => ({
        validate: () => {
            const nameTrimmed = formData?.name?.trim();
            const isNameEmpty = nameTrimmed === "";
            const isNameInvalid = !/^[a-zA-Z0-9\s]+$/.test(nameTrimmed);
            const isNameDuplicate = conditions.some(
                (cond) => cond.name === nameTrimmed && cond.name !== condition.name
            );    

            const newErrors = {
                name: isNameEmpty || isNameInvalid || isNameDuplicate,
                objectId: formData.object_ids.length === 0,
            };
    
            setErrors(newErrors);
    
            return !Object.values(newErrors).some(Boolean);
        },
        getData: () => formData,
    }));    

    return (
        <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
            {/* Name */}
            <TextField
                label="Name"
                fullWidth
                size="small"
                value={formData.name}
                error={errors.name}
                helperText={
                    errors.name &&
                    (formData.name.trim() === ""
                        ? "必填且只能填英文/數字"
                        : conditions.some(
                            (cond) =>
                                cond.name === formData.name.trim() &&
                                cond.name !== condition.name
                        )
                        ? "名稱不能重複"
                        : "必填且只能填英文/數字")
                }
                onChange={(e) =>
                    setFormData((prev) => ({ ...prev, name: e.target.value }))
                }
            />

            {/* Object */}
            <FormControl fullWidth size="small" error={errors.objectId}>
                <InputLabel>作業物件</InputLabel>
                <Select
                    multiple
                    value={formData.object_ids || []}
                    label="作業物件"
                    onChange={(e) => {
                        const value = e.target.value;
                        setFormData((prev) => ({
                            ...prev,
                            object_ids: value,
                        }));
                    }}
                    renderValue={(selected) =>
                        objects
                            .filter((obj) => selected.includes(obj.id))
                            .map((obj) => obj.name)
                            .join(", ")
                    }
                >
                    {objects.map((obj) => {
                        const selectedCount = formData.object_ids?.length || 0;
                        const isSelected = formData.object_ids?.includes(obj.id);
                        const isDisabled = !isSelected && selectedCount >= 2;

                        return (
                            <MenuItem key={obj.id} value={obj.id} disabled={isDisabled}>
                                <Checkbox checked={isSelected} />
                                <ListItemText primary={obj.name} />
                            </MenuItem>
                        )
                    })}
                </Select>
                {errors.objectId && (
                    <Typography variant="caption" color="error" sx={{ mt: 0.5 }}>
                        物件為必要選項 (上限2)
                    </Typography>
                )}
            </FormControl>

            {/* Fence */}
            <FormControl fullWidth size="small" error={errors.fenceId}>
                <InputLabel>作業圍籬</InputLabel>
                <Select
                    value={formData.fence_id || ""}
                    label="作業圍籬"
                    onChange={(e) =>
                        setFormData((prev) => ({
                            ...prev,
                            fence_id: e.target.value,
                        }))
                    }
                    renderValue={(selected) => {
                        const f = fences.find((f) => f.id === selected);
                        return f ? f.name : "";
                    }}
                >
                    <MenuItem value="">
                        <em>清除選擇</em>
                    </MenuItem>

                    {fences.map((f) => (
                        <MenuItem key={f.id} value={f.id}>
                            <Checkbox checked={formData.fence_id === f.id} />
                            <ListItemText primary={f.name} />
                        </MenuItem>
                    ))}
                </Select>
            </FormControl>
        </Box>
    );
});

UpdateConditionSection.displayName = "UpdateConditionSection";

export default UpdateConditionSection;
