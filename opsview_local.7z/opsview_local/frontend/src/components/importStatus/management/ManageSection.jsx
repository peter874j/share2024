import React, { useEffect, useRef, useState } from "react";
import { useNavigate, useLocation, useParams } from "react-router-dom";
import {
    Box,
    Tab,
    Tabs,
    Button,
    Stack,
    Typography,
    Paper,
    CardMedia,
    IconButton,
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import {
    AddOutlined,
    ArrowCircleLeftOutlined,
    Edit,
    DeleteForeverRounded,
} from "@mui/icons-material";
import { useTheme } from "@mui/material/styles";
import { Stage, Layer, Line } from "react-konva";
import { SubTitleLabel, TitleLabel } from "../../Label";
import DialogSection from "./DialogSection";
import { backendAPI } from "../../../apis/services/backendAPI";
import { NotificationService } from "../../NotificationService";
import { useUnsavedChangesPrompt } from "../../../utils/useUnsavedChangesPrompt";

export default function ManageSection() {
    const theme = useTheme();
    const navigate = useNavigate();
    const { unitId } = useParams();
    const location = useLocation();
    const state = location?.state;
    const [activeTab, setActiveTab] = useState(0);
    const [objects, setObjects] = useState([]);
    const [fences, setFences] = useState([]);
    const [conditions, setConditions] = useState([]);
    const [logicRows, setLogicRows] = useState([]);
    const [dialogHandler, setDialogHandler] = useState({
        type: null,
        show: false,
        mode: null,
        editLevel: "full",
    });
    const originalRef = useRef(null);
    const hasUnsavedChangesRef = useRef(false);
    const selectRowRef = useRef(null);
    const formRef = useRef();
    const videoRef = useRef(null);
    
    useUnsavedChangesPrompt(hasUnsavedChangesRef.current)
    
    useEffect(() => {
        const handleBeforeUnload = (e) => {
            if (hasUnsavedChangesRef.current) {
                e.preventDefault();
                e.returnValue = "";
            }
        };
        window.addEventListener("beforeunload", handleBeforeUnload);
        return () => {
            window.removeEventListener("beforeunload", handleBeforeUnload);
        };
    }, []);    

    useEffect(() => {
        if(!location.state) {
            navigate("/h/unit");
            return;
        };
    
        if (state.cam !== undefined) {
            videoRef.current = state.cam
        };

        fetchAll();
    }, []);      
    
    async function fetchAll() {
        const [objRes, fenceRes, condRes, logicRes] = await Promise.all([
            backendAPI.getObjects(unitId),
            backendAPI.getFences(unitId),
            backendAPI.getConditions(unitId),
            backendAPI.getLogics(unitId),
        ]);
    
        const results = [
            { key: "物件", res: objRes },
            { key: "圍籬", res: fenceRes },
            { key: "條件", res: condRes },
            { key: "邏輯", res: logicRes },
        ];
    
        const failed = results.filter(({ res }) => res?.status !== 200);
    
        if (failed.length) {
            const failedNames = failed.map(({ key }) => key).join("、");
            NotificationService.handleError(`取得 ${failedNames} 失敗`);
            console.error("fetchAll 失敗：", failed);
            return;
        }
    
        const objectsData = objRes.data ?? [];
        const fencesData = fenceRes.data ?? [];
        const conditionsData = condRes.data ?? [];
        const logicsData = logicRes.data ?? [];
    
        originalRef.current = {
            fences: fencesData,
            conditions: conditionsData,
            logicRows: logicsData,
        };
    
        setObjects(objectsData);
        setFences(fencesData);
        setConditions(conditionsData);
        setLogicRows(logicsData);
    }    

    const handleShowDialog = (row, type, mode) => {
        let editLevel = "full";

        if (type === "logic" && mode === "edit") {
            const idx = logicRows.findIndex(r => r.id === row.id);
            if (idx === 0) editLevel = "expression";
            else if (idx >= 1 && idx <= 3) editLevel = "mode_expression";
        }

        selectRowRef.current = row;
        setDialogHandler({ type, mode, show: true, editLevel });
    };

    const handleCloseDialog = () => {
        selectRowRef.current = null;
        setDialogHandler({ type: null, mode: null, show: false });
    };

    const handleCreateCondition = async () => {
        if (formRef.current?.validate()) {
            const data = formRef.current.getData();
            const response = await backendAPI.createCondition(data);
            if (response?.status !== undefined) {
                setConditions((prev) => [...prev, response.data]);
                NotificationService.handleSuccess("建立成功");
                handleCloseDialog();
            } else {
                NotificationService.handleSuccess("建立失敗");
            }     
        }
    };

    const handleEditCondition = async () => {
        if (formRef.current?.validate()) {
            const data = formRef.current.getData();

            const response = await backendAPI.updateCondition(data.id, data);
            if (response?.status !== undefined) {
                setConditions(prev => 
                    prev.map(item => (item.id === data.id ? { ...item, ...data } : item))    
                )
                NotificationService.handleSuccess("更新成功");
                handleCloseDialog();
            } else {
                NotificationService.handleSuccess("更新失敗");
            }   
        }
    };

    const handleDeleteCondition = async () => {
        const id = selectRowRef.current.id;

        const response = await backendAPI.deleteCondition(id);
        if (response?.status !== undefined) {
            setConditions(prev => 
                prev.filter(item => (item.id !== id))    
            )
            NotificationService.handleSuccess("刪除成功");
            handleCloseDialog();
        } else {
            NotificationService.handleSuccess("刪除失敗");
        }   
    };

    const handleCreateFence = async () => {
        if (formRef.current?.validate()) {
            const data = formRef.current.getData();
            const response = await backendAPI.createFence(data);
            if (response?.status !== undefined) {
                setFences((prev) => [...prev, response.data]);
                NotificationService.handleSuccess("建立成功");
                handleCloseDialog();
            } else {
                NotificationService.handleSuccess("建立失敗");
            }     
        }
    };   

    const handleEditFence = async () => {
        if (formRef.current?.validate()) {
            const data = formRef.current.getData();

            const response = await backendAPI.updateFence(data.id, data);
            if (response?.status !== undefined) {
                setFences(prev => 
                    prev.map(item => (item.id === data.id ? { ...item, ...data } : item))    
                )
                NotificationService.handleSuccess("更新成功");
                handleCloseDialog();
            } else {
                NotificationService.handleSuccess("更新失敗");
            } 
        }
    };

    const handleDeleteFence = async () => {
        const id = selectRowRef.current.id;
        const response = await backendAPI.deleteFence(id);
        if (response?.status !== undefined) {
            setFences(prev => 
                prev.filter(item => (item.id !== id))    
            )
            NotificationService.handleSuccess("刪除成功");
            handleCloseDialog();
        } else {
            NotificationService.handleSuccess("刪除失敗");
        }   
    };

    const handleCreateLogic = async () => {
        if (formRef.current?.validate()) {
            const data = formRef.current.getData();
            const response = await backendAPI.createLogic(data);
            if (response?.status !== undefined) {
                setLogicRows((prev) => [...prev, response.data]);
                NotificationService.handleSuccess("建立成功");
                handleCloseDialog();
            } else {
                NotificationService.handleSuccess("建立失敗");
            }     
        }
    };

    const handleEditLogic = async () => {
        if (formRef.current?.validate()) {
            const data = formRef.current.getData();

            const response = await backendAPI.updateLogic(data.id, data);
            if (response?.status !== undefined) {
                setLogicRows(prev => 
                    prev.map(item => (item.id === data.id ? { ...item, ...data } : item))    
                )
                NotificationService.handleSuccess("更新成功");
                handleCloseDialog();
            } else {
                NotificationService.handleSuccess("更新失敗");
            } 
        }
    };

    const handleDeleteLogic = async () => {
        const id = selectRowRef.current.id;

        const response = await backendAPI.deleteLogic(id);
        if (response?.status !== undefined) {
            setLogicRows(prev => 
                prev.filter(item => (item.id !== id))    
            )
            NotificationService.handleSuccess("刪除成功");
            handleCloseDialog();
        } else {
            NotificationService.handleSuccess("刪除失敗");
        }  
    };

    const handleUpdateAIClient = async () => {
        const payload = {
            unit_id: unitId
        }

        const response = await backendAPI.syncConfig(payload);
        if (response?.status !== undefined) {
            NotificationService.handleSuccess("AI Client 更新成功");
            handleCloseDialog();
        } else {
            NotificationService.handleSuccess("AI Client 更新失敗");
        }  
    };

    /*********************
     * DataGrid columns  *
     *********************/
    const simpleColumns = [
        {
            field: "no",
            headerName: "No.",
            flex: 2,
            sortable: false,
            filterable: false,
            renderCell: (params) => {
                const sortedIds = params.api.getSortedRowIds();
                const index = sortedIds.indexOf(params.id);
                return index + 1;
            }
        },
        { field: "name", headerName: "Name", flex: 6 },
    ];
    const logicColumns = [
        { field: "name", headerName: "Name", flex: 1 },
        { field: "expression", headerName: "Condition", flex: 1 },
        { field: "mode", headerName: "Stop Logic", flex: 1 },
        {
            field: "action",
            headerName: "Action",
            flex: 1,
            sortable: false,
            filterable: false,
            renderCell: (params) => {
                const rowIds = params.api.getAllRowIds();
                const rowIndex = rowIds.indexOf(params.id)
                const isDeleteVisible = rowIndex >= 4;
                return (
                    <Box
                        sx={{
                            width: "100%",
                            height: "100%",
                            display: "flex",
                            alignItems: "center",
                        }}
                    >
                        <Stack direction="row" spacing={1}>
                            <IconButton
                                size="small"
                                onClick={() =>
                                    handleShowDialog(params.row, "logic", "edit")
                                }
                            >
                                <Edit fontSize="small" />
                            </IconButton>
                            {isDeleteVisible && (
                                <IconButton
                                    size="small"
                                    onClick={() =>
                                        handleShowDialog(params.row, "logic", "delete")
                                    }
                                >
                                    <DeleteForeverRounded fontSize="small" />
                                </IconButton>
                            )}
                        </Stack>
                    </Box>
                );
            },
        },
    ];

    const renderTableWithCreate = (
        rows,
        type,
        withActions = false,
    ) => {
        const columns = [
            {
                field: "no",
                headerName: "No.",
                flex: 2,
                sortable: false,
                filterable: false,
                renderCell: (params) => {
                    const sortedIds = params.api.getSortedRowIds();
                    const index = sortedIds.indexOf(params.id);
                    return index + 1;
                }
            },
            { field: "name", headerName: "Name", flex: 7.5 },
            ...(withActions
                ? [
                      {
                          field: "action",
                          headerName: "Action",
                          flex: 2,
                          sortable: false,
                          filterable: false,
                          renderCell: (params) => (
                              <Box
                                  sx={{
                                      width: "100%",
                                      height: "100%",
                                      display: "flex",
                                      alignItems: "center",
                                      justifyContent: "center",
                                  }}
                              >
                                  <Stack direction="row" spacing={1}>
                                      <IconButton
                                          size="small"
                                          onClick={() =>
                                            handleShowDialog(params.row, type, "edit")
                                          }
                                      >
                                          <Edit fontSize="small" />
                                      </IconButton>
                                      <IconButton
                                          size="small"
                                          onClick={() =>
                                            handleShowDialog(params.row, type, "delete")
                                          }
                                      >
                                          <DeleteForeverRounded fontSize="small" />
                                      </IconButton>
                                  </Stack>
                              </Box>
                          ),
                      },
                  ]
                : []),
        ];

        return (
            <Box
                sx={{
                    flex: 1,
                    display: "flex",
                    flexDirection: "column",
                    gap: 2,
                }}
            >
                <Stack
                    direction="row"
                    justifyContent="space-between"
                    alignItems="center"
                >
                    <Button
                        aria-label="create"
                        onClick={() => {
                            handleShowDialog("", type, "create")
                        }}
                        startIcon={<AddOutlined />}
                        sx={{
                            textTransform: "none",
                            backgroundColor: theme.palette.avatar.default,
                            pointerEvents: "auto",
                        }}
                    >
                        <SubTitleLabel fontSize={"13px"}>Create</SubTitleLabel>
                    </Button>
                </Stack>
                <DataGrid
                    autoHeight
                    rows={rows}
                    columns={columns}
                    hideFooter
                    disableRowSelectionOnClick
                />
            </Box>
        );
    };

    /*********************
     * Konva render      *
     *********************/
    const renderOverlay = () => (
        <Stage
            width={1090}
            height={613}
            style={{ position: "absolute", top: 0, left: 0 }}
        >
            <Layer>
                {/* Draw fences as red polygons */}
                {fences.map((f) => (
                    <Line
                        key={`f-${f.id}`}
                        points={f.drawn_area}
                        stroke="#e53935"
                        strokeWidth={3}
                        closed
                    />
                ))}
            </Layer>
        </Stage>
    );

    return (
        <>
            <Box
                sx={{ display: "flex", flexDirection: "column", gap: 2, p: 3 }}
            >
                <Box sx={{ display: "flex", gap: 2 }}>
                    <IconButton
                        sx={{
                            backgroundColor: "transparent",
                            "&:hover": {
                                backgroundColor: "transparent",
                            },
                        }}
                        onClick={() => {
                            navigate("/h/import");
                        }}
                    >
                        <ArrowCircleLeftOutlined
                            sx={{
                                fontSize: "28px",
                                color: theme.palette.avatar.logo,
                                "&:hover": {
                                    color: theme.palette.icon.hover,
                                },
                            }}
                        />
                    </IconButton>
                    <TitleLabel fontSize="28px">崗位管理</TitleLabel>
                </Box>
                <Stack direction="row" alignItems="center" spacing={2}>
                    <TitleLabel>{state?.unit}</TitleLabel>
                    <Button
                        aria-label="ai update"
                        onClick={() => {handleUpdateAIClient}}
                        startIcon={<AddOutlined />}
                        sx={{
                            px: 2,
                            py: 1.5,
                            textTransform: "none",
                            backgroundColor: theme.palette.avatar.default,
                        }}
                    >
                        <SubTitleLabel fontSize={"16px"}> AI 參數更新</SubTitleLabel>
                    </Button>   
                </Stack>
                <Box sx={{ display: "flex", gap: 2 }}>
                    {/* Left - 7/10 width */}
                    <Box
                        sx={{
                            flex: 7,
                            display: "flex",
                            flexDirection: "column",
                            gap: 2,
                        }}
                    >
                        {/* Video (6/10 of right) */}
                        <Box
                            sx={{
                                flex: 6,
                                position: "relative",
                                width: 1090,
                                height: 613,
                                background: "#000",
                                borderRadius: "4px",
                            }}
                        >
                            {videoRef.current?.stream_det_uri ?
                                <>
                                    <CardMedia
                                        component="img"
                                        autoPlay
                                        controls
                                        image={
                                            videoRef.current?.stream_det_uri
                                        }
                                        sx={{
                                            borderRadius: "4px",
                                            width: "100%",
                                            height: "100%",
                                    }}
                                />
                                {renderOverlay()}
                                </>:
                                    <Box
                                        sx={{
                                            width: "100%",
                                            height: "45vh",
                                            display: "flex",
                                            alignItems: "center",
                                            justifyContent: "center"
                                        }}
                                    >
                                        <TitleLabel>暫無影像</TitleLabel>
                                    </Box>
                            }
                        </Box>

                        {/* Logic (4/10 of right) */}
                        <Box sx={{ flex: 4 }}>
                            <Stack
                                direction="row"
                                alignItems="center"
                                mb={1}
                                gap={3}
                            >
                                <Typography variant="subtitle1">
                                    作業邏輯
                                </Typography>
                                <Button
                                    aria-label="logic"
                                    startIcon={<AddOutlined />}
                                    onClick={() => {
                                        handleShowDialog("", "logic", "create")
                                    }}
                                    sx={{
                                        textTransform: "none",
                                        backgroundColor:
                                            theme.palette.avatar.default,
                                        pointerEvents: "auto",
                                    }}
                                >
                                    <SubTitleLabel fontSize={"13px"}>
                                        Create
                                    </SubTitleLabel>
                                </Button>
                            </Stack>
                            <DataGrid
                                autoHeight
                                disableColumnMenu
                                rows={logicRows}
                                columns={logicColumns}
                                hideFooter
                                disableRowSelectionOnClick
                            />
                        </Box>
                    </Box>
                    {/* Right - 3/10 width */}
                    <Paper
                        sx={{
                            flex: 3,
                            display: "flex",
                            flexDirection: "column",
                            background: theme.palette.background.default,
                            boxShadow: "none",
                            gap: 2,
                        }}
                    >
                        <TitleLabel>前置設定</TitleLabel>
                        <Tabs
                            value={activeTab}
                            onChange={(_, v) => setActiveTab(v)}
                            variant="fullWidth"
                            textColor="inherit"
                            sx={{
                                backgroundColor:
                                    theme.palette.background.paper1,
                                borderRadius: "8px",
                                "& .MuiTab-root": {
                                    textTransform: "capitalize",
                                    fontSize: "18px",
                                    fontWeight: "bold",
                                },
                            }}
                        >
                            <Tab label="作業物件" />
                            <Tab label="作業圍籬" />
                            <Tab label="作業觸發條件" />
                        </Tabs>
                        <Box sx={{ flex: 1 }}>
                            {activeTab === 0 && (
                                <DataGrid
                                    autoHeight
                                    disableColumnMenu
                                    rows={objects}
                                    columns={simpleColumns}
                                    hideFooter
                                    disableRowSelectionOnClick
                                />
                            )}
                            {activeTab === 1 &&
                                renderTableWithCreate(
                                    fences,
                                    "fence",
                                    true,
                                )}
                            {activeTab === 2 &&
                                renderTableWithCreate(
                                    conditions,
                                    "condition",
                                    true,
                                )}
                        </Box>
                    </Paper>
                </Box>
            </Box>
            <DialogSection
                dialogHandler={dialogHandler}
                setDialogHandler={setDialogHandler}
                formRef={formRef}
                selectRow={selectRowRef.current}
                objects={objects}
                fences={fences}
                conditions={conditions}
                logicRows={logicRows}
                streamPreUri={state?.cam?.stream_det_uri}
                onCreateFence={handleCreateFence}
                onEditFence={handleEditFence}
                onDeleteFence={handleDeleteFence}
                onCreateCondition={handleCreateCondition}
                onEditCondition={handleEditCondition}
                onDeleteCondition={handleDeleteCondition}
                onCreateLogic={handleCreateLogic}
                onEditLogic={handleEditLogic}
                onDeleteLogic={handleDeleteLogic}
            />
        </>
    );
}
