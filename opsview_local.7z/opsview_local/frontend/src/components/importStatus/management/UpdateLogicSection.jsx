import React, { useState, useImperativeHandle, forwardRef } from "react";
import {
    Box,
    TextField,
    Typography,
    RadioGroup,
    FormControlLabel,
    Radio,
    Chip,
    Button,
    Stack,
    Paper,
    Tooltip,
} from "@mui/material";
import { useParams } from "react-router-dom";

const UpdateLogicSection = forwardRef(
    ({ conditions = [], logic = {}, editLevel = "full", logicRows}, ref) => {
        console.log("conditions", conditions);
        const { unitId } = useParams();
        const canEditName = editLevel === "full";
        const canEditMode = editLevel === "full" || editLevel === "mode_expression";
        const [formData, setFormData] = useState({
            ...logic,
            unit_id: parseInt(logic.unit_id ?? unitId),
            expression: logic.expression?.trim() ? logic.expression.split(/\s+/) : [],
        });

        const [errors, setErrors] = useState({
            state: false,
            name: false,
            mode: false,
            expression: false,
        });

        const [lastType, setLastType] = useState(null); // condition | operator | null
        const operators = ["AND", "OR", "NOT", "(", ")"];

        useImperativeHandle(ref, () => ({
            validate: () => {
                const nameTrimmed = formData?.name?.trim();
                const isNameEmpty = nameTrimmed === "";
                const isNameInvalid = !/^[a-zA-Z0-9\s]+$/.test(nameTrimmed);
                const isNameDuplicate = logicRows.some(
                    (logicRow) => logicRow.name === nameTrimmed && logicRow.name !== logic.name
                ); 

                const newErrors = {
                    name: isNameEmpty || isNameInvalid || isNameDuplicate,
                    mode: formData.mode === "",
                    expression: formData.expression.length === 0 || !isValidExpressionSyntax(formData.expression),
                };
                setErrors(newErrors);
                return !Object.values(newErrors).some(Boolean);
            },
            getData: () => ({
                ...formData,
                expression: formData.expression.map((token) => {
                    if (operators.includes(token)) return token;
                    return token.split("_").slice(1).join("_");
                })
                .join(" ")
                ,
            })
        }));

        const getType = (value) => {
            if (operators.includes(value)) {
                return "operator";
            }
            return "condition";
        };

        const isAddValid = (value) => {
            const type = getType(value);
            if (!lastType) {
                return type !== "operator" || value === "NOT" || value === "(";
            }
            if (lastType === "condition" && type === "condition") {
                return false;
            }
            if (
                lastType === "operator" &&
                ["AND", "OR", "NOT"].includes(formData.expression.at(-1)) &&
                type === "operator"
            ) {
                return false;
            }
            return true;
        };

        const isValidExpressionSyntax = (expression) => {
            let balance = 0;
            let lastType = null;
        
            const operators = ["AND", "OR", "NOT"];
            const openParen = "(";
            const closeParen = ")";
        
            for (let i = 0; i < expression.length; i++) {
                const token = expression[i];
        
                if (token === openParen) {
                    balance++;
                    lastType = "openParen";
                } else if (token === closeParen) {
                    balance--;
                    if (balance < 0) {
                        return false;
                    }
                    if (lastType === "operator") {
                        return false; // like: ( A AND )
                    }
                    lastType = "closeParen";
                } else if (operators.includes(token)) {
                    if (
                        token !== "NOT" &&
                        (!lastType ||
                            lastType === "operator" ||
                            lastType === "openParen")
                    ) {
                        return false; // invalid: AND A, or ( AND
                    }
                    lastType = "operator";
                } else {
                    // assume condition
                    if (lastType === "condition" || lastType === "closeParen") {
                        return false;
                    }
                    lastType = "condition";
                }
            }
        
            return balance === 0 && lastType !== "operator"; // parentheses match & not end with operator
        };        

        const handleAddExpression = (value) => {
            if (!isAddValid(value)) return;
            setFormData((prev) => ({
                ...prev,
                expression: [...prev.expression, value],
            }));
            setLastType(getType(value));
        };

        const handleDeleteExpression = (index) => {
            const newExpression = formData.expression.filter((_, i) => i !== index);
            setFormData((prev) => ({
                ...prev,
                expression: newExpression,
            }));
            setLastType(newExpression.length > 0 ? getType(newExpression.at(-1)) : null);
        };

        return (
            <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
                {/* <TextField
                    label="步驟"
                    fullWidth
                    size="small"
                    value={formData.state}
                    onChange={(e) =>
                        setFormData({ ...formData, state: e.target.value })
                    }
                    error={errors.state}
                    helperText={errors.state && "State is required"}
                /> */}
                <Typography variant="subtitle1" sx={{ mb: -1 }}>
                    名稱
                </Typography>
                <TextField
                    fullWidth
                    disabled={!canEditName}
                    size="small"
                    value={formData.name}
                    onChange={(e) =>
                        setFormData({ ...formData, name: e.target.value, state: e.target.value})
                    }
                    error={errors.name}
                    helperText={
                        errors.name &&
                        (formData.name.trim() === ""
                            ? "必填且只能填英文/數字"
                            : logicRows.some(
                                (logicRow) =>
                                    logicRow.name === formData.name.trim() &&
                                    logicRow.name !== logic.name
                            )
                            ? "名稱不能重複"
                            : "必填且只能填英文/數字")
                        }
                />
                <Box>
                    <Typography variant="subtitle1" sx={{ mb: 1 }}>
                        Stop logic
                    </Typography>

                    <Box
                        sx={{
                            border: "1px solid",
                            borderColor: "divider",
                            borderRadius: 2,
                            px: 1,
                        }}
                    >
                        <RadioGroup
                            row
                            value={formData.mode}
                            onChange={(e) => setFormData({ ...formData, mode: e.target.value })}
                        >
                            <Tooltip
                                arrow
                                title={"不滿足觸發條件，即停止計算該 State 秒數"}
                                placement="top"
                            >
                                <FormControlLabel
                                    value="release"
                                    control={<Radio />}
                                    label="Release"
                                    disabled={!canEditMode}
                                />
                            </Tooltip>
                            <Tooltip
                                arrow
                                title={
                                    "僅需滿足一次觸發條件，直至其他 State 被觸發，即停止計算該 State 秒數"
                                }
                                placement="top"
                            >
                                <FormControlLabel
                                    value="switch"
                                    control={<Radio />}
                                    label="Switch"
                                    disabled={!canEditMode}
                                />
                            </Tooltip>
                        </RadioGroup>
                    </Box>
                </Box>
                <Box>
                    <Typography variant="subtitle1" sx={{ mb: 1 }}>
                       作業邏輯組成
                    </Typography>
                    <Paper
                        sx={{
                            minHeight: 60,
                            display: "flex",
                            flexWrap: "wrap",
                            p: 1,
                            gap: 1,
                            borderRadius: "8px",
                        }}
                    >
                        {formData.expression.map((token, index) => (
                            <Chip
                                key={index}
                                label={token}
                                onDelete={() => handleDeleteExpression(index)}
                            />
                        ))}
                    </Paper>
                </Box>
                <Box sx={{ display: "flex", gap: 2 }}>
                    <Box sx={{ flex: 1 }}>
                        {
                            errors.expression && (
                                <Typography color="error" sx={{ mt: 1 }}>
                                    表達式格式錯誤，請確認括號配對與邏輯語法
                                </Typography>
                            )
                        }
                        <Typography variant="subtitle1" sx={{ mb: 1 }}>
                            作業觸發條件
                        </Typography>
                        <Paper sx={{ height: 250, p: 1, overflowY: "auto", oberflowX: "hidden" }}>
                            <Stack spacing={1} mt={1} sx={{ height: "100%" }}>
                                {conditions.map((cond) => {
                                    const value = `${cond.id}_${cond.name}`;
                                    return (
                                        <Tooltip
                                            key={value}
                                            title={
                                                isAddValid(value)
                                                    ? ""
                                                    : "無效的邏輯順序"
                                            }
                                        >
                                            <span>
                                                <Button
                                                    variant="outlined"
                                                    onClick={() =>
                                                        handleAddExpression(value)
                                                    }
                                                    disabled={
                                                        !isAddValid(value)
                                                    }
                                                    sx={{
                                                        width: "fit-content",
                                                    }}
                                                >
                                                    {value}
                                                </Button>
                                            </span>
                                        </Tooltip>
                                    );
                                })}
                            </Stack>
                        </Paper>
                    </Box>
                    <Box sx={{ flex: 1 }}>
                        <Typography variant="subtitle1" sx={{ mb: 1 }}>
                            Operator
                        </Typography>
                        <Paper sx={{ height: 250, p: 1 }}>
                            <Stack spacing={1} mt={1} sx={{ height: "100%" }}>
                                {operators.map((op) => (
                                    <Tooltip
                                        key={op}
                                        title={
                                            isAddValid(op)
                                                ? ""
                                                : "無效的邏輯順序"
                                        }
                                    >
                                        <span>
                                            <Button
                                                variant="outlined"
                                                onClick={() =>
                                                    handleAddExpression(op)
                                                }
                                                disabled={!isAddValid(op)}
                                                sx={{ width: "fit-content" }}
                                            >
                                                {op}
                                            </Button>
                                        </span>
                                    </Tooltip>
                                ))}
                            </Stack>
                        </Paper>
                    </Box>
                </Box>
            </Box>
        );
    },
);

UpdateLogicSection.displayName = "UpdateLogicSection";
export default UpdateLogicSection;
