import React from "react";
import ContentDialog from "../../ContentDialog";
import UpdateFenceSection from "./UpdateFenceSection";
import UpdateConditionSection from "./UpdateConditionSection";
import UpdateLogicSection from "./UpdateLogicSection";

const DialogSection = ({
  dialogHandler,
  setDialogHandler,
  formRef,
  selectRow,
  objects,
  fences,
  conditions,
  logicRows,
  streamPreUri,
  onCreateFence,
  onEditFence,
  onDeleteFence,
  onCreateCondition,
  onEditCondition,
  onDeleteCondition,
  onCreateLogic,
  onEditLogic,
  onDeleteLogic,
}) => {
  const closeDialog = () => setDialogHandler({ type: null, show: false, mode: null });
  const type = dialogHandler.type;
  const isCreate = dialogHandler.mode === "create";
  const isEdit = dialogHandler.mode === "edit";
  const isDelete = dialogHandler.mode === "delete";

  const commonProps = {
    showDialog: dialogHandler.show,
    setShowDialog: () => closeDialog(),
    secondaryActionLabel: "取消",
    secondaryActionHandler: () => closeDialog(),
  };

  switch (type) {
    case "fence": {
      if (isCreate || isEdit)
        return (
          <ContentDialog
            {...commonProps}
            maxWidth="md"
            title={isCreate ? "建立作業圍籬" : "編輯作業圍籬"}
            content={
              <UpdateFenceSection
                fence={selectRow}
                ref={formRef}
                videoUrl={streamPreUri}
                fences={fences}
              />
            }
            actionLabel="確認"
            actionHandler={() => (isCreate ? onCreateFence() : onEditFence())}
          />
        );
      if (isDelete)
        return (
          <ContentDialog
            {...commonProps}
            maxWidth="xs"
            title="刪除作業圍籬"
            content={`This will delete ID: ${selectRow?.id} Name: ${selectRow?.name}`}
            actionLabel="確認"
            actionHandler={onDeleteFence}
          />
        );
      break;
    }
    case "condition": {
      if (isCreate || isEdit)
        return (
          <ContentDialog
            {...commonProps}
            maxWidth="xs"
            title={isCreate ? "建立作業觸發條件" : "編輯作業觸發條件"}
            content={
              <UpdateConditionSection
                objects={objects}
                fences={fences}
                ref={formRef}
                condition={isEdit ? selectRow : undefined}
                conditions={conditions}
              />
            }
            actionLabel="確認"
            actionHandler={() => (isCreate ? onCreateCondition() : onEditCondition())}
          />
        );
      if (isDelete)
        return (
          <ContentDialog
            {...commonProps}
            maxWidth="xs"
            title="刪除作業觸發條件"
            content={`This will delete ID: ${selectRow?.id} Name: ${selectRow?.name}`}
            actionLabel="確認"
            actionHandler={onDeleteCondition}
          />
        );
      break;
    }
    case "logic": {
      if (isCreate || isEdit)
        return (
          <ContentDialog
            {...commonProps}
            maxWidth="md"
            title={isCreate ? "建立作業邏輯" : "編輯作業邏輯"}
            content={
              <UpdateLogicSection
                conditions={conditions}
                ref={formRef}
                logic={isEdit ? selectRow : undefined}
                editLevel={dialogHandler.editLevel || "full"}
                logicRows={logicRows}
              />
            }
            actionLabel="確認"
            actionHandler={() => (isCreate ? onCreateLogic() : onEditLogic())}
          />
        );
      if (isDelete)
        return (
          <ContentDialog
            {...commonProps}
            maxWidth="xs"
            title="刪除作業步驟解析邏輯"
            content={`This will delete ID: ${selectRow?.id} Name: ${selectRow?.name}`}
            actionLabel="確認"
            actionHandler={onDeleteLogic}
          />
        );
      break;
    }
    default:
      return null;
  }
};

export default DialogSection;
