import React, { useContext, useEffect, useRef, useState } from "react";
import { Box, Typography, Button, Stack } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import ReactECharts from "echarts-for-react";
import usePieOption from "./usePieOption";
import useLineBarOption from "./useLineBarOption";
import { UserContext } from "../../utils/userContext";
import { backendAPI } from "../../apis/services/backendAPI";
import { NotificationService } from "../NotificationService";
import { TitleLabel } from "../Label";

const TopChartSection = () => {
    const theme = useTheme();
    const [loading, setLoading] = useState(false);
    const { sideBarOpen } = useContext(UserContext);
    const [pieData, setPieData] = useState([]);
    const [barData, setBarData] = useState({
        categories: [],
        barValues: [],
        lineValues: [],
    });

    const pieRef = useRef(null);
    const barRef = useRef(null);

    useEffect(() => {
        const fetchImportStatu = async () => {
            setLoading(true);
            try {
                const response = await backendAPI.getImportStatus();
                if (response?.status !== undefined) {
                    const data = response.data;
        
                    // Pie 資料格式：[{ name: 'fab_name(total)', value: imported_units }]
                    const pie = data.map((item) => ({
                        name: `${item.fab_name}`,
                        value: item.imported_units,
                    }));
        
                    // Bar 資料格式：
                    const bar = {
                        categories: data.map((item) => item.fab_name),
                        barValues: data.map((item) => item.total_units),
                        lineValues: data.map((item) =>
                            Math.round(item.import_rate * 100),
                        ),
                    };
        
                    setPieData(pie);
                    setBarData(bar);
        
                    requestAnimationFrame(() => {
                        pieRef.current?.getEchartsInstance().resize();
                        barRef.current?.getEchartsInstance().resize();
                    });
                } else {
                    NotificationService.handleError("取得導入資料錯誤");
                }
            } catch (err) {
                NotificationService.handleError("取得導入資料錯誤");
            } finally {
                setLoading(false);
            }
        };
    
        fetchImportStatu();
    }, []);    

    useEffect(() => {
        const timeout = setTimeout(() => {
            pieRef.current?.getEchartsInstance().resize();
            barRef.current?.getEchartsInstance().resize();
        }, 300);

        return () => clearTimeout(timeout);
    }, [sideBarOpen]);

    const pieOption = usePieOption(pieData);
    const barOption = useLineBarOption(barData);

    return (
        <Box
            sx={{
                display: "flex",
                gap: 2,
                padding: 3,
                pl: 0,
                pr: 0,
                maxWidth: "100%",
                overflowX: "hidden",
            }}
        >
            {/* Pie chart block */}
            <Box
                sx={{
                    flex: 1,
                    backgroundColor: theme.palette.background.paper1,
                    borderRadius: 2,
                    p: 2,
                    display: "flex",
                    flexDirection: "column",
                }}
            >
                <TitleLabel fontSize={"23px"}>
                    崗位分布
                </TitleLabel>
                <Box sx={{ flex: 1 }}>
                    <ReactECharts
                        ref={pieRef}
                        option={pieOption}
                        style={{ width: "100%", height: 350 }}
                    />
                </Box>
            </Box>

            {/* Bar chart block */}
            <Box
                sx={{
                    flex: 1,
                    backgroundColor: theme.palette.background.paper1,
                    borderRadius: 2,
                    p: 2,
                    display: "flex",
                    flexDirection: "column",
                }}
            >
                <TitleLabel fontSize={"23px"}>
                    各廠導入進度
                </TitleLabel>
                <Box sx={{ flex: 1 }}>
                    <ReactECharts
                        ref={barRef}
                        option={barOption}
                        style={{ width: "100%", height: 350 }}
                    />
                </Box>
            </Box>
        </Box>
    );
};

export default TopChartSection;
