import { useMemo } from "react";
import { useChartToolbox } from "../useChartToolbox";
import { handleDownloadCSV } from "../../utils/handleDownloadCSV";

const useLineBarOption = ({
    categories = [],
    barValues = [],
    lineValues = [],
}) => {
    return useMemo(
        () => ({
            tooltip: {
                trigger: "axis",
            },
            legend: {
                data: ["導入數量", "導入率"],
                textStyle: { color: "#fff" },
            },
            xAxis: {
                type: "category",
                data: categories,
                axisLabel: { color: "#ccc" },
                axisLine: { lineStyle: { color: "#888" } },
            },
            yAxis: [
                {
                    type: "value",
                    name: "導入數量",
                    axisLabel: { color: "#ccc" },
                    axisLine: { lineStyle: { color: "#888" } },
                },
                {
                    type: "value",
                    name: "導入率 (%)",
                    position: "right",
                    axisLabel: { color: "#ccc" },
                    axisLine: { lineStyle: { color: "#888" } },
                },
            ],
            series: [
                {
                    name: "導入數量",
                    type: "bar",
                    data: barValues,
                    barWidth: "40%",
                    barMaxWidth: 50,
                },
                {
                    name: "導入率",
                    type: "line",
                    yAxisIndex: 1,
                    data: lineValues,
                    smooth: true,
                    symbol: "circle",
                    symbolSize: 8,
                    lineStyle: { width: 2 },
                },
            ],
            toolbox: useChartToolbox(handleDownloadCSV),
        }),
        [categories, barValues, lineValues],
    );
};

export default useLineBarOption;
