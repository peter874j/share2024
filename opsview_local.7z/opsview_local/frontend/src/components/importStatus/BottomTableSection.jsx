import React, { useEffect, useRef, useState, useMemo } from "react";
import { Box, Button, IconButton } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { useNavigate } from "react-router-dom";
import { useTheme } from "@mui/material/styles";
import StatusChip from "../EquipmentPage/StatusChip";
import CustomToolbar from "../CustomToolbar";
import WorkIcon from "@mui/icons-material/Work";
import EditIcon from "@mui/icons-material/Edit";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import { NotificationService } from "../NotificationService";
import { TitleLabel } from "../Label";
import DialogSection from "./DialogSection";
import { backendAPI } from "../../apis/services/backendAPI";
import { useDebouncedValue } from "../../utils/useDebouncedValue";

const BottomTableSection = () => {
    const theme = useTheme();

    const [rows, setRows] = useState([]);
    const [rowCount, setRowCount] = useState(0);
    const [loading, setLoading] = useState(false);
    const [searchInput, setSearchInput] = useState("")
    const debouncedSearch = useDebouncedValue(searchInput, 300)
    const [fabOptions, setFabOptions] = useState([]);
    const [departOptions, setDepartOptions] = useState([]);
    const [stagOptions, setStagOptions] = useState([]);
    const [updateTrigger, setUpdateTrigger] = useState(0);
    const isTyping = searchInput !== debouncedSearch;
    const [dialogHandler, setDialogHandler] = useState({
        show: false,
        mode: null,
    });
    const [sortModel, setSortModel] = useState([{
        field: "id",
        sort: "asc",
    }]);
    const [paginationModel, setPaginationModel] = useState({
        pageSize: 5,
        page: 0,
    });

    const editRowIdRef = useRef(null);
    const editUnitSectionRef = useRef(null);

    useEffect(() => {
        const fetchUnitInfo = async () => {
            setLoading(true);
            try {
                const currentSort = sortModel[0] || { field: "id", sort: "asc" };
    
                const response = await backendAPI.getUnitInfo({
                    page: paginationModel.page + 1,
                    limit: paginationModel.pageSize,
                    sortField: currentSort.field,
                    sortOrder: currentSort.sort,
                    searchKeyword: debouncedSearch,
                });

                if (response?.status !== undefined) {
                    const transformed = response.data?.data.map((item) => ({
                        id: item?.id,
                        fab: item?.stage.fab.name,
                        department: item?.stage.department.name,
                        stage: item?.stage.name,
                        unit: item?.name,
                        import_status: item?.import_status,
                        programStatus: item?.server_status ? "online" : "offline",
                        cam: item?.cams[0],
                    }));
    
                    setRows(transformed);
                    setRowCount(response.data.total_count);
                } else {
                    NotificationService.handleError("取得崗位資料錯誤")
                }
            } catch (err) {
                NotificationService.handleError("取得崗位資料錯誤")
            } finally {
                setLoading(false);
            }
        };
    
        fetchUnitInfo();
    }, [paginationModel, sortModel, updateTrigger, debouncedSearch]);   
    
    useEffect(() => {
        setPaginationModel((prev) => ({ ...prev, page: 0}));
    }, [debouncedSearch]);

    useEffect(() => {
        const updateFabOptions = new Set();
        const updateDepartOptions = new Set();
        const updateStageOptions = new Set();
        rows?.forEach((row) => {
            updateFabOptions.add(row.fab);
            updateDepartOptions.add(row.department);
            updateStageOptions.add(row.stage);
        });

        setFabOptions([...updateFabOptions]);
        setDepartOptions([...updateDepartOptions]);
        setStagOptions([...updateStageOptions]);
    }, [rows]);

    const columns = useMemo(() => [
        {
            field: "fab",
            headerName: "廠區",
            flex: 1,
            headerClassName: "custom-header",
        },
        {
            field: "department",
            headerName: "崗位部門",
            flex: 1,
            headerClassName: "custom-header",
        },
        {
            field: "stage",
            headerName: "站點",
            flex: 1,
            headerClassName: "custom-header",
        },
        {
            field: "unit",
            headerName: "崗位",
            flex: 2,
            headerClassName: "custom-header",
        },
        {
            field: "import_status",
            headerName: "導入狀態",
            flex: 1,
            headerClassName: "custom-header",
            renderCell: (params) => (
                params.value === "undo" ? "規劃中" : "已導入"
            ),
        },
        {
            field: "programStatus",
            headerName: "程式狀態",
            flex: 1,
            headerClassName: "custom-header",
            sortable: false,
            renderCell: (params) => (
                <StatusChip status={params.value === "online" ? true : false} />
            ),
        },
        {
            field: "action",
            headerName: "崗位管理",
            flex: 1,
            sortable: false,
            filterable: false,
            headerClassName: "custom-header",
            renderCell: (params) => {
                const navigate = useNavigate();
                return (
                    <Button
                        variant="outlined"
                        size="small"
                        onClick={() =>
                            navigate(`/h/unit/${params.row.id}`, {
                                state: params.row,
                            })
                        }
                    >
                        AI 參數
                    </Button>
                );
            },
        },
        {
            field: "edit",
            headerName: "編輯",
            width: 60,
            sortable: false,
            filterable: false,
            headerClassName: "custom-header",
            align: "center",
            headerAlign: "center",
            renderCell: (params) => {
                return (
                    <IconButton
                        onClick={() => {
                            handleEditClick(params.id);
                        }}
                    >
                        <EditIcon />
                    </IconButton>
                );
            },
        },
        {
            field: "del",
            headerName: "刪除",
            width: 60,
            sortable: false,
            filterable: false,
            headerClassName: "custom-header",
            align: "center",
            headerAlign: "center",
            renderCell: (params) => {
                return (
                    <IconButton>
                        <DeleteForeverIcon
                            onClick={() => {
                                handleDelClick(params.id);
                            }}
                        />
                    </IconButton>
                );
            },
        },
    ], []);

    const handleAddClick = () => {
        setDialogHandler({
            show: true,
            mode: "add",
        });
    };

    const handleEditClick = (editId) => {
        editRowIdRef.current = editId;
        setDialogHandler({
            show: true,
            mode: "edit",
        });
    };

    const handleDelClick = (editId) => {
        editRowIdRef.current = editId;
        setDialogHandler({
            show: true,
            mode: "del",
        });
    };

    const handleDialogSection = () => {
        // 新增崗位
        if (dialogHandler.mode === "add") {
            const isValid = editUnitSectionRef.current.validate();
            if (isValid) {
                addUnit();
            }
        }
        // 編輯崗位
        else if (dialogHandler.mode === "edit") {
            const isValid = editUnitSectionRef.current.validate();
            if (isValid) {
                editUnit();
            }
        }

        // // 刪除崗位
        else if (dialogHandler.mode === "del") {
            delUnit();
        }
    };

    const resetDialogHandler = () => {
        setDialogHandler({
            show: false,
            mode: null,
        });
    };

    const getUnitInfo = () => {
        const editRow = rows.find((row) => row.id === editRowIdRef.current);
        return {
            fab: editRow.fab,
            depart: editRow.department,
            stage: editRow.stage,
            unit: editRow.unit,
        };
    };

    // 確認新增崗位
    const addUnit = async () => {
        const newUnit = editUnitSectionRef.current.getNewUnit();
        const response = await backendAPI.createUnit(newUnit);
        if (response?.status !== undefined) {
            NotificationService.handleInfo("崗位新增成功");
            setUpdateTrigger((prev) => prev + 1);
        } else {
            NotificationService.handleError("An unexpected error occurred. Please try again later.");
        }
        resetDialogHandler();
    };

    // 確認編輯崗位
    const editUnit = async () => {
        const newUnit = editUnitSectionRef.current.getNewUnit();
        const response = await backendAPI.updateUnit(editRowIdRef.current, newUnit);
        if (response?.status !== undefined) {
            NotificationService.handleInfo("崗位更新成功");
            setUpdateTrigger((prev) => prev + 1);
        } else {
            NotificationService.handleError("An unexpected error occurred. Please try again later.");
        }
        resetDialogHandler();
    };

    const delUnit = async () => {
        const response = await backendAPI.deleteUnit(editRowIdRef.current);
        if (response?.status !== undefined) {
            NotificationService.handleInfo("崗位刪除成功");
            setUpdateTrigger((prev) => prev + 1);
        } else {
            NotificationService.handleError("An unexpected error occurred. Please try again later.");
        }
        resetDialogHandler();
    };

    return (
        <Box sx={{ height: "100%", overflow: "auto" }}>
            {/* 新增崗位按鈕 */}
            <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 1 }}>
                <TitleLabel fontSize={"24px"}>
                    崗位清單
                </TitleLabel>
                <Button
                    variant="contained"
                    startIcon={<WorkIcon />}
                    onClick={handleAddClick}
                    sx={{
                        color: "white",
                        bgcolor: theme.palette.avatar.default,
                    }}
                >
                    新增崗位
                </Button>
            </Box>

            <DataGrid
                showToolbar
                rows={rows}
                columns={columns}
                rowCount={rowCount}
                loading={loading && !isTyping}
                paginationMode="server"
                paginationModel={paginationModel}
                onPaginationModelChange={setPaginationModel}
                sortingMode="server"
                sortModel={sortModel}
                onSortModelChange={setSortModel}
                disableColumnFilter
                disableColumnMenu
                disableMultipleColumnsSorting
                pageSizeOptions={[5, 10, 20]}
                disableRowSelectionOnClick
                slots={{ toolbar: CustomToolbar }}
                slotProps={{
                  toolbar: {
                    searchInput,
                    setSearchInput,
                  },
                }}
                sx={{
                    minHeight: 370,
                    height: "100%",
                    color: theme.palette.text.primary,
                    "& .custom-header, & .MuiDataGrid-toolbar": {
                        backgroundColor: theme.palette.background.paper1,
                        color: theme.palette.text.primary,
                        fontWeight: "bold",
                    },
                    "& .MuiDataGrid-cell": {
                        borderBottom: "1px solid #333",
                    },
                }}
            />
            {dialogHandler.show && (
                <DialogSection
                    dialogHandler={dialogHandler}
                    setDialogHandler={setDialogHandler}
                    editUnitSectionRef={editUnitSectionRef}
                    handleDialogSection={handleDialogSection}
                    resetDialogHandler={resetDialogHandler}
                    getUnitInfo={getUnitInfo}
                    fabOptions={fabOptions}
                    departOptions={departOptions}
                    stagOptions={stagOptions}
                />
            )}
        </Box>
    );
};

export default BottomTableSection;
