import { useMemo } from "react";
import { useChartToolbox } from "../useChartToolbox";
import { handleDownloadCSV } from "../../utils/handleDownloadCSV";

const usePieOption = (rawData = []) => {
    return useMemo(() => {
        const total = rawData.reduce((sum, item) => sum + item.value, 0);

        const dataWithPercentage = rawData.map((item) => {
            const percent = ((item.value / total) * 100).toFixed(1);
            return {
                ...item,
                displayName: `${item.name} (${percent}%)`,
                percent,
            };
        });

        return {
            tooltip: {
                trigger: "item",
                formatter: (params) => `${params.name}`,
            },
            legend: {
                orient: "vertical",
                right: 0,
                top: "center",
                textStyle: { color: "#fff" },
                data: dataWithPercentage.map((item) => item.displayName),
            },
            series: [
                {
                    name: "崗位分布",
                    type: "pie",
                    radius: ["40%", "70%"],
                    center: ["40%", "50%"],
                    avoidLabelOverlap: false,
                    label: {
                        show: false,
                        formatter: ({ data }) => `${data.displayName}`,
                        color: "#fff",
                    },
                    emphasis: {
                        label: {
                            show: false,
                            fontSize: 18,
                            fontWeight: "bold",
                        },
                    },
                    labelLine: {
                        show: true,
                    },
                    data: dataWithPercentage.map((item) => ({
                        name: item.displayName,
                        value: item.value,
                        displayName: item.displayName, // for formatter use
                    })),
                },
            ],
            toolbox: useChartToolbox(handleDownloadCSV),
        };
    }, [rawData]);
};

export default usePieOption;
