import { Autocomplete, Box, TextField } from "@mui/material";
import React, { useImperativeHandle, useState } from "react";

const EditUnitSection = ({
    fabOptions,
    departOptions,
    stagOptions,
    initState = {
        fab: "",
        depart: "",
        stage: "",
        unit: "",
    },
    ref,
}) => {
    const [fabInput, setFabInput] = useState(initState.fab);
    const [departInput, setDepartInput] = useState(initState.depart);
    const [stageInput, setStageInput] = useState(initState.stage);
    const [unitInput, setUnitInput] = useState(initState.unit);
    const [errors, setErrors] = useState({
        fab: false,
        depart: false,
        stage: false,
        unit: false,
    });

    const validate = () => {
        const newErrors = { ...errors };
        newErrors.fab = fabInput === "";
        newErrors.depart = departInput === "";
        newErrors.stage = stageInput === "";
        newErrors.unit = unitInput === "";
        setErrors(newErrors);
        return !Object.values(newErrors).includes(true); // 回傳是否通過驗證
    };

    const getNewUnit = () => {
        return {
            fab_name: fabInput,
            department_name: departInput,
            stage_name: stageInput,
            unit_name: unitInput,
        };
    };

    useImperativeHandle(ref, () => ({
        validate,
        getNewUnit,
    }));

    return (
        <Box display="flex" flexDirection="Column" gap={2}>
            <Autocomplete
                freeSolo
                options={fabOptions}
                value={fabInput}
                onInputChange={(_, newValue) => {
                    setFabInput(newValue);
                }}
                renderInput={(params) => (
                    <TextField
                        {...params}
                        required
                        label="廠區"
                        error={errors.fab}
                        helperText={errors.fab && "請輸入廠區名稱"}
                    />
                )}
            />
            <Autocomplete
                freeSolo
                options={departOptions}
                value={departInput}
                onInputChange={(_, newValue) => {
                    setDepartInput(newValue);
                }}
                renderInput={(params) => (
                    <TextField
                        {...params}
                        required
                        label="崗位部門"
                        error={errors.depart}
                        helperText={errors.depart && "請輸入崗位所屬部門名稱"}
                    />
                )}
            />
            <Autocomplete
                freeSolo
                options={stagOptions}
                value={stageInput}
                onInputChange={(_, newValue) => {
                    setStageInput(newValue);
                }}
                renderInput={(params) => (
                    <TextField
                        {...params}
                        required
                        label="站點"
                        error={errors.stage}
                        helperText={errors.stage && "請輸入站點名稱"}
                    />
                )}
            />
            <TextField
                required
                label="崗位"
                value={unitInput}
                onChange={(event) => {
                    setUnitInput(event.target.value);
                }}
                error={errors.unit}
                helperText={errors.unit && "請輸入崗位名稱"}
            />
        </Box>
    );
};

export default EditUnitSection;
