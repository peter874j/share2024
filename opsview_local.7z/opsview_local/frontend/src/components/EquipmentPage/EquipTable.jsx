import {
    Box,
    Button,
    styled,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TablePagination,
    TableRow,
    Typography,
    useTheme,
} from "@mui/material";
import { useEffect, useRef, useState } from "react";
import PcRow from "./PcRow";
import ComputerIcon from "@mui/icons-material/Computer";
import DialogSection from "./DialogSection";
import { NotificationService } from "../NotificationService";
import { backendAPI } from "../../apis/services/backendAPI";
import { getIsAdmin } from "../../apis/utils/roleManager";

function dataFilter(equipDatas, filterSelects) {
    const filterDatas = [];
    for (const equipData of equipDatas) {
        const pcStatus = equipData.pcStatus ? "Online" : "Offline";
        // 篩選主機
        if (filterSelects.pcStatus.includes(pcStatus)) {
            // 如果主機沒有攝影機, 不受攝影機篩選條件影響
            if (equipData.cameras.length === 0) {
                filterDatas.push(equipData);
            } else {
                // 篩選攝影機
                const filterCameras = [];
                for (const camera of equipData.cameras) {
                    const camStatus = camera.camStatus ? "Online" : "Offline";
                    if (
                        filterSelects.stage.includes(camera.stage) &&
                        filterSelects.unit.includes(camera.unit) &&
                        filterSelects.camStatus.includes(camStatus)
                    ) {
                        filterCameras.push(camera);
                    }
                }

                // 至少有一台通過篩選的攝影機
                if (filterCameras.length > 0) {
                    filterDatas.push({ ...equipData, cameras: filterCameras });
                }
            }
        }
    }
    return filterDatas;
}

const EquipTable = (props) => {
    const {
        fab,
        currentUser,
        equipDatas,
        filterSelects,
        setEquipDatas,
        loadEquipDatas,
    } = props;
    const isAdmin = currentUser?.role ? getIsAdmin(currentUser.role) : false;

    const [filterDatas, setFilterDatas] = useState([]); // 篩選後設備狀態資料
    const [dialogHandler, setDialogHandler] = useState({
        show: false,
        type: null, // "pc" or "cam"
        mode: null, // "add" or "edit" or "del"
    });
    const dialogSectionRef = useRef(null);
    const editPcIdRef = useRef(null);
    const editCamIdRef = useRef(null);

    const theme = useTheme();
    const StyledTitleCell = styled(TableCell)({
        fontSize: "16px",
        fontWeight: "bold",
        backgroundColor: theme.palette.background.paper1,
    });

    const [page, setPage] = useState(0);
    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const [rowsPerPage, setRowsPerPage] = useState(5);
    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(event.target.value);
        setPage(0);
    };

    // 修改篩選條件時, 重新篩選資料
    useEffect(() => {
        const filterDatas = dataFilter(equipDatas, filterSelects);
        setFilterDatas(filterDatas);
    }, [equipDatas, filterSelects]);

    // 顯示資料修改時回到第一頁
    useEffect(() => {
        setPage(0);
    }, [filterDatas]);

    // 新增主機按鈕被按下
    const handleAddPcClick = () => {
        setDialogHandler({
            show: true,
            type: "pc",
            mode: "add",
        });
    };

    // 確認新增主機
    const handleAddPc = () => {
        const isValid = dialogSectionRef.current.validate(); // 檢查內容
        if (isValid) {
            const newPc = dialogSectionRef.current.getNewPc();
            backendAPI
                .addPc(fab.id, newPc.pcName, newPc.pcIp)
                .then((resp) => {
                    if (!resp.status) {
                        throw new Error(resp);
                    }
                    const newPcId = resp.data.id;
                    console.log("新增主機成功, ID: ", newPcId);

                    loadEquipDatas(); // 重新載入設備資料
                    resetDialog();
                    NotificationService.handleInfo("新增主機成功");
                })
                .catch((error) => {
                    NotificationService.handleError(`新增主機失敗 ${error}`);
                });
        }
    };

    // 編輯主機被按下
    const handleEditPcClick = (editPcId) => {
        editPcIdRef.current = editPcId;
        setDialogHandler({
            show: true,
            type: "pc",
            mode: "edit",
        });
    };

    // 確認編輯主機
    const handleEditPc = () => {
        const isValid = dialogSectionRef.current.validate(); // 檢查內容
        if (isValid) {
            const updatePc = dialogSectionRef.current.getNewPc();
            backendAPI
                .editPc(
                    editPcIdRef.current,
                    updatePc.pcName,
                    updatePc.pcIp,
                    equipDatas.find(
                        (equipData) => equipData.pcId === editPcIdRef.current,
                    ).status,
                )
                .then((resp) => {
                    if (!resp.status) {
                        throw new Error(resp);
                    }
                    // 更新資料
                    setEquipDatas((prevEquipDatas) =>
                        prevEquipDatas.map((equipData) => {
                            if (equipData.pcId === editPcIdRef.current) {
                                return {
                                    ...equipData,
                                    ...updatePc, // 覆蓋屬性
                                };
                            } else {
                                return equipData;
                            }
                        }),
                    );
                    NotificationService.handleInfo("主機編輯成功");
                    resetDialog();
                })
                .catch((error) => {
                    NotificationService.handleError(`主機編輯失敗 ${error}`);
                });
        }
    };

    // 刪除主機按鈕被按下
    const handleDelPcClick = (delPcId) => {
        editPcIdRef.current = delPcId;
        setDialogHandler({
            show: true,
            type: "pc",
            mode: "del",
        });
    };

    // 確認刪除主機
    const handleDelPc = () => {
        backendAPI
            .delPc(editPcIdRef.current)
            .then((resp) => {
                if (!resp.status) {
                    throw new Error(resp);
                }
                loadEquipDatas(); // 重新載入設備資料
                resetDialog();
                NotificationService.handleInfo("主機刪除成功");
            })
            .catch((error) => {
                NotificationService.handleError(`主機刪除失敗: ${error}`);
            });
        NotificationService.handleInfo("主機刪除成功");
        resetDialog();
    };

    // 新增攝影機按紐被按下
    const handleAddCamClick = (editPcId) => {
        editPcIdRef.current = editPcId;
        setDialogHandler({
            show: true,
            type: "cam",
            mode: "add",
        });
    };

    // 確認新增攝影機
    const handleAddCam = () => {
        const isValid = dialogSectionRef.current.validate(); // 檢查內容
        if (isValid) {
            const addCam = dialogSectionRef.current.getNewCam();
            const editPc = equipDatas.find(
                (equipData) => equipData.pcId === editPcIdRef.current,
            );
            backendAPI
                .addCam(
                    editPc.pcId,
                    addCam.stage.id,
                    addCam.unit.id,
                    addCam.camIp,
                    addCam.aiServicePort,
                )
                .then((resp) => {
                    if (!resp.status) {
                        throw new Error(resp);
                    }
                    NotificationService.handleInfo("新增攝影機成功");
                    loadEquipDatas(); // 重新載入設備資料
                    resetDialog();
                })
                .catch((error) => {
                    NotificationService.handleError(`新增攝影機失敗 ${error}`);
                });
        }
    };

    // 編輯攝影機按紐被按下
    const handleEditCamClick = (editPcId, editCamId) => {
        editPcIdRef.current = editPcId;
        editCamIdRef.current = editCamId;
        setDialogHandler({
            show: true,
            type: "cam",
            mode: "edit",
        });
    };

    // 確認編輯攝影機
    const handleEditCam = () => {
        const isValid = dialogSectionRef.current.validate(); // 檢查內容
        if (isValid) {
            const updateCam = dialogSectionRef.current.getNewCam();
            backendAPI
                .editCam(
                    editCamIdRef.current,
                    updateCam.stage.id,
                    updateCam.unit.id,
                    updateCam.camIp,
                    updateCam.aiServicePort,
                )
                .then((resp) => {
                    if (!resp.status) {
                        throw new Error(resp);
                    }

                    // 更新資料
                    setEquipDatas((preEquipDatas) =>
                        preEquipDatas.map((equipData) => {
                            if (equipData.pcId === editPcIdRef.current) {
                                return {
                                    ...equipData,
                                    cameras: equipData.cameras.map((camera) => {
                                        if (
                                            camera.camId ===
                                            editCamIdRef.current
                                        ) {
                                            return {
                                                ...camera,
                                                stage: updateCam.stage.name,
                                                unit: updateCam.unit.name,
                                                camIp: updateCam.camIp,
                                                aiServicePort:
                                                    updateCam.aiServicePort,
                                            };
                                        }
                                        return camera;
                                    }),
                                };
                            }
                            return equipData;
                        }),
                    );

                    resetDialog();
                    NotificationService.handleInfo("攝影機編輯成功");
                })
                .catch((error) => {
                    NotificationService.handleError(`編輯攝影機失敗 ${error}`);
                });
        }
    };

    // 刪除攝影機按紐被按下
    const handleDelCamClick = (delPcId, delCamId) => {
        editPcIdRef.current = delPcId;
        editCamIdRef.current = delCamId;
        setDialogHandler({
            show: true,
            type: "cam",
            mode: "del",
        });
    };

    // 確認刪除攝影機
    const handleDelCam = () => {
        backendAPI
            .delCam(editCamIdRef.current)
            .then((resp) => {
                if (!resp.status) {
                    throw new Error(resp);
                }
                loadEquipDatas(); // 重新載入設備資料
                resetDialog();
                NotificationService.handleInfo("攝影機刪除成功");
            })
            .catch((error) => {
                NotificationService.handleError(`刪除攝影機失敗: ${error}`);
            });
    };

    // 關閉並重置彈出視窗
    const resetDialog = () => {
        setDialogHandler({
            show: false,
            type: null,
            mode: null,
        });
        editPcIdRef.current = null;
        editCamIdRef.current = null;
    };

    return (
        <Box
            sx={{
                width: "100%",
            }}
        >
            <Box
                sx={{
                    width: "100%",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    mb: 1,
                }}
            >
                <Typography variant="h6">主機列表</Typography>
                {/* 新增主機 */}
                <Button
                    variant="contained"
                    startIcon={<ComputerIcon />}
                    onClick={handleAddPcClick}
                    disabled={!isAdmin}
                    sx={{
                        color: "white",
                        bgcolor: theme.palette.avatar.default,
                    }}
                >
                    新增主機
                </Button>
            </Box>
            <TableContainer>
                <Table stickyHeader>
                    <TableHead>
                        <TableRow>
                            <StyledTitleCell
                                align="center"
                                sx={{ padding: 0, width: "120px" }}
                            ></StyledTitleCell>
                            <StyledTitleCell align="center">
                                主機名稱
                            </StyledTitleCell>
                            <StyledTitleCell align="center">
                                主機 IP
                            </StyledTitleCell>
                            <StyledTitleCell align="center">
                                主機狀態
                            </StyledTitleCell>
                            <StyledTitleCell align="center">
                                編輯/刪除
                            </StyledTitleCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {filterDatas
                            .slice(
                                page * rowsPerPage,
                                page * rowsPerPage + rowsPerPage,
                            )
                            .map((equipData) => (
                                <PcRow
                                    key={equipData.pcId}
                                    isAdmin={isAdmin}
                                    equipData={equipData}
                                    handleEditPcClick={handleEditPcClick}
                                    handleDelPcClick={handleDelPcClick}
                                    handleAddCamClick={handleAddCamClick}
                                    handleEditCamClick={handleEditCamClick}
                                    handleDelCamClick={handleDelCamClick}
                                ></PcRow>
                            ))}
                    </TableBody>
                </Table>
            </TableContainer>
            <TablePagination
                rowsPerPageOptions={[5, 10, 15]}
                component="div"
                count={filterDatas.length}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                labelDisplayedRows={({ from, to, count }) => {
                    return `Page ${page + 1} of ${Math.ceil(count / rowsPerPage)}`;
                }}
                onRowsPerPageChange={handleChangeRowsPerPage}
                labelRowsPerPage="每頁顯示主機數:"
            />
            {dialogHandler.show && (
                <DialogSection
                    fabName={fab.name}
                    equipDatas={equipDatas}
                    dialogHandler={dialogHandler}
                    setDialogHandler={setDialogHandler}
                    dialogSectionRef={dialogSectionRef}
                    editPcIdRef={editPcIdRef}
                    editCamIdRef={editCamIdRef}
                    handleAddPc={handleAddPc}
                    handleEditPc={handleEditPc}
                    handleDelPc={handleDelPc}
                    handleAddCam={handleAddCam}
                    handleEditCam={handleEditCam}
                    handleDelCam={handleDelCam}
                    resetDialog={resetDialog}
                />
            )}
        </Box>
    );
};

export default EquipTable;
