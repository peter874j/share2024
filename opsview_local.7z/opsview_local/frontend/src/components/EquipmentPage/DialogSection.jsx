import PcDialogSection from "./PcDialogSection";
import ContentDialog from "../ContentDialog";
import CamDialogSection from "./CamDialogSection";

const DialogSection = (props) => {
    const {
        fabName,
        equipDatas,
        dialogHandler,
        setDialogHandler,
        dialogSectionRef,
        editPcIdRef,
        editCamIdRef,
        handleAddPc,
        handleEditPc,
        handleDelPc,
        handleAddCam,
        handleEditCam,
        handleDelCam,
        resetDialog,
    } = props;

    const setShowDialog = (showDialog) => {
        setDialogHandler({
            ...dialogHandler,
            show: showDialog,
        });
    };

    if (dialogHandler.show) {
        // 新增主機
        if (dialogHandler.type === "pc" && dialogHandler.mode === "add") {
            return (
                <ContentDialog
                    maxWidth="sm"
                    showDialog={dialogHandler.show}
                    setShowDialog={setShowDialog}
                    title={"新增主機"}
                    content={
                        <PcDialogSection mode="add" ref={dialogSectionRef} />
                    }
                    actionLabel={"確認"}
                    actionHandler={handleAddPc}
                    secondaryActionLabel={"取消"}
                    secondaryActionHandler={resetDialog}
                />
            );
        }

        // 編輯主機
        if (dialogHandler.type === "pc" && dialogHandler.mode === "edit") {
            const editPc = equipDatas.find(
                (equipData) => equipData.pcId === editPcIdRef.current,
            );
            return (
                <ContentDialog
                    maxWidth="sm"
                    showDialog={dialogHandler.show}
                    setShowDialog={setShowDialog}
                    title={"編輯主機"}
                    content={
                        <PcDialogSection
                            mode={"edit"}
                            initState={{
                                pcName: editPc.pcName,
                                pcIp: editPc.pcIp,
                            }}
                            ref={dialogSectionRef}
                        />
                    }
                    actionLabel={"確認"}
                    actionHandler={handleEditPc}
                    secondaryActionLabel={"取消"}
                    secondaryActionHandler={resetDialog}
                />
            );
        }

        // 刪除主機
        if (dialogHandler.type === "pc" && dialogHandler.mode === "del") {
            const delPc = equipDatas.find(
                (equipData) => equipData.pcId === editPcIdRef.current,
            );
            return (
                <ContentDialog
                    maxWidth="xs"
                    showDialog={dialogHandler.show}
                    setShowDialog={setShowDialog}
                    title={"刪除主機"}
                    message={`確定要刪除主機 ${delPc?.pcName} (${delPc?.pcIp}) 嗎？`}
                    actionLabel={"確認"}
                    actionHandler={handleDelPc}
                    secondaryActionLabel={"取消"}
                    secondaryActionHandler={resetDialog}
                />
            );
        }

        // 新增攝影機
        if (dialogHandler.type === "cam" && dialogHandler.mode === "add") {
            return (
                <ContentDialog
                    maxWidth="sm"
                    showDialog={dialogHandler.show}
                    setShowDialog={setShowDialog}
                    title={"新增攝影機"}
                    content={
                        <CamDialogSection
                            fabName={fabName}
                            ref={dialogSectionRef}
                        />
                    }
                    actionLabel={"確認"}
                    actionHandler={handleAddCam}
                    secondaryActionLabel={"取消"}
                    secondaryActionHandler={resetDialog}
                />
            );
        }

        // 編輯攝影機
        if (dialogHandler.type === "cam" && dialogHandler.mode === "edit") {
            const editPc = equipDatas.find(
                (equipData) => equipData.pcId === editPcIdRef.current,
            );
            const editCam = editPc.cameras.find(
                (camera) => camera.camId === editCamIdRef.current,
            );
            return (
                <ContentDialog
                    maxWidth="sm"
                    showDialog={dialogHandler.show}
                    setShowDialog={setShowDialog}
                    title={"編輯攝影機"}
                    content={
                        <CamDialogSection
                            fabName={fabName}
                            initState={{
                                stage: editCam.stage,
                                unit: editCam.unit,
                                camIp: editCam.camIp,
                                aiServicePort: editCam.aiServicePort,
                            }}
                            ref={dialogSectionRef}
                        />
                    }
                    actionLabel={"確認"}
                    actionHandler={handleEditCam}
                    secondaryActionLabel={"取消"}
                    secondaryActionHandler={resetDialog}
                />
            );
        }

        // 刪除攝影機
        if (dialogHandler.type === "cam" && dialogHandler.mode === "del") {
            const delPc = equipDatas.find(
                (equipData) => equipData.pcId === editPcIdRef.current,
            );
            const delCam = delPc.cameras.find(
                (camera) => camera.camId === editCamIdRef.current,
            );
            return (
                <ContentDialog
                    maxWidth="xs"
                    showDialog={dialogHandler.show}
                    setShowDialog={setShowDialog}
                    title={"刪除攝影機"}
                    message={`確定要刪除攝影機 ${delCam?.unit} (${delCam?.camIp}) 嗎？`}
                    actionLabel={"確認"}
                    actionHandler={handleDelCam}
                    secondaryActionLabel={"取消"}
                    secondaryActionHandler={resetDialog}
                />
            );
        }
    }
};

export default DialogSection;
