import { Box, TextField, Typography } from "@mui/material";
import { useImperativeHandle, useState } from "react";
import { isValidIp } from "../../utils/validUtils";

const PcDialogSection = ({
    mode,
    initState = {
        pcName: "",
        pcIp: "",
    },
    ref,
}) => {
    const [pcName, setPcName] = useState(initState.pcName);
    const [pcIp, setPcIp] = useState(initState.pcIp);

    const [errors, setErrors] = useState({
        pcName: false,
        pcIp: false,
    });

    // 驗證輸入
    const validate = () => {
        const newErrors = { ...errors };
        newErrors.pcName = pcName === "";
        newErrors.pcIp = !isValidIp(pcIp);
        setErrors(newErrors);

        // 回傳是否通過驗證
        if (mode == "add") {
            return !Object.values(newErrors).includes(true);
        } else {
            return !Object.values(newErrors).includes(true);
        }
    };

    const getNewPc = () => {
        if (mode == "add") {
            return {
                pcName: pcName,
                pcIp: pcIp,
                cameras: [],
            };
        } else {
            return {
                pcName: pcName,
                pcIp: pcIp,
            };
        }
    };

    // 將函數暴露給父件使用
    useImperativeHandle(ref, () => ({
        validate,
        getNewPc,
    }));

    return (
        <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
            {/* 主機資訊 */}
            <Box display="flex" flexDirection="Column" gap={2}>
                <Typography variant="h6">主機資訊</Typography>
                <TextField
                    required
                    label="主機名稱"
                    value={pcName}
                    onChange={(event) => {
                        setPcName(event.target.value);
                    }}
                    error={errors.pcName}
                    helperText={errors.pcName && "主機名稱不得為空"}
                />
                <TextField
                    required
                    label="主機 IP"
                    value={pcIp}
                    onChange={(event) => {
                        setPcIp(event.target.value);
                    }}
                    error={errors.pcIp}
                    helperText={errors.pcIp && "請輸入正確的 IP 位置"}
                />
            </Box>
        </Box>
    );
};
export default PcDialogSection;
