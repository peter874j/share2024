import {
    Box,
    Button,
    Collapse,
    IconButton,
    styled,
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableRow,
    Typography,
    useTheme,
} from "@mui/material";
import { useEffect, useRef, useState } from "react";
import StatusChip from "../EquipmentPage/StatusChip";
import { KeyboardArrowDown, KeyboardArrowUp } from "@mui/icons-material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import VideocamIcon from "@mui/icons-material/Videocam";

const PcTitleCell = styled(TableCell)(({ theme }) => ({
    borderBottom: "none",
}));

const PcRow = ({
    isAdmin,
    equipData,
    handleEditPcClick,
    handleDelPcClick,
    handleAddCamClick,
    handleEditCamClick,
    handleDelCamClick,
}) => {
    const theme = useTheme();
    const StyledTitleCell = styled(TableCell)({
        fontSize: "16px",
        fontWeight: "bold",
        backgroundColor: theme.palette.background.paper2,
    });

    const [open, setOpen] = useState(true);
    const [rowHeight, setRowHeight] = useState(0);
    const [arrowButtonWidth, setArrowButtonWidth] = useState(0);
    const rowRef = useRef(null);
    const arrowButtonRef = useRef(null);
    const maxCamShow = 3;

    useEffect(() => {
        if (rowRef.current) {
            setRowHeight(rowRef.current.clientHeight);
        }
    }, [rowRef]);

    useEffect(() => {
        if (arrowButtonRef.current) {
            setArrowButtonWidth(arrowButtonRef.current.clientHeight);
        }
    }, [arrowButtonRef]);

    return (
        <>
            {/* 主機資訊 */}
            <TableRow>
                <PcTitleCell align="center" ref={arrowButtonRef}>
                    <IconButton
                        aria-label="expand row"
                        size="small"
                        onClick={() => setOpen(!open)}
                        disabled={!isAdmin}
                    >
                        {open ? <KeyboardArrowUp /> : <KeyboardArrowDown />}
                    </IconButton>
                </PcTitleCell>
                <PcTitleCell align="center">{equipData.pcName}</PcTitleCell>
                <PcTitleCell align="center">{equipData.pcIp}</PcTitleCell>
                <PcTitleCell align="center">
                    <StatusChip status={equipData.pcStatus}></StatusChip>
                </PcTitleCell>
                <PcTitleCell align="center">
                    <IconButton
                        onClick={() => {
                            handleEditPcClick(equipData.pcId);
                        }}
                        disabled={!isAdmin}
                    >
                        <EditIcon />
                    </IconButton>
                    <IconButton
                        onClick={() => {
                            handleDelPcClick(equipData.pcId);
                        }}
                        disabled={!isAdmin}
                    >
                        <DeleteForeverIcon />
                    </IconButton>
                </PcTitleCell>
            </TableRow>

            <TableRow>
                <TableCell
                    style={{ paddingBottom: 0, paddingTop: 0 }}
                    colSpan={5}
                    sx={{ borderBottomWidth: "3px" }}
                >
                    {/* 摺疊區域 */}
                    <Collapse
                        in={open}
                        timeout="auto"
                        unmountOnExit
                        sx={{ padding: 1 }}
                    >
                        <Box
                            sx={{
                                width: "100%",
                                display: "flex",
                                justifyContent: "space-between",
                                alignItems: "center",
                                pl: `${arrowButtonWidth}px`,
                                mb: 1,
                            }}
                        >
                            <Typography variant="h6">攝影機列表</Typography>
                        </Box>

                        <Box
                            sx={{
                                maxHeight:
                                    rowHeight == 0
                                        ? null
                                        : `${rowHeight * (maxCamShow + 1)}px`,
                                overflow: "auto",
                                paddingLeft: `${arrowButtonWidth}px`,
                            }}
                        >
                            {/* 攝影機資訊 */}
                            <Table stickyHeader>
                                <TableHead>
                                    <TableRow>
                                        <StyledTitleCell align="center">
                                            站點
                                        </StyledTitleCell>
                                        <StyledTitleCell align="center">
                                            崗位
                                        </StyledTitleCell>
                                        <StyledTitleCell align="center">
                                            攝影機 IP
                                        </StyledTitleCell>
                                        <StyledTitleCell align="center">
                                            AI 服務 Port
                                        </StyledTitleCell>
                                        <StyledTitleCell align="center">
                                            攝影機狀態
                                        </StyledTitleCell>
                                        <StyledTitleCell align="center">
                                            編輯
                                        </StyledTitleCell>
                                    </TableRow>
                                </TableHead>

                                <TableBody>
                                    {equipData.cameras.map((camera, idx) => (
                                        <TableRow
                                            key={idx}
                                            ref={idx === 0 ? rowRef : null}
                                        >
                                            <TableCell align="center">
                                                {camera.stage}
                                            </TableCell>
                                            <TableCell align="center">
                                                {camera.unit}
                                            </TableCell>
                                            <TableCell align="center">
                                                {camera.camIp}
                                            </TableCell>
                                            <TableCell align="center">
                                                {camera.aiServicePort}
                                            </TableCell>
                                            <TableCell align="center">
                                                <StatusChip
                                                    status={camera.camStatus}
                                                ></StatusChip>
                                            </TableCell>

                                            <TableCell align="center">
                                                <IconButton
                                                    disabled={!isAdmin}
                                                    onClick={() => {
                                                        handleEditCamClick(
                                                            equipData.pcId,
                                                            camera.camId,
                                                        );
                                                    }}
                                                >
                                                    <EditIcon />
                                                </IconButton>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </Box>
                    </Collapse>
                </TableCell>
            </TableRow>
        </>
    );
};

export default PcRow;
