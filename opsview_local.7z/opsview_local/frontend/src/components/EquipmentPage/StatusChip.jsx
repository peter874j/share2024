import React from "react";
import { Circle } from "@mui/icons-material";
import { Chip } from "@mui/material";

const StatusChip = ({ status }) => {
    const color = status ? "lightgreen" : "grey";
    const statuText = status ? "Online" : "Offline";
    return (
        <Chip
            icon={<Circle style={{ height: "18px", color: color }} />}
            label={statuText}
            sx={{ color: color }}
        />
    );
};

export default StatusChip;
