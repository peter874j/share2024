import {
    Box,
    FormControl,
    FormHelperText,
    InputLabel,
    MenuItem,
    Select,
    TextField,
    Typography,
} from "@mui/material";
import { useEffect, useImperativeHandle, useState } from "react";
import { backendAPI } from "../../apis/services/backendAPI";
import { isValidIp, isValidPort } from "../../utils/validUtils";

const CamDialogSection = ({
    fabName,
    initState = {
        stage: "",
        unit: "",
        camIp: "",
        aiServicePort: "",
    },
    ref,
}) => {
    const [camera, setCamera] = useState(initState);
    const hasStage = camera.stage !== "";
    const [stageOptions, setStageOptions] = useState([
        {
            name: initState.stage,
            id: null,
        },
    ]);
    const [unitOptions, setUnitOptions] = useState([
        {
            name: initState.unit,
            id: null,
        },
    ]);
    const [errors, setErrors] = useState({
        stage: false,
        unit: false,
    });

    useEffect(() => {
        if (fabName) {
            backendAPI
                .getStageOptions(fabName)
                .then((resp) => {
                    const updateStageOptions = resp.data.map((item) => ({
                        name: item.name,
                        id: item.id,
                    }));
                    setStageOptions(updateStageOptions);
                })
                .catch((error) => {
                    console.error(`載入 ${fabName} 站點列表失敗: `, error);
                });
        }
    }, [fabName]);

    useEffect(() => {
        if (fabName && camera.stage) {
            backendAPI
                .getUnitOptions(fabName, camera.stage)
                .then((resp) => {
                    const updateUnitOptions = resp.data.map((item) => ({
                        name: item.name,
                        id: item.id,
                    }));
                    setUnitOptions(updateUnitOptions);
                })
                .catch((error) => {
                    console.error(
                        `載入 ${fabName}-${camera.stage} 崗位列表失敗: `,
                        error,
                    );
                });
        }
    }, [fabName, camera.stage]);

    const handleStageSelect = (event) => {
        const updateStage = event.target.value;
        setCamera({
            ...camera,
            stage: updateStage,
            unit: camera.stage === updateStage ? camera.unit : "", // 站點修改時, 清除崗位
        });
    };

    const handleUnitSelect = (event) => {
        setCamera({
            ...camera,
            unit: event.target.value,
        });
    };

    // 驗證輸入
    const validate = () => {
        const newErrors = { ...errors };
        newErrors.stage = camera.stage === "";
        newErrors.unit = camera.unit === "";

        setErrors(newErrors);
        return !Object.values(newErrors).includes(true); // 回傳是否通過驗證
    };

    const getNewCam = () => {
        // 補上 stage 與 unit 的 id
        console.log("camera: ", camera);
        console.log("stageOptions: ", stageOptions);
        return {
            ...camera,
            stage: {
                name: camera.stage,
                id: stageOptions.find(
                    (stageOption) => stageOption.name === camera.stage,
                )?.id,
            },
            unit: {
                name: camera.unit,
                id: unitOptions.find(
                    (unitOption) => unitOption.name === camera.unit,
                )?.id,
            },
        };
    };

    // 將函數暴露給父件使用
    useImperativeHandle(ref, () => ({
        validate,
        getNewCam,
    }));

    return (
        <Box display="flex" flexDirection="Column" gap={2}>
            <Typography variant="h6">攝影機資訊</Typography>
            <FormControl required error={errors.stage}>
                <InputLabel id="stage-label">站點</InputLabel>
                <Select
                    labelId="stage-label"
                    value={camera.stage}
                    label="站點"
                    onChange={handleStageSelect}
                >
                    {stageOptions.map((stageOption, idx) => (
                        <MenuItem key={idx} value={stageOption.name}>
                            {stageOption.name}
                        </MenuItem>
                    ))}
                </Select>
                {errors.stage && <FormHelperText>請選擇站點</FormHelperText>}
            </FormControl>
            <FormControl required error={errors.unit}>
                <InputLabel id="unit-label">
                    {hasStage ? "崗位" : "崗位 (請先選擇站點)"}
                </InputLabel>
                <Select
                    value={camera.unit}
                    labelId="unit-label"
                    label="崗位"
                    disabled={!hasStage}
                    onChange={handleUnitSelect}
                >
                    {unitOptions.map((unitOption, idx) => (
                        <MenuItem key={idx} value={unitOption.name}>
                            {unitOption.name}
                        </MenuItem>
                    ))}
                </Select>
                {errors.unit && <FormHelperText>請選擇崗位</FormHelperText>}
            </FormControl>
            <TextField label="攝影機 IP" value={camera.camIp} disabled={true} />
            <TextField
                label="AI 服務 Port"
                value={camera.aiServicePort}
                disabled={true}
            />
        </Box>
    );
};

export default CamDialogSection;
