import { FilterAlt, FilterAltOff } from "@mui/icons-material";
import {
    Box,
    Checkbox,
    Divider,
    IconButton,
    Menu,
    MenuItem,
    Typography,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import StatusChip from "../EquipmentPage/StatusChip";
import { sortFunc } from "../../utils/sort";

const Filter = ({
    filterName,
    filterOptions,
    filterSelects,
    setFilterSelects,
}) => {
    const options = filterOptions[filterName].sort((a, b) => sortFunc(a, b));
    const selects = filterSelects[filterName];
    const [isSelectAll, setIsSelectAll] = useState(true);

    useEffect(() => {
        setIsSelectAll(options.length === selects.length);
    }, [options, selects]);

    const filterNameShow = {
        stage: "站點",
        unit: "崗位",
        pcStatus: "主機狀態",
        camStatus: "攝影機狀態",
    };

    const [anchorEl, setAnchorEl] = React.useState(null);
    const open = Boolean(anchorEl);
    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
        setAnchorEl(null);
    };

    const handleCheckboxChange = (option) => {
        // 取消選取
        if (selects.includes(option)) {
            setFilterSelects({
                ...filterSelects,
                [filterName]: selects.filter((item) => item !== option),
            });
        }
        // 新增選取
        else {
            setFilterSelects({
                ...filterSelects,
                [filterName]: [...selects, option],
            });
        }
    };

    const handleSelectAll = () => {
        // 取消全選
        if (isSelectAll) {
            setFilterSelects({
                ...filterSelects,
                [filterName]: [],
            });
        }
        // 全選
        else {
            setFilterSelects({
                ...filterSelects,
                [filterName]: filterOptions[filterName],
            });
        }
    };

    const renderOptionDisplay = (option) => {
        if (["pcStatus", "camStatus"].includes(filterName)) {
            /* 主機狀態與攝影機狀態顯示 chip */
            return <StatusChip status={option === "Online"} />;
        } else {
            return option;
        }
    };

    return (
        <Box
            sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
            }}
        >
            <Typography sx={{ fontSize: "16px" }}>
                {filterNameShow[filterName]}
            </Typography>

            <IconButton onClick={handleClick}>
                {isSelectAll ? (
                    <FilterAlt></FilterAlt>
                ) : (
                    <FilterAltOff></FilterAltOff>
                )}
            </IconButton>
            <Menu
                anchorEl={anchorEl}
                open={open}
                onClose={handleClose}
                sx={{ maxHeight: "50vh" }}
            >
                <MenuItem
                    onClick={handleSelectAll}
                    sx={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                    }}
                >
                    {isSelectAll ? "取消全選" : "全選"}
                </MenuItem>
                <Divider />
                {options.map((option, idx) => (
                    <MenuItem
                        key={idx}
                        onClick={() => handleCheckboxChange(option)}
                    >
                        <Checkbox checked={selects.includes(option)} />
                        {renderOptionDisplay(option)}
                    </MenuItem>
                ))}
            </Menu>
        </Box>
    );
};

const FilterBar = ({
    filterOptions,
    filterSelects,
    setFilterSelects,
    handleSelectChange,
}) => {
    return (
        <Box
            sx={(theme) => ({
                width: "50%",
                paddingX: 5,
                paddingY: 3,
                height: 8,
                backgroundColor: theme.palette.background.drawer,
                borderRadius: theme.shape.borderRadius,
                display: "flex",
                alignItems: "center",
                justifyContent: "space-evenly",
            })}
        >
            {Object.keys(filterOptions).map((filterName) => {
                return (
                    <Filter
                        key={filterName}
                        filterName={filterName}
                        filterOptions={filterOptions}
                        filterSelects={filterSelects}
                        setFilterSelects={setFilterSelects}
                        handleSelectChange={handleSelectChange}
                    ></Filter>
                );
            })}
        </Box>
    );
};

export default FilterBar;
