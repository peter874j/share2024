import { Select, styled } from "@mui/material";

const StyleSelect = styled(Select)(({ theme, ...props }) => {
    const readOnly = props?.inputProps?.readOnly;
    return {
        height: "100%",
        backgroundColor: "white",
        color: "black",
        borderRadius: theme.shape.borderRadius,
        // readOnly 時, 滑鼠顯示禁止符號 (必須要有 backgroundColor, cursor 才有作用)
        "& *": {
            cursor: readOnly ? "not-allowed !important" : "default",
        },
        // 設定箭頭顏色
        "& .MuiSelect-icon": {
            color: "black",
        },
        "& .MuiSelect-select": {
            paddingLeft: "10px",
        },
    };
});

export default StyleSelect;
