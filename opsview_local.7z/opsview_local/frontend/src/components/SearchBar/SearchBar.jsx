import { useEffect, useState } from "react";
import { Box } from "@mui/material";
import FabSelector from "./FabSelector";
import StageSelector from "./StageSelector";
import UnitSelector from "./UnitSelector";
import { backendAPI } from "../../apis/services/backendAPI";
import { sortFunc } from "../../utils/sort";

const SearchBar = ({
    fab,
    setFab,
    currentUser,
    stage = null,
    setStage = null,
    units = null,
    setUnits = null,
    isMultiUnit = false,
}) => {
    // 判斷是否可以選擇廠區
    const canChooseFab = currentUser.role === "super_admin";
    // 判斷是否應啟用 StageSelector
    const enableStage = stage !== null && setStage !== null;

    // 判斷是否應啟用 UnitSelector
    const enableUnit = units !== null && setUnits !== null;

    const [fabOptions, setFabOptions] = useState([]); // 廠區選項
    const [stageOptions, setStageOptions] = useState([]); // 站點選項
    const [unitOptions, setUnitOptions] = useState([]); // 崗位選項

    function getFabOptions() {
        // super_admin 角色可以選擇所有廠區, 其他角色只能選擇其所在廠區
        // 預設顯示用戶所在廠區
        if (currentUser?.location) {
            backendAPI
                .getFabOptions()
                .then((resp) => {
                    if (!resp.status) {
                        throw new Error(`取得廠區選項失敗: ${resp}`);
                    }
                    const results = resp.data.map((item) => ({
                        name: item.name,
                        id: item.id,
                    }));

                    const currentFabInfo = results.find(
                        (result) => result.name === currentUser.location,
                    );

                    if (currentFabInfo) {
                        // 如果當前用戶所在廠區在選項中, 則預設選擇該廠區
                        setFab({
                            name: currentFabInfo.name,
                            id: currentFabInfo.id,
                        });
                    } else {
                        // 如果當前用戶所在廠區不在選項中, 則預設選擇第一個廠區
                        setFab({ name: results[0].name, id: results[0].id });
                    }

                    if (canChooseFab) {
                        setFabOptions(
                            results.sort((a, b) => sortFunc(a.name, b.name)),
                        );
                    } else {
                        setFabOptions([currentFabInfo]);
                    }
                })
                .catch((err) => {
                    console.error(`取得廠區選項發生錯誤: ${err}`);
                });
        }
    }

    function getStageOptions() {
        backendAPI
            .getStageOptions(fab.name)
            .then((resp) => {
                if (!resp.status) {
                    throw new Error(resp);
                }
                const results = resp.data.map((item) => ({
                    name: item.name,
                    id: item.id,
                }));
                setStage(results[0]); // 預設選擇第一個站點
                setStageOptions(
                    results.sort((a, b) => sortFunc(a.name, b.name)),
                );
            })
            .catch((err) => {
                console.error(`取得站點選項發生錯誤: ${err}`);
            });
    }

    function getUnitOptions() {
        backendAPI
            .getUnitOptions(fab.name, stage.name)
            .then((resp) => {
                if (!resp.status) {
                    throw new Error(resp);
                }
                const results = resp.data.map((item) => ({
                    name: item.name,
                    id: item.id,
                }));
                setUnitOptions(
                    results.sort((a, b) => sortFunc(a.name, b.name)),
                );
                if (isMultiUnit) {
                    // 多選時, 預設選擇全部崗位
                    setUnits(results);
                } else {
                    // 單選時, 預設選擇第一個崗位
                    setUnits(
                        results.length > 0
                            ? [results[0]]
                            : [{ name: "", id: null }],
                    );
                }
            })
            .catch((err) => {
                console.error(`取得崗位選項發生錯誤: ${err}`);
            });
    }

    // 初始化 fab 選項, 並預設選擇第一筆結果
    useEffect(() => {
        getFabOptions();
    }, [currentUser?.location]);

    // 選擇 fab 時查詢對應的 stage 選項, 並預設選擇第一筆結果
    useEffect(() => {
        if (enableStage && fab.name !== "") {
            getStageOptions();
        }
    }, [fab?.name, enableStage]);

    // 選擇 stage 時查詢對應的 unit 選項, 並預設全選
    useEffect(() => {
        if (enableUnit && fab.name !== "" && stage.name !== "") {
            getUnitOptions();
        }
    }, [fab?.name, stage?.name]);

    return (
        <Box sx={{ display: "flex", gap: 3, my: 3, height: "60px" }}>
            <FabSelector
                fabOptions={fabOptions}
                fab={fab}
                setFab={setFab}
                readOnly={!canChooseFab}
            ></FabSelector>
            {enableStage && (
                <StageSelector
                    stageOptions={stageOptions}
                    stage={stage}
                    setStage={setStage}
                ></StageSelector>
            )}
            {enableUnit && (
                <UnitSelector
                    unitOptions={unitOptions}
                    isMultiUnit={isMultiUnit}
                    units={units}
                    setUnits={setUnits}
                ></UnitSelector>
            )}
        </Box>
    );
};

export default SearchBar;
