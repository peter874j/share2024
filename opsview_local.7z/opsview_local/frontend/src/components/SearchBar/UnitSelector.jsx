import {
    Box,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Checkbox,
    ListItemText,
    Chip,
} from "@mui/material";
import { useEffect, useMemo, useState } from "react";
import StyleSelect from "./StyleSelect";

const UnitSelector = ({ unitOptions, isMultiUnit, units, setUnits }) => {
    // 多選
    if (isMultiUnit) {
        const selectAllItem = {
            name: "全選",
            id: "select-all-id",
        };
        const [isSelectAll, setIsSelectAll] = useState(false);

        // 渲染已選擇的選項
        const renderSelected = (selected) => {
            const displayCount = 5; // 顯示的最大項目數量

            const filteredSelected = selected.filter(
                (item) => item.name !== selectAllItem.name,
            ); // 不在已選列標中顯示全選
            const displayedItems = filteredSelected.slice(0, displayCount); // 顯示的項目
            const remainingCount = filteredSelected.length - displayCount; // 隱藏的數量
            return (
                <Box
                    sx={{
                        display: "flex",
                        flexWrap: "wrap",
                        gap: 0.5,
                    }}
                >
                    {displayedItems.map((item) => (
                        <Chip key={item.id} label={item.name} />
                    ))}

                    {/* 隱藏的項目數量 */}
                    {remainingCount > 0 && (
                        <Chip
                            label={`+${remainingCount} more`}
                            color="primary"
                        />
                    )}
                </Box>
            );
        };

        // 連動所有選項與全選的關係
        useEffect(() => {
            if (isSelectAllUnit(units)) {
                setIsSelectAll(true);
            } else {
                setIsSelectAll(false);
            }
        }, [units]);

        const isSelectAllUnit = (selected) => {
            if (selected.length === 0) return false;
            const filteredSelected = selected.filter(
                (item) => item.name !== selectAllItem.name,
            );
            return filteredSelected.length === unitOptions.length;
        };

        const handleSelect = (event) => {
            const selectedItems = event.target.value;

            // 檢查是否選擇了全選選項
            const selectAllSelected = selectedItems.includes(selectAllItem);
            // 過濾掉全選項目，只保留實際的選項
            const actualSelectedItems = selectedItems.filter(
                (item) => item.id !== selectAllItem.id,
            );

            // 原本已全選
            if (isSelectAll) {
                // 全選狀態下, 用戶取消全選 -> 清空所有選項
                if (!selectAllSelected) {
                    setUnits([]);
                }
                // 全選狀態下, 用戶取消選取部分選項 -> 取消選取部分選項
                else if (actualSelectedItems.length !== unitOptions.length) {
                    setUnits(actualSelectedItems);
                }
            }
            // 原本非全選
            else {
                // 非全選狀態下, 用戶選擇全選 -> 全選
                if (selectAllSelected) {
                    setUnits(unitOptions);
                }
                // 非全選狀態下, 用戶沒選擇全選 -> 直接更新選項
                else {
                    setUnits(selectedItems);
                }
            }
        };

        return (
            <FormControl variant="standard" sx={{ minWidth: 200, height: 60 }}>
                <InputLabel id="unitSelectLabel">崗位</InputLabel>
                <Select
                    id="unitSelect"
                    labelId="unitSelectLabel"
                    multiple
                    value={isSelectAll ? [selectAllItem, ...units] : units}
                    onChange={handleSelect}
                    renderValue={renderSelected}
                    sx={{ height: "100%" }}
                >
                    {/* 全選選項 */}
                    <MenuItem key={selectAllItem.id} value={selectAllItem}>
                        <Checkbox checked={isSelectAll} />
                        <ListItemText primary={selectAllItem.name} />
                    </MenuItem>

                    {/* 一般選項 */}
                    {unitOptions.map((item) => (
                        <MenuItem key={item.id} value={item}>
                            <Checkbox
                                checked={units.some(
                                    (unit) => unit.id === item.id,
                                )}
                            />
                            <ListItemText primary={item.name} />
                        </MenuItem>
                    ))}
                </Select>
            </FormControl>
        );
    }
    // 單選
    else {
        return (
            <FormControl variant="standard" sx={{ minWidth: 100, height: 60 }}>
                <InputLabel id="unitSelectLabel">崗位</InputLabel>
                <StyleSelect
                    id="unitSelect"
                    labelId="unitSelectLabel"
                    value={units[0]?.name}
                    onChange={(event) => {
                        const selectUnitName = event.target.value;
                        setUnits([
                            {
                                name: selectUnitName,
                                id: unitOptions.find(
                                    (item) => item.name === selectUnitName,
                                ).id,
                            },
                        ]);
                    }}
                    sx={{ height: "100%" }}
                >
                    {unitOptions.map((item) => (
                        <MenuItem key={item.id} value={item.name}>
                            {item.name}
                        </MenuItem>
                    ))}
                </StyleSelect>
            </FormControl>
        );
    }
};

export default UnitSelector;
