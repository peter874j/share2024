import { FormControl, InputLabel, MenuItem } from "@mui/material";
import React from "react";
import StyleSelect from "./StyleSelect";

const StageSelector = ({ stageOptions, stage, setStage }) => {
    return (
        <FormControl variant="standard" sx={{ minWidth: 100 }}>
            <InputLabel id="stageSelectLabel">站點</InputLabel>
            <StyleSelect
                id="stageSelect"
                labelId="stageSelectLabel"
                value={stage.name}
                onChange={(event) => {
                    const selectStageName = event.target.value;
                    setStage({
                        name: selectStageName,
                        id: stageOptions.find(
                            (item) => item.name === selectStageName,
                        ).id,
                    });
                }}
                sx={{ height: "100%" }}
            >
                {stageOptions.map((item) => (
                    <MenuItem key={item.id} value={item.name}>
                        {item.name}
                    </MenuItem>
                ))}
            </StyleSelect>
        </FormControl>
    );
};

export default StageSelector;
