import { FormControl, InputLabel, MenuItem } from "@mui/material";
import StyleSelect from "./StyleSelect";

const FabSelector = ({ fabOptions, fab, setFab, readOnly = false }) => {
    return (
        <FormControl variant="standard" sx={{ minWidth: 100 }}>
            <InputLabel id="fabSelectLabel">廠區</InputLabel>
            <StyleSelect
                id="fabSelect"
                labelId="fabSelectLabel"
                value={fab.name}
                onChange={(event) => {
                    const selectFabName = event.target.value;
                    setFab({
                        name: selectFabName,
                        id: fabOptions.find(
                            (item) => item.name === selectFabName,
                        ).id,
                    });
                }}
                inputProps={{ readOnly: readOnly }}
                sx={{ height: "100%" }}
            >
                {fabOptions.map((item) => (
                    <MenuItem key={item.id} value={item.name}>
                        {item.name}
                    </MenuItem>
                ))}
            </StyleSelect>
        </FormControl>
    );
};

export default FabSelector;
