import { motion, AnimatePresence, useCycle } from "framer-motion";
import { useEffect } from "react";
import { useTheme } from "@mui/material/styles";
import { TitleLabel } from "../Label";

export default function WelcomeTextSpring() {
    const theme = useTheme();
    /* 1️要輪播的字串 */
    const words = ["Welcome Back!", "歡迎回來！"];

    /* 2️在 0 / 1 之間循環 */
    const [index, cycleIndex] = useCycle(0, 1);

    /* 3️每 2.5 秒切換一次 */
    useEffect(() => {
        const id = setTimeout(cycleIndex, 2500);
        return () => clearTimeout(id);
    }, [index, cycleIndex]);

    /* 彈簧滑入 / 滑出 variants */
    const springSlide = {
        hidden: (direction) => ({
            x: direction > 0 ? -60 : 60, // 交替方向 | alternate dir
            opacity: 0,
        }),
        visible: {
            x: 0,
            opacity: 1,
            transition: { type: "spring", stiffness: 280, damping: 22 },
        },
        exit: (direction) => ({
            x: direction > 0 ? 60 : -60,
            opacity: 0,
            transition: { type: "spring", stiffness: 280, damping: 22 },
        }),
    };

    /* direction 用於讓下一段從相反方向進場 */
    const direction = index % 2 === 0 ? 1 : -1;

    return (
        <AnimatePresence mode="wait" custom={direction}>
            <motion.div
                key={index}
                variants={springSlide}
                custom={direction}
                initial="hidden"
                animate="visible"
                exit="exit"
            >
                <TitleLabel fontSize="5vw" color={theme.palette.avatar.logo}>
                    {words[index]}
                </TitleLabel>
            </motion.div>
        </AnimatePresence>
    );
}
