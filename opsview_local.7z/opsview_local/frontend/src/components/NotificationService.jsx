import { toast } from "react-toastify";

export class NotificationService {
    static handleUnexpectedError(err, title, toastId) {
        const messagePrefix = title ? `${title}: ` : "Unexpected error: ";
        const message = `${messagePrefix}${err?.message || "No error message provided"}`;

        toast.error(message, {
            toastId: toastId || "error",
            position: "top-center",
            autoClose: 5000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "dark",
        });
    }

    static handleError(title, toastId) {
        toast.error(title, {
            toastId: toastId || "error",
            position: "top-center",
            autoClose: 5000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "dark",
        });
    }

    static handleSuccess(title, toastId) {
        toast.success(title, {
            toastId: toastId || "success",
            position: "top-center",
            autoClose: 5000,
            hideProgressBar: true,
            closeOnClick: false,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "dark",
        });
    }

    static handleInfo(title, toastId) {
        toast.info(title, {
            toastId: toastId || "info",
            position: "top-center",
            autoClose: 5000,
            hideProgressBar: true,
            closeOnClick: false,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "dark",
        });
    }
}
