import React, { forwardRef } from "react";
import { useTheme } from "@mui/material/styles";
import { Box, Dialog, Divider, IconButton } from "@mui/material";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import { PrimaryActionButton, SecondaryActionButton } from "./StyledButton";
import CloseIcon from "@mui/icons-material/Close";
import { TitleLabel } from "./Label";

const ContentDialog = forwardRef((props, ref) => {
    const {
        maxWidth = "md",
        showDialog = true,
        setShowDialog,
        title,
        message,
        content,
        actionLabel,
        actionHandler,
        secondaryActionLabel,
        secondaryActionHandler,
        closeHandler,
    } = props;

    const handleClose = () => {
        setShowDialog(false);
        if (closeHandler) closeHandler();
    };

    const theme = useTheme();

    return (
        <Dialog
            ref={ref}
            fullWidth={true}
            maxWidth={maxWidth}
            open={showDialog}
            onClose={handleClose}
            PaperProps={{
                elevation: 0,
                style: {
                    padding: "8px",
                    borderRadius: "12px",
                    backgroundColor: theme.palette.background.drawer,
                },
            }}
        >
            <DialogTitle>
                <TitleLabel fontSize="25px" textAlign="center">
                    {title}
                </TitleLabel>
                <IconButton
                    aria-label="close"
                    onClick={handleClose}
                    sx={{
                        position: "absolute",
                        right: 16,
                        top: 26,
                    }}
                >
                    <CloseIcon />
                </IconButton>
            </DialogTitle>
            <Divider sx={{ mt: "15px", mb: "15px" }} />
            <DialogContent>
                <DialogContentText>{message}</DialogContentText>
                {content}
                <Box display="flex" marginTop="32px">
                    {secondaryActionLabel && (
                        <>
                            <SecondaryActionButton
                                variant="contained"
                                fullWidth
                                disableElevation
                                onClick={secondaryActionHandler}
                                sx={{
                                    textTransform: "none",
                                }}
                            >
                                {secondaryActionLabel}
                            </SecondaryActionButton>
                            <Box width="20px"></Box>
                        </>
                    )}
                    {actionLabel && (
                        <PrimaryActionButton
                            variant="contained"
                            fullWidth
                            disableElevation
                            onClick={actionHandler}
                            sx={{
                                textTransform: "none",
                            }}
                        >
                            {actionLabel}
                        </PrimaryActionButton>
                    )}
                </Box>
            </DialogContent>
        </Dialog>
    );
});

ContentDialog.displayName = "ContentDialog";

export default ContentDialog;
