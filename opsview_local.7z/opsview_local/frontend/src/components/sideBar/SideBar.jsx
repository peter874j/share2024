import * as React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { styled, useTheme } from "@mui/material/styles";
import { ExpandLessRounded, ExpandMoreRounded, HistoryRounded, HubOutlined } from "@mui/icons-material";
import { UserContext } from "../../utils/userContext";
import SiderBarHeader from "./SideBarHeader";
import sideBarItem from "../ListItem";
import Profile from "./Profile";
import {
    ListItemText,
    ListItemIcon,
    ListItemButton,
    ListItem,
    List,
    CssBaseline,
    Box,
    Drawer,
    IconButton,
    Tooltip,
    Stack,
} from "@mui/material";
import { COLLAPSED_SIDE_BAR_WIDTH, SIDE_BAR_WIDTH } from "../../constants/appConstants";
import SiderBarButton from "./SideBarButton";

const shouldForward = (prop) => !["sideBarOpen", "theme"].includes(prop);

const DrawerContent = styled(Box, { shouldForwardProp: shouldForward })(({ theme, sideBarOpen }) => ({
    display: "flex",
    flexDirection: "column",
    flexGrow: 1,
    backgroundColor: theme.palette.background.drawer,
    boxShadow: 0,
    height: "100%",
    width: sideBarOpen ? "100%" : COLLAPSED_SIDE_BAR_WIDTH,
    padding: sideBarOpen ? "20px" : "8px"
}));

export const ScrollableContent = styled(Box, { shouldForwardProp: shouldForward })(({ theme }) => ({
    overflow: "hidden",
    flexGrow: 1,
    "&::-webkit-scrollbar": {
        width: "6px",
    },
    "&::-webkit-scrollbar-track": {
        background: "transparent",
    },
    "&::-webkit-scrollbar-thumb": {
        background: theme.palette.background.dialog,
        borderRadius: "4px",
    },
    "&::-webkit-scrollbar-thumb:hover": {
        background: theme.palette.icon.hover,
        cursor: "default",
    },
    "&:hover": { overflow: "auto" },
}));

const FixedHeader = styled(Box, { shouldForwardProp: shouldForward })(({ theme }) => ({
    position: "sticky",
    top: 0,
    zIndex: 1,
}));

const FixedFooter = styled(Box, { shouldForwardProp: shouldForward })(({ theme }) => ({
    position: "sticky",
    bottom: 0,
    zIndex: 1,
    paddingTop: theme.spacing(1),
}));

export default function SideBar() {
    const theme = useTheme();
    const navigate = useNavigate();
    const currentPath = useLocation().pathname;
    const { sideBarOpen, setSideBarOpen } = React.useContext(UserContext);
    const [ recentOpen, setRecentOpen ] = React.useState(true);

    const handleNavigate = (item) => {
        if (item.id === "api") {
            window.open(item.url, "_blank", "noopener,noreferrer");
        } else {
            navigate(item.url);
        }
    };

    return (
        <Box sx={{ display: "flex" }}>
            <CssBaseline />
            <Drawer
                sx={{
                    width: sideBarOpen ? SIDE_BAR_WIDTH : COLLAPSED_SIDE_BAR_WIDTH,
                    flexShrink: 0,
                    "& .MuiDrawer-paper": {
                        width: sideBarOpen ? SIDE_BAR_WIDTH : COLLAPSED_SIDE_BAR_WIDTH,
                        boxSizing: "border-box",
                        border: 0,
                        backgroundColor: "transparent",
                    },
                }}
                variant="persistent"
                anchor="left"
                open={true}
            >
                <DrawerContent 
                    sideBarOpen={sideBarOpen}
                >
                    {sideBarOpen ? 
                    <>
                        <FixedHeader>
                            <SiderBarHeader />
                        </FixedHeader>
                        <ScrollableContent>
                            <List>
                                {sideBarItem.items.map((item) => (
                                    <ListItem key={item.id} disablePadding sx={{ display: "block" }}>
                                        <ListItemButton
                                            onClick={() => {
                                                item.id === "recent"
                                                ? setRecentOpen((o) => !o)
                                                : handleNavigate(item);
                                            }}
                                            sx={{
                                                borderRadius: "8px",
                                                backgroundColor:
                                                    item.url === currentPath &&
                                                    theme.palette.action.hover,
                                                m: 0.1,
                                            }}
                                        >
                                            <ListItemIcon 
                                                sx={{ 
                                                    minWidth: 38,
                                                    color: theme.palette.icon.default 
                                                }}>
                                                {item.icon}
                                            </ListItemIcon>
                                            {sideBarOpen && (
                                                <Box display="flex" alignItems="center">
                                                <ListItemText
                                                    primary={item.title}
                                                />
                                                {item.id === "recent" && (
                                                    recentOpen ? (
                                                        <ExpandLessRounded 
                                                            fontSize="small" 
                                                            sx={{ ml: 0.5 }} 
                                                        />
                                                    ) : (
                                                        <ExpandMoreRounded 
                                                            fontSize="small" 
                                                            sx={{ ml: 0.5 }} 
                                                        />
                                                    )
                                                )}
                                                </Box>
                                            )}
                                        </ListItemButton>
                                    </ListItem>
                                ))}
                            </List>
                        </ScrollableContent>

                        <FixedFooter>
                            <Profile />
                        </FixedFooter>
                    </>
                    :
                        <>
                            <FixedHeader
                                sx={{ 
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                }}
                            >
                                <SiderBarButton />
                            </FixedHeader>
                            <Stack 
                                spacing={2}
                                alignItems="center"
                                sx={{
                                    mt: 3,
                                    flexGrow: 1,
                                }}
                            >
                                {sideBarItem.items.map((item) => (
                                    <Tooltip key={item.id} arrow title={item.title} placement="right">
                                        <IconButton
                                            onClick={() => navigate(item.url)}
                                            sx={{
                                                backgroundColor: theme.palette.background.dialog,
                                                borderRadius: "12px",
                                                padding: "8px", 
                                                "&:hover": {
                                                    backgroundColor: theme.palette.background.histroySelected,
                                                },
                                            }}
                                        >
                                            {item.icon}
                                        </IconButton>
                                    </Tooltip>
                                ))}             
                            </Stack>
                            {/* <FixedFooter>
                                <Profile />
                            </FixedFooter> */}
                        </>
                    }
                </DrawerContent>
            </Drawer>
        </Box>
    );
}
