import * as React from "react";
import { UserContext } from "../../utils/userContext";
import { useTheme } from "@mui/material/styles";
import { IconButton, Tooltip } from "@mui/material";
import { ArrowCircleLeftOutlined, ArrowCircleRightOutlined } from "@mui/icons-material";

export default function SideBarButton() {
    const theme = useTheme();
    const { sideBarOpen, setSideBarOpen } = React.useContext(UserContext);
    const tooptip = sideBarOpen ? "Close sidebar" : "Open sidebar";

    const handleSideBarOpen = () => {
        setSideBarOpen(true);
    };

    const handleSideBarClose = () => {
        setSideBarOpen(false);
    };

    return (
        <>
            {sideBarOpen ? (
                <Tooltip arrow title={tooptip} placement="right">
                    <IconButton
                        sx={{
                            backgroundColor: "transparent",
                            "&:hover": {
                                backgroundColor: "transparent",
                            },
                        }}
                        onClick={handleSideBarClose}
                    >
                        <ArrowCircleLeftOutlined
                            sx={{
                                fontSize: "28px",
                                color: theme.palette.avatar.logo,
                                "&:hover": {
                                    color: theme.palette.icon.hover,
                                },
                            }}
                        />
                    </IconButton>
                </Tooltip>
            ) : (
                <Tooltip arrow title={tooptip} placement="right">
                    <IconButton
                        sx={{
                            backgroundColor: "transparent",
                            "&:hover": {
                                backgroundColor: "transparent",
                            },
                        }}
                        onClick={handleSideBarOpen}
                    >
                        <ArrowCircleRightOutlined
                            sx={{
                                fontSize: "28px",
                                color: theme.palette.avatar.logo,
                                "&:hover": {
                                    color: theme.palette.icon.hover,
                                },
                            }}
                        />
                    </IconButton>
                </Tooltip>
            )}
        </>
    );
}
