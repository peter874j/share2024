import React from "react";
import {
    Box,
    IconButton,
    Typography,
    Avatar,
    Tooltip,
} from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { useNavigate } from "react-router-dom";
import { loadFromLocalStorage } from "../../utils/localStorageUtils";
import { LogoutOutlined } from "@mui/icons-material";
import { backendAPI } from "../../apis/services/backendAPI";
import PersonIcon from "@mui/icons-material/Person";

export default function Profile() {
    const theme = useTheme();
    const navigate = useNavigate();
    const user = loadFromLocalStorage("user");

    const handleClick = () => {
        handleLogout();
    };

    const handleLogout = async () => {
        await backendAPI.logout();
        localStorage.removeItem("user");
        navigate("/login");
    };

    return (
        <>
            <Box
                sx={{
                    mt: "8px",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    borderRadius: "8px",
                    p: "10px",
                    pr: "0px",
                    width: "100%",
                }}
            >
                <Avatar
                    sx={{
                        width: 34,
                        height: 34,
                        fontSize: "16px",
                        color: theme.palette.avatar.logo,
                    }}
                >
                    <PersonIcon />
                </Avatar>
                <Typography sx={{ fontSize: "14px", ml: "14px", flex: 1 }}>
                    {user && user?.fullname}
                </Typography>
                <Tooltip arrow title={"登出"} placement="top">
                    <IconButton
                        aria-label="logout"
                        onClick={handleClick}
                        sx={{
                            border: "1px solid",
                            borderColor: theme.palette.text.primary,
                            borderRadius: "50%",
                            width: "34px",
                            height: "34px",
                            mr: "10px",
                            ml: "10px",
                        }}
                    >
                        <LogoutOutlined
                            sx={{
                                width: "18px",
                                height: "18px",
                                color: theme.palette.icon.default,
                            }}
                        />
                    </IconButton>
                </Tooltip>
            </Box>
        </>
    );
}
