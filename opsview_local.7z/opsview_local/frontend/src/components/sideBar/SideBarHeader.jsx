import * as React from "react";
import { useNavigate } from "react-router-dom";
import { useTheme } from "@mui/material/styles";
import { Box } from "@mui/material";
import { TitleLabel } from "../Label";
import SiderBarButton from "./SideBarButton";
import getEnv from "../../utils/getEnv";

export default function SideBarHeader() {
    const theme = useTheme();
    const navigate = useNavigate();
    const env = getEnv("ENV")

    const handleNavigateHome = () => {
        navigate("/home")
    }

    return (
        <Box
            display="flex"
            alignItems="center"
            justifyContent="center"
            mb={2}
            sx={{
                position: "relative",
            }}
        >
            <Box
                display="flex"
                flexDirection="column"
                sx={{
                    alignItems: "center",
                    justifyContent: "center",
                    width: "100%",
                }}
            >
                <Box 
                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                    sx={{ width: "100%", minWidth: "100%" }}
                >
                    <Box flex={1} >
                        <TitleLabel                        
                            color={theme.palette.avatar.logo}
                            onClick={handleNavigateHome}
                            sx={{
                                cursor: "pointer",
                                fontSize: "25px",
                                textAlign: "center",
                            }}
                        >
                            O - View
                        </TitleLabel>
                    </Box>
                    <SiderBarButton />
                </Box>
                {env !== "production" && (
                    <TitleLabel
                        color={theme.palette.avatar.logo}
                        sx={{ fontSize: "18px", mt: "7px" }}
                    >
                        (Beta)
                    </TitleLabel>
                )}
            </Box>
        </Box>
    );
}
