import { Box, IconButton, Typography, useTheme } from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import { useEffect, useState, useRef, useMemo } from "react";
import { DataGrid, useGridApiRef } from "@mui/x-data-grid";
import ContentDialog from "../ContentDialog";
import EditSection from "./EditSection";
import CustomToolbar from "../CustomToolbar";
import {
    roleMapping,
    roleKeyByDisplayName,
    RoleComparator,
} from "../../apis/utils/roleManager";

const PermissionTable = ({ permissions, currentUser, updatePermissions }) => {
    const theme = useTheme();
    const [rows, setRows] = useState([]); // 顯示用的資料
    const [showDialog, setShowDialog] = useState(false); // 權限編輯視窗開關

    const editUserRef = useRef(null); // 編輯中的 User
    const newRoleRef = useRef(null); // user 透過編輯視窗選擇的新權限
    const apiRef = useGridApiRef(); // DataGrid 的 API 引用

    const paginationModel = { page: 0, pageSize: 15 };
    const currentRole = currentUser?.role; // 當前使用者角色
    const currentUserId = currentUser?.id; // 當前使用者工號
    const roleOptions = useMemo(
        () => getRoleOptions(currentRole),
        [currentRole],
    ); // 可賦予他人的角色選項

    // 計算是否可編輯
    function getIsEditable(currentRoleKey, targetRoleKey) {
        const currentRoleValue = roleMapping[currentRoleKey]?.value;
        const targetRoleValue = roleMapping[targetRoleKey]?.value;
        // 除 Super Admin 以外, 本身權限需高於被改動者的權限
        if (currentRoleValue === 0) {
            return true;
        } else if (currentRoleValue < targetRoleValue) {
            return true;
        } else {
            return false;
        }
    }

    // 計算可賦予他人的角色選項 (可賦與他人最高與自己相同)
    function getRoleOptions(currentRoleKey) {
        const currentRoleValue = roleMapping[currentRoleKey]?.value;
        const roleOptions = [];
        for (const { displayName, value } of Object.values(roleMapping)) {
            if (value >= currentRoleValue) {
                roleOptions.push(displayName);
            }
        }
        return roleOptions;
    }

    // 轉換資料, 將 permissions 轉為 DataGrid 所需的格式
    useEffect(() => {
        const initRows = permissions.map((permission, idx) => ({
            id: idx,
            name: permission.fullname,
            workId: permission.id,
            fab: permission.location,
            depart: permission.deptno,
            role: roleMapping[permission.role].displayName, // 將角色名稱轉為顯示時的字串
        }));
        setRows(initRows);
    }, [permissions]);

    const handleRoleEdit = () => {
        setShowDialog(false);
        if (newRoleRef.current) {
            // 呼叫後端 API 更新用戶權限, 並重新載入用戶列表
            updatePermissions(
                editUserRef.current.workId,
                roleKeyByDisplayName[newRoleRef.current],
            );
        }

        editUserRef.current = null;
        newRoleRef.current = null;
    };

    const columns = [
        {
            field: "name",
            headerName: "姓名",
            flex: 1,
            align: "center",
            headerAlign: "center",
            renderCell: (params) => {
                if (params.row.workId === currentUserId) {
                    return (
                        <Box
                            sx={{
                                height: "100%",
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                                gap: 1,
                            }}
                        >
                            <Box sx={{ flex: 1 }}></Box>
                            <Typography sx={{ flex: 1 }}>
                                {params.value}
                            </Typography>
                            <Typography sx={{ flex: 1 }}>
                                {"(It's you)"}
                            </Typography>
                        </Box>
                    );
                } else {
                    return (
                        <Typography
                            sx={{
                                height: "100%",
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                            }}
                        >
                            {params.value}
                        </Typography>
                    );
                }
            },
        },
        {
            field: "workId",
            headerName: "工號",
            flex: 1,
            align: "center",
            headerAlign: "center",
        },
        {
            field: "fab",
            headerName: "廠別",
            flex: 1,
            align: "center",
            headerAlign: "center",
        },
        {
            field: "depart",
            headerName: "單位",
            flex: 1,
            align: "center",
            headerAlign: "center",
        },
        {
            field: "role",
            headerName: "權限",
            flex: 1,
            align: "center",
            headerAlign: "center",
            sortComparator: RoleComparator,
            renderCell: (params) => (
                <Typography
                    width="100%"
                    height="100%"
                    sx={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        // Admin 以上顯示醒目色
                        color:
                            roleMapping[roleKeyByDisplayName[params.value]]
                                .value <= 1
                                ? "yellow"
                                : "null",
                    }}
                >
                    {params.value}
                </Typography>
            ),
        },
        {
            field: "editIcon",
            headerName: "編輯權限",
            align: "center",
            headerAlign: "center",
            width: 100,
            sortable: false,
            filterable: false,
            renderCell: (params) => {
                const isEditable = getIsEditable(
                    currentRole,
                    roleKeyByDisplayName[params.row.role],
                );
                return (
                    <IconButton
                        disabled={
                            !isEditable || params.row.workId === currentUserId
                        } // 不能編輯自己或沒有編輯權限
                        onClick={() => {
                            editUserRef.current = { ...params.row };
                            setShowDialog(true);
                        }}
                    >
                        <EditIcon />
                    </IconButton>
                );
            },
        },
    ];

    return (
        <Box sx={{ width: "100%" }}>
            <DataGrid
                rows={rows}
                columns={columns}
                apiRef={apiRef}
                disableRowSelectionOnClick // 禁用行選擇
                disableColumnSelector // 禁用欄位隱藏
                disableColumnResize // 停用調整列寬
                showToolbar
                slots={{ toolbar: CustomToolbar }}
                pageSizeOptions={[15, 30, 50]}
                initialState={{
                    pagination: { paginationModel },
                    sorting: {
                        sortModel: [{ field: "role", sort: "desc" }],
                    },
                }}
                sx={{
                    borderRadius: theme.shape.borderRadius,
                    "& .MuiDataGrid-columnHeader": {
                        backgroundColor: theme.palette.background.paper1,
                        fontSize: "16px",
                        fontWeight: "bold",
                    },
                    "& .MuiDataGrid-toolbar": {
                        backgroundColor: theme.palette.background.paper1,
                    },
                }}
            ></DataGrid>

            <ContentDialog
                maxWidth="xs"
                showDialog={showDialog}
                setShowDialog={setShowDialog}
                title={"編輯權限"}
                content={
                    <EditSection
                        editUserRef={editUserRef}
                        newRoleRef={newRoleRef}
                        roleOptions={roleOptions}
                    />
                }
                actionLabel={"確認"}
                actionHandler={handleRoleEdit}
            />
        </Box>
    );
};

export default PermissionTable;
