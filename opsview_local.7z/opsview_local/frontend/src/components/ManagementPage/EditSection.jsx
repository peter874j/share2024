import {
    Box,
    FormControlLabel,
    Radio,
    RadioGroup,
    Typography,
} from "@mui/material";
import React, { useState } from "react";

const EditSection = ({ editUserRef, newRoleRef, roleOptions }) => {
    const [selectedRole, setSelectedRole] = useState(editUserRef.current?.role);

    return (
        <Box sx={{ p: 2, border: "1px solid #ccc", borderRadius: "8px" }}>
            {/* 第一行：顯示工號和名稱 */}
            <Box
                sx={{ mb: 2, display: "flex", flexDirection: "column", gap: 2 }}
            >
                <Typography sx={{ fontSize: "19px" }}>
                    工號: {editUserRef.current?.workId}
                </Typography>
                <Typography sx={{ fontSize: "19px" }}>
                    姓名: {editUserRef.current?.name}
                </Typography>
            </Box>
            {/* 第二行：角色選擇按鈕 */}
            <RadioGroup
                row
                value={selectedRole}
                onChange={(event) => {
                    const newRole = event.target.value;
                    setSelectedRole(newRole);
                    newRoleRef.current = newRole;
                }}
                sx={{ justifyContent: "space-around" }}
            >
                {roleOptions.map((roleOption, idx) => (
                    <FormControlLabel
                        key={`${idx}-${roleOption}`}
                        value={roleOption}
                        control={<Radio />}
                        label={roleOption}
                    />
                ))}
            </RadioGroup>
        </Box>
    );
};

export default EditSection;
