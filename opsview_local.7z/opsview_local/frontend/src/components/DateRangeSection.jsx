import React, { useEffect } from "react";
import { Box, TextField, Chip } from "@mui/material";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Circle } from "@mui/icons-material";

const QUICK_RANGES = [
    { label: "Week", value: "week", days: 7 },
    { label: "Month", value: "month", days: 30 },
    { label: "Year", value: "year", days: 365 },
];

export default function DateRangeSection({
    startDate,
    endDate,
    setStartDate,
    setEndDate,
    mode,
    setMode,
}) {
    useEffect(() => {
        if (!startDate || !endDate) {
            const defaultItem = QUICK_RANGES.find((item) => item.value === mode);
            if (defaultItem) {
                handleQuickRangeChange(defaultItem.value, defaultItem.days);
            }
        }
    },[startDate, endDate, mode])

    const handleQuickRangeChange = (value, days) => {
        const now = roundToNearest30Min(new Date());  // <-- 對齊整點/半點
        const past = new Date(now);
        past.setDate(now.getDate() - days);
      
        setStartDate(past);
        setEndDate(now);
        setMode(value);
    };      

    function roundToNearest30Min(date = new Date()) {
        const rounded = new Date(date);
        const minutes = date.getMinutes();
        const roundedMinutes = minutes < 15 ? 0 : minutes < 45 ? 30 : 0;
        if (minutes >= 45) {
            rounded.setHours(date.getHours() + 1);
        }
        rounded.setMinutes(roundedMinutes);
        rounded.setSeconds(0);
        rounded.setMilliseconds(0);
        return rounded;
    }

    return (
        <Box display="flex" alignItems="center" gap={2} flexWrap="wrap">
            <DatePicker
                showTimeSelect
                timeIntervals={30}
                dateFormat="yyyy/MM/dd HH:mm"
                timeFormat="HH:mm"
                selected={startDate}
                onChange={(date) => {
                    setStartDate(date);
                    setMode("");
                }}
                selectsStart
                startDate={startDate}
                endDate={endDate}
                customInput={<TextField label="開始日期" />}
            />

            <DatePicker
                showTimeSelect
                timeIntervals={30}
                dateFormat="yyyy/MM/dd HH:mm"
                timeFormat="HH:mm"
                selected={endDate}
                onChange={(date) => {
                    setEndDate(date);
                    setMode("");
                }}
                selectsEnd
                startDate={startDate}
                endDate={endDate}
                minDate={startDate}
                customInput={<TextField label="結束日期" />}
            />

            <Box display="flex" gap={1}>
                {QUICK_RANGES.map((item) => (
                    <Chip
                        key={item.value}
                        label={item.label}
                        clickable
                        icon={
                            <Circle
                                style={{
                                    height: "13px",
                                    color:
                                        mode === item.value
                                            ? "lightgreen"
                                            : "grey",
                                }}
                            />
                        }
                        color={mode === item.value ? "default" : "primary"}
                        onClick={() =>
                            handleQuickRangeChange(item.value, item.days)
                        }
                        sx={{ borderRadius: "8px"}}
                    />
                ))}
            </Box>
        </Box>
    );
}
