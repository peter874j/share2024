import { useEffect } from "react";

export default function useRetrievaWidget({
    userId = "testID",
    userName = "testName",
    depno = "testDepno4",
    isDarkMode = false,
    apiKey = "",
    mode = "L6K",
    onApiResponse = (e) => console.log("Widget api response:", e.detail),
    customCssUrl = "/js/custom-styles.css",
    scriptSrc = "/js/rag-widget.js",
    cssHref = "/js/styles.css",
}) {
    useEffect(() => {
        const link = document.createElement("link");
        link.rel = "stylesheet";
        link.href = cssHref;
        document.head.appendChild(link);

        const script = document.createElement("script");
        script.src = scriptSrc;
        script.async = true;
        document.body.appendChild(script);

        script.onload = () => {
            if (window.App) {
                window.App.render(document.getElementById("rag-widget-root"), {
                    userId,
                    userName,
                    depno,
                    isDarkMode,
                    apiKey,
                    mode,
                    customCssUrl,
                });
            }

            window.addEventListener("retrieva:api-response", onApiResponse);
        };

        return () => {
            document.head.removeChild(link);
            document.body.removeChild(script);
            window.removeEventListener("retrieva:api-response", onApiResponse);
        };
    }, []);
}
