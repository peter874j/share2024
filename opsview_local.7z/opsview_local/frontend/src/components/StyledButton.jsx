import React from "react";
import { styled } from "@mui/system";
import { Button, useTheme } from "@mui/material";

const PrimaryActionButton = styled(Button, {
    shouldForwardProp: (prop) =>
        prop !== "color" && prop !== "fontSize" && prop !== "fontWeight",
})(({ color, fontSize, fontWeight, theme }) => ({
    color: color ? color : theme.palette.text.primaryButton,
    backgroundColor: theme.palette.background.primaryButton,
    fontSize: fontSize ? fontSize : "18px",
    fontWeight: fontWeight ? fontWeight : 600,
    borderRadius: "0.75rem",
    boxShadow: "none",
}));

const SecondaryActionButton = styled(Button, {
    shouldForwardProp: (prop) =>
        prop !== "color" && prop !== "fontSize" && prop !== "fontWeight",
})(({ color, fontSize, fontWeight, theme }) => ({
    color: color ? color : theme.palette.text.secondaryButton,
    backgroundColor: theme.palette.background.secondaryButton,
    fontSize: fontSize ? fontSize : "18px",
    fontWeight: fontWeight ? fontWeight : 600,
    borderRadius: "0.75rem",
    boxShadow: "none",
}));

const ThemedPrimaryActionButton = (props) => {
    return <PrimaryActionButton {...props} />;
};

const ThemedSecondaryActionButton = (props) => {
    return <SecondaryActionButton {...props} />;
};

export {
    ThemedPrimaryActionButton as PrimaryActionButton,
    ThemedSecondaryActionButton as SecondaryActionButton,
};
