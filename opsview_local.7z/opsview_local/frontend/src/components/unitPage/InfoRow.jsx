import React from 'react'
import { Box, Typography } from '@mui/material';

export default function InfoRow({ label, value, needToFix = false }) {
	if (needToFix) {
		const roundValue = Math.round(value * 100) / 100;
		value = roundValue.toFixed(2);
	}

    return (
        <Box sx={{ display: "flex", justifyContent: "space-between", mb: 1 }}>
            <Typography sx={{ fontWeight: "bold", color: "#ccc" }}>{label}</Typography>
            <Typography sx={{ textAlign: "right", color: "#fff", ml: 2 }}>{value}</Typography>
        </Box>
    )
}
