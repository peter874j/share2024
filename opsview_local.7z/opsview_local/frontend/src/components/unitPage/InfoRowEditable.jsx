import { useState } from "react";
import { Box, Typography, TextField, IconButton } from "@mui/material";
import { backendAPI } from "../../apis/services/backendAPI";
import { NotificationService } from "../NotificationService";
import EditIcon from "@mui/icons-material/Edit";

export default function InfoRowEditable({ label, value, onChange, selectedBarInfo }) {
    const [isEditing, setIsEditing] = useState(false);

    const updateWorkId = async() => {
        const payload = {
            work_id: value,
            cycle_start_time: selectedBarInfo?.timestamp,
        }

        const response = await backendAPI.updateReportWorkId(selectedBarInfo?.reportId, payload);
        if (response?.status !== undefined) {
            NotificationService.showSuccess("更新成功");
            setIsEditing(false);
        } else {
            NotificationService.handleError("更新失敗")
        }
    }

    const handleKeyDown = async (event) => {
        if (event.key === "Enter") {
            await updateWorkId();
        }
    };

    return (
        <Box
            sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                mb: 1,
            }}
        >
            <Typography sx={{ minWidth: 80 }}>
                {label}
            </Typography>
            {isEditing ? (
                <TextField
                    variant="standard"
                    value={value}
                    onChange={(e) => onChange(e.target.value)}
                    onBlur={async () => {
                        await updateWorkId();
                    }}
                    onKeyDown={handleKeyDown}
                    autoFocus
                    sx={{
                        input: { color: "#fff", textAlign: "right" },
                        width: 120,
                    }}
                />
            ) : (
                <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                    <Typography sx={{ textAlign: "right" }}>{value}</Typography>
                    <IconButton size="small" onClick={() => setIsEditing(true)}>
                        <EditIcon fontSize="small" sx={{ color: "#ccc" }} />
                    </IconButton>
                </Box>
            )}
        </Box>
    );
}
