import React, { useContext, useEffect, useRef, useState } from "react";
import { Box, Typography, Button, Stack } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import ReactECharts from "echarts-for-react";
import usePieOption from "./usePieOption";
import { UserContext } from "../../utils/userContext";
import { useChartToolbox } from "../useChartToolbox";
import { handleDownloadCSV } from "../../utils/handleDownloadCSV";

const TopChartSection = ({cycleTime, workTime, idleTime}) => {
    const theme = useTheme();
    const { sideBarOpen } = useContext(UserContext);
	const [cyclePieData, setCyclePieData] = useState([]);
	const [workPieData, setWorkPieData] = useState([]);
	const [idlePieData, setIdlePieData] = useState([]);

    const cyclePieRef = useRef(null);
    const workPieRef = useRef(null);
    const idlePieRef = useRef(null);

    const toolBox = useChartToolbox(handleDownloadCSV)
    const cyclePieOption = usePieOption(cyclePieData, toolBox);
	const workPieOption = usePieOption(workPieData, toolBox);
	const idlePieOption = usePieOption(idlePieData, toolBox);

	useEffect(() => {
        if (cycleTime) {
            setCyclePieData([
                { value: cycleTime.Work, name: "Work" },
                { value: cycleTime.OP_Idle, name: "OP_nonWork" },
                { value: cycleTime.EQ_Idle, name: "EQ_nonWork" },
            ]);
        }

        if (workTime?.steps) {
            setWorkPieData(
                Object.entries(workTime.steps).map(([name, value]) => ({
                    value,
                    name,
                }))
            );
        }

        if (idleTime) {
            setIdlePieData([
                { value: idleTime.OP_Idle, name: "OP_nonWork" },
                { value: idleTime.EQ_Idle, name: "EQ_nonWork" },
            ]);
        }

        requestAnimationFrame(() => {
            cyclePieRef.current?.getEchartsInstance().resize();
            workPieRef.current?.getEchartsInstance().resize();
            idlePieRef.current?.getEchartsInstance().resize();
        });
    }, [cycleTime, workTime, idleTime]);

    useEffect(() => {
        const timeout = setTimeout(() => {
            cyclePieRef.current?.getEchartsInstance().resize();
            workPieRef.current?.getEchartsInstance().resize();
            idlePieRef.current?.getEchartsInstance().resize();
        }, 300);

        return () => clearTimeout(timeout);
    }, [sideBarOpen]);

    return (
        <Box
            sx={{
                display: "flex",
                gap: 2,
                padding: 3,
                pl: 0,
                pr: 0,
                maxWidth: "100%",
                overflowX: "hidden",
            }}
        >
            <Box
                sx={{
                    flex: 1,
                    backgroundColor: theme.palette.background.paper1,
                    borderRadius: 2,
                    p: 2,
                    display: "flex",
                    flexDirection: "column",
                }}
            >
                <Typography variant="h6" color={theme.palette.text.primary} gutterBottom>
                    Avg. Cycle Time 組成
                </Typography>
                <Box sx={{ flex: 1 }}>
                    <ReactECharts
                        ref={cyclePieRef}
                        option={cyclePieOption}
                        style={{ width: "100%", height: 300 }}
                    />
                </Box>
            </Box>
            <Box
                sx={{
                    flex: 1,
                    backgroundColor: theme.palette.background.paper1,
                    borderRadius: 2,
                    p: 2,
                    display: "flex",
                    flexDirection: "column",
                }}
            >
                <Typography variant="h6" color={theme.palette.text.primary} gutterBottom>
                    Avg. Work Time 組成
                </Typography>
                <Box sx={{ flex: 1 }}>
                    <ReactECharts
                        ref={workPieRef}
                        option={workPieOption}
                        style={{ width: "100%", height: 300 }}
                    />
                </Box>
            </Box>
            <Box
                sx={{
                    flex: 1,
                    backgroundColor: theme.palette.background.paper1,
                    borderRadius: 2,
                    p: 2,
                    display: "flex",
                    flexDirection: "column",
                }}
            >
                <Typography variant="h6" color={theme.palette.text.primary} gutterBottom>
                    Avg. nonWork Time 組成
                </Typography>
                <Box sx={{ flex: 1 }}>
                    <ReactECharts
                        ref={idlePieRef}
                        option={idlePieOption}
                        style={{ width: "100%", height: 300 }}
                    />
                </Box>
            </Box>
        </Box>
    );
};

export default TopChartSection;
