import { useMemo } from "react";

const usePieOption = (rawData = [], externalToolbox = null) => {
  return useMemo(() => {
    const total = rawData.reduce((sum, item) => sum + item.value, 0);

    const processedData = rawData.map((item) => {
      const percent = ((item.value / total) * 100).toFixed(1);
      const displayName = item.name.length > 12 ? item.name.slice(0, 12) + "..." : item.name;
      return {
        ...item,
        percent,
        displayName,
      };
    });

    return {
      tooltip: {
        trigger: "item",
        formatter: (params) => {
          const { name, value, data } = params;
          return `
            <div>
              <strong>${name}</strong><br/>
              數值: ${value}<br/>
              比例: ${data.percent}%
            </div>
          `;
        },
      },
      legend: {
        orient: "vertical",
        right: 0,
        top: "center",
        textStyle: { color: "#fff" },
        data: processedData.map(item => item.name),
        formatter: (name) => {
          const found = processedData.find((item) => item.name === name);
          return found?.displayName || name;
        },
      },
      series: [
        {
          name: "崗位分布",
          type: "pie",
          radius: ["40%", "70%"],
          center: ["40%", "50%"],
          avoidLabelOverlap: false,
          label: {
            show: false,
            formatter: ({ data }) => `${data.displayName} (${data.percent}%)`,
            color: "#fff",
          },
          emphasis: {
            label: {
              show: false,
              fontSize: 18,
              fontWeight: "bold",
            },
          },
          labelLine: {
            show: true,
          },
          data: processedData.map((item) => ({
            name: item.name, // ✅ 保留原始完整名稱
            value: item.value,
            percent: item.percent,
            displayName: item.displayName,
          })),
        },
      ],
      toolbox: externalToolbox ?? {
        show: true,
        feature: {
          saveAsImage: {
            show: true,
            title: "匯出圖片",
            type: "png",
            name: "pie-chart",
          },
        },
        right: 20,
        top: 10,
      },
    };
  }, [rawData, externalToolbox]);
};

export default usePieOption;
