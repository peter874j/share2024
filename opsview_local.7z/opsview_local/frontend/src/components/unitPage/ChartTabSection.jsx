import React, { useState, useMemo, useEffect } from "react";
import {
    Box,
    Tabs,
    Tab,
    Checkbox,
    FormGroup,
    FormControlLabel,
    Select,
    MenuItem,
} from "@mui/material";
import ReactECharts from "echarts-for-react";
import { useTheme } from "@mui/material/styles";
import ContentDialog from "../ContentDialog";
import { useChartToolbox } from "../useChartToolbox";
import DialogSection from "./DialogSection";
import { backendAPI } from "../../apis/services/backendAPI";
import { NotificationService } from "../NotificationService";
import { handleDownloadCSV } from "../../utils/handleDownloadCSV";
import { convertUTCToUserTimezone } from "../../utils/convertUTCToUserTimezone";

export default function ChartTabSection({
    cycleList,
    workList,
    idleList,
    unitId,
}) {
    const theme = useTheme();
    const [tabIndex, setTabIndex] = useState(0);
    const [selectedRatios, setSelectedRatios] = useState([
        "Work_Ratio",
        "OP_nonWork_Ratio",
        "EQ_nonWork_Ratio",
    ]);
    const [selectedBarInfo, setSelectedBarInfo] = useState(null);
    const [showVideoDialog, setShowVideoDialog] = useState(false);
    const [selectedStep, setSelectedStep] = useState("");

    const handleRatioToggle = (name) => {
        setSelectedRatios((prev) =>
            prev.includes(name)
                ? prev.filter((r) => r !== name)
                : [...prev, name],
        );
    };

    const handleChartClick = (params) => {
        if (params.componentType === "series" && params.seriesType === "bar") {
            fetchCycleTimeData(params.data.Cycle_Start_Time, unitId);
        }
    };

    const fetchCycleTimeData = async (cycleTime, unitId) => {
        const response = await backendAPI.getUnitCycleDetailReport(
            cycleTime,
            unitId,
        );
        if (response?.status !== undefined) {
            const data = response.data;
            setSelectedBarInfo({
                reportId: data.id,
                workId: data.WorkId,
                cycleTime: data.Cycle_Time,
                workTime: data.Work_Time,
                opIdleTime: data.OP_Idle_Time,
                eqIdleTime: data.EQ_Idle_Time,
                videoUrl: data.Video_Url,
                stage: data.unit?.stage?.name,
                fab: data.unit?.stage?.fab?.name,
                unit: data.unit.name,
                timestamp: data.Cycle_Start_Time,
                operator: data.WorkId,
            });
            setShowVideoDialog(true);
        } else {
            NotificationService.handleError("取得影片資料發生錯誤");
        }
    };

    const memoizedCycleData = useMemo(() => {
        const base = {
            x: [],
            Cycle_Start_Time: [],
            Work: [],
            OP_Idle: [],
            EQ_Idle: [],
            Work_Ratio: [],
            OP_Idle_Ratio: [],
            EQ_Idle_Ratio: [],
            Baseline: [],
        };

        const records = cycleList?.[0]?.data || [];
        records.forEach((item) => {
            base.Cycle_Start_Time.push(item.Cycle_Start_Time);
            base.Work.push(item.Work);
            base.OP_Idle.push(item.OP_Idle);
            base.EQ_Idle.push(item.EQ_Idle);
            base.Work_Ratio.push(item.Work_Ratio);
            base.OP_Idle_Ratio.push(item.OP_Idle_Ratio);
            base.EQ_Idle_Ratio.push(item.EQ_Idle_Ratio);
            base.Baseline.push(item.Baseline);
        });

        return base;
    }, [cycleList]);

    const memoizedIdleData = useMemo(() => {
        const base = {
            x: [],
            Cycle_Start_Time: [],
            OP_Idle: [],
            EQ_Idle: [],
            OP_Base: [],
            EQ_Base: [],
        };

        const records = idleList?.[0]?.data || [];
        records.forEach((item) => {
            base.Cycle_Start_Time.push(item.Cycle_Start_Time);
            base.OP_Idle.push(item.OP_Idle);
            base.EQ_Idle.push(item.EQ_Idle);
            base.OP_Base.push(item.OP_Base);
            base.EQ_Base.push(item.EQ_Base);
        });

        return base;
    }, [idleList]);

    const memoizedWorkData = useMemo(() => {
        const result = {
            Cycle_Start_Time: [],
            stepNames: [], // ["sn_scanning", "pre_post_work", ...]
            steps: {}, // 每 step: { Time:[], Count:[], AVG_Time:[] }
        };

        const records = workList?.[0]?.data || [];
        if (!records.length) return result;

        const STEP_KEY_RE = /^Step_(.+?)(?:_AVG)?_(Time|Count|AVG_Time)$/;
        const stepSet = new Set();

        records.forEach((rec) => {
            Object.keys(rec).forEach((k) => {
                const m = k.match(STEP_KEY_RE);
                if (m) stepSet.add(m[1]); // m[1] = sn_scanning...
            });
        });

        result.stepNames = Array.from(stepSet);

        result.stepNames.forEach((s) => {
            result.steps[s] = { Time: [], Count: [], AVG_Time: [] };
        });

        /* 缺值補 0 / null */
        records.forEach((rec) => {
            result.Cycle_Start_Time.push(rec.Cycle_Start_Time);

            result.stepNames.forEach((step) => {
                result.steps[step].Time.push(rec[`Step_${step}_Time`] ?? 0);
                result.steps[step].Count.push(rec[`Step_${step}_Count`] ?? 0);
                result.steps[step].AVG_Time.push(
                    rec[`Step_${step}_AVG_Time`] ?? null,
                );
            });
        });

        return result;
    }, [workList]);

    useEffect(() => {
        if (!selectedStep && memoizedWorkData.stepNames.length) {
            setSelectedStep(memoizedWorkData.stepNames[0]);
        }
    }, [selectedStep, memoizedWorkData.stepNames]);

    const cycleTimeOption = {
        tooltip: {
            trigger: "axis",
            formatter: (params) => {
                const firstItem = params[0];
                const { data } = firstItem || {};
                return `Cycle_Start_Time: ${convertUTCToUserTimezone(data?.Cycle_Start_Time) || "N/A"}`;
            },
        },
        legend: {
            data: [
                "Work",
                "OP_Idle",
                "EQ_Idle",
                ...selectedRatios,
                "Avg_Cycle",
            ],
            bottom: 0,
            textStyle: { color: "#ccc" },
        },
        xAxis: {
            type: "category",
            // data: memoizedCycleData.x,
            axisLabel: { color: "#ccc" },
            axisLine: { lineStyle: { color: "#888" } },
        },
        yAxis: [
            {
                type: "value",
                name: "Time (s)",
                axisLabel: { color: "#ccc" },
                axisLine: { lineStyle: { color: "#888" } },
            },
            {
                type: "value",
                name: "Ratio (%)",
                axisLabel: {
                    color: "#ccc",
                    formatter: (value) => `${value * 100}%`,
                },
                axisLine: { lineStyle: { color: "#888" } },
            },
        ],
        series: [
            {
                name: "Work",
                type: "bar",
                stack: "total",
                data: memoizedCycleData?.Work?.map((v, i) => ({
                    value: v,
                    Cycle_Start_Time: memoizedCycleData?.Cycle_Start_Time[i],
                })),
            },
            {
                name: "OP_Idle",
                type: "bar",
                stack: "total",
                data: memoizedCycleData?.OP_Idle?.map((v, i) => ({
                    value: v,
                    Cycle_Start_Time: memoizedCycleData?.Cycle_Start_Time[i],
                })),
            },
            {
                name: "EQ_Idle",
                type: "bar",
                stack: "total",
                data: memoizedCycleData?.EQ_Idle?.map((v, i) => ({
                    value: v,
                    Cycle_Start_Time: memoizedCycleData?.Cycle_Start_Time[i],
                })),
            },
            ...selectedRatios.map((name) => ({
                name,
                type: "line",
                yAxisIndex: 1,
                data: memoizedCycleData[name],
                lineStyle: { type: "solid" },
            })),
            {
                name: "Avg_Cycle",
                type: "line",
                data: memoizedCycleData.Baseline,
                lineStyle: { type: "dashed" },
                symbol: "none",
            },
        ],
        toolbox: useChartToolbox(handleDownloadCSV),
    };

    const workStepOption = (step) => {
        const title = step
            .replace(/_/g, " ")
            .replace(/\b\w/g, (c) => c.toUpperCase());
        const { Time, Count, AVG_Time } = memoizedWorkData.steps[step] ?? {
            Time: [],
            Count: [],
            AVG_Time: [],
        };

        return {
            title: {
                text: title,
                left: "center",
                textStyle: { color: theme.palette.text.primary },
            },
            tooltip: {
                trigger: "axis",
                formatter: (params) => {
                    const firstItem = params[0];
                    const { data } = firstItem || {};
                    return `Cycle_Start_Time: ${convertUTCToUserTimezone(data?.Cycle_Start_Time) || "N/A"}`;
                },
            },
            legend: {
                data: [`${title} Time`, `${title} Count`, "AVG_Time"],
                bottom: 0,
                textStyle: { color: "#ccc" },
            },
            xAxis: {
                type: "category",
                // data: memoizedWorkData.Cycle_Start_Time,
                axisLabel: { color: "#ccc" },
                axisLine: { lineStyle: { color: "#888" } },
            },
            yAxis: [
                {
                    type: "value",
                    name: "Time (s)",
                    axisLabel: { color: "#ccc" },
                    axisLine: { lineStyle: { color: "#888" } },
                },
                {
                    type: "value",
                    name: "Count",
                    axisLabel: { color: "#ccc" },
                    axisLine: { lineStyle: { color: "#888" } },
                    minInterval: 1,
                },
            ],
            series: [
                {
                    name: `${title} Time`,
                    type: "bar",
                    data: Time.map((v, i) => ({
                        value: v,
                        Cycle_Start_Time: memoizedWorkData.Cycle_Start_Time[i],
                    })),
                },
                {
                    name: `${title} Count`,
                    type: "line",
                    yAxisIndex: 1,
                    data: Count,
                },
                {
                    name: "AVG_Time",
                    type: "line",
                    data: AVG_Time,
                    lineStyle: { type: "dashed" },
                    symbol: "none",
                },
            ],
            toolbox: useChartToolbox(handleDownloadCSV),
        };
    };

    const idleTimeOption = {
        tooltip: {
            trigger: "axis",
            formatter: (params) => {
                const firstItem = params[0];
                const { data } = firstItem || {};
                return `Cycle_Start_Time: ${convertUTCToUserTimezone(data?.Cycle_Start_Time) || "N/A"}`;
            },
        },
        legend: {
            data: [
                "OP_nonWork",
                "EQ_nonWork",
                "Avg_OP_nonWork",
                "Avg_EQ_nonWork",
            ],
            bottom: 0,
            textStyle: { color: "#ccc" },
        },
        xAxis: {
            type: "category",
            // data: memoizedIdleData.x,
            axisLabel: { color: "#ccc" },
            axisLine: { lineStyle: { color: "#888" } },
        },
        yAxis: {
            type: "value",
            name: "Time (s)",
            axisLabel: { color: "#ccc" },
            axisLine: { lineStyle: { color: "#888" } },
        },
        series: [
            {
                name: "OP_nonWork",
                type: "bar",
                data: memoizedIdleData.OP_Idle.map((v, i) => ({
                    value: v,
                    Cycle_Start_Time: memoizedCycleData?.Cycle_Start_Time[i],
                })),
            },
            {
                name: "EQ_nonWork",
                type: "bar",
                data: memoizedIdleData.EQ_Idle.map((v, i) => ({
                    value: v,
                    Cycle_Start_Time: memoizedCycleData?.Cycle_Start_Time[i],
                })),
                barGap: "0%",
            },
            {
                name: "Avg_OP_nonWork",
                type: "line",
                data: memoizedIdleData.OP_Base,
                lineStyle: { type: "dashed" },
                symbol: "none",
            },
            {
                name: "Avg_EQ_nonWork",
                type: "line",
                data: memoizedIdleData.EQ_Base,
                lineStyle: { type: "dashed" },
                symbol: "none",
            },
        ],
        toolbox: useChartToolbox(handleDownloadCSV),
    };

    return (
        <>
            <Box
                sx={{
                    width: "100%",
                    pt: 1,
                    px: 3,
                    backgroundColor: theme.palette.background.paper1,
                    borderRadius: 2,
                }}
            >
                <Tabs
                    value={tabIndex}
                    onChange={(_, v) => setTabIndex(v)}
                    textColor="inherit"
                    indicatorColor="primary"
                >
                    <Tab label="Cycle Time" sx={{ textTransform: "none" }} />
                    <Tab label="Work Time" sx={{ textTransform: "none" }} />
                    <Tab label="nonWork Time" sx={{ textTransform: "none" }} />
                </Tabs>

                {tabIndex === 0 && (
                    <>
                        <FormGroup row sx={{ px: 1 }}>
                            {[
                                "Work_Ratio",
                                "OP_nonWork_Ratio",
                                "EQ_nonWork_Ratio",
                            ].map((r) => (
                                <FormControlLabel
                                    key={r}
                                    control={
                                        <Checkbox
                                            checked={selectedRatios.includes(r)}
                                            onChange={() =>
                                                handleRatioToggle(r)
                                            }
                                            size="small"
                                        />
                                    }
                                    label={r}
                                />
                            ))}
                        </FormGroup>
                        <Box sx={{ p: 1 }}>
                            <ReactECharts
                                option={cycleTimeOption}
                                key={selectedRatios.join("-")}
                                style={{ width: "100%", height: 310 }}
                                onEvents={{ click: handleChartClick }}
                            />
                        </Box>
                    </>
                )}

                {tabIndex === 1 && (
                    <Box sx={{ p: 1 }}>
                        {/* 下拉選單 */}
                        <Select
                            size="small"
                            value={selectedStep}
                            onChange={(e) => setSelectedStep(e.target.value)}
                            sx={{ mb: 1, minWidth: 220 }}
                        >
                            {memoizedWorkData.stepNames.map((step) => (
                                <MenuItem key={step} value={step}>
                                    {step
                                        .replace(/_/g, " ")
                                        .replace(/\b\w/g, (c) =>
                                            c.toUpperCase(),
                                        )}
                                </MenuItem>
                            ))}
                        </Select>

                        {/* 單張圖表 */}
                        {selectedStep && (
                            <ReactECharts
                                option={workStepOption(selectedStep)}
                                style={{ width: "100%", height: 310 }}
                                onEvents={{ click: handleChartClick }}
                            />
                        )}
                    </Box>
                )}

                {tabIndex === 2 && (
                    <Box sx={{ p: 1 }}>
                        <ReactECharts
                            option={idleTimeOption}
                            style={{ width: "100%", height: 310 }}
                            onEvents={{ click: handleChartClick }}
                        />
                    </Box>
                )}
            </Box>
            <ContentDialog
                maxWidth="md"
                showDialog={showVideoDialog}
                setShowDialog={setShowVideoDialog}
                title={convertUTCToUserTimezone(selectedBarInfo?.timestamp)}
                content={
                    <DialogSection
                        selectedBarInfo={selectedBarInfo}
                        setSelectedBarInfo={setSelectedBarInfo}
                    />
                }
                actionLabel={"關閉"}
                actionHandler={() => {
                    setShowVideoDialog(false);
                }}
            />
        </>
    );
}
