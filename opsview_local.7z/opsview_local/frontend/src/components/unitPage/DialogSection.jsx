import React from "react";
import { Box, CardMedia } from "@mui/material";
import InfoRow from "./InfoRow";
import InfoRowEditable from "./InfoRowEditable";

export default function DialogSection({ selectedBarInfo, setSelectedBarInfo }) {
    return (
        <>
            <Box sx={{ mb: 2 }}>
                <CardMedia
                    component="video"
                    autoPlay
                    controls
                    src={selectedBarInfo?.videoUrl}
                    sx={{
                        borderRadius: "4px",
                        width: "100%",
                        height: "100%",
                        objectFit: "cover",
                    }}
                />                
            </Box>

            <Box display="flex" gap={4}>
                <Box flex={1}>
                    <InfoRow label="Cycle Time:" value={selectedBarInfo?.cycleTime} needToFix={true} />
                    <InfoRow label="Work Time:" value={selectedBarInfo?.workTime} needToFix={true}/>
                    <InfoRow label="OP Idle Time:" value={selectedBarInfo?.opIdleTime} needToFix={true}/>
                    <InfoRow label="EQ Idle Time:" value={selectedBarInfo?.eqIdleTime} needToFix={true}/>
                </Box>
                <Box sx={{ width: "1px", backgroundColor: "#CCCCCC70", mx: 3 }} />
                <Box flex={1}>
                    <InfoRow label="時間:" value={selectedBarInfo?.timestamp} />
                    <InfoRow label="廠區:" value={selectedBarInfo?.fab} />
                    <InfoRow label="站點:" value={selectedBarInfo?.stage} />
                    <InfoRow label="崗位:" value={selectedBarInfo?.unit} />
                    <InfoRowEditable
                        label="工號:"
                        value={selectedBarInfo?.operator}
                        onChange={(newValue) =>
                            setSelectedBarInfo((prev) => ({
                                ...prev,
                                operator: newValue,
                            }))
                        }
                        selectedBarInfo={selectedBarInfo}
                    />
                </Box>
            </Box>
        </>
    );
}
