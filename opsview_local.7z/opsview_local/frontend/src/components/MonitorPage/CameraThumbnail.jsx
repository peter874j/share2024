import { useEffect, useRef, useState } from "react";
import { Box, Typography, Card, IconButton, CardMedia } from "@mui/material";
import { PlayCircleFilledWhite } from "@mui/icons-material";

const CameraThumbnail = ({ unit, handleDialogOpen, url }) => {
    const [imageSrc, setImageSrc] = useState("");
    const imgRef = useRef(null);
    const canvasRef = useRef(null);

    useEffect(() => {
        if (!url) {
            setImageSrc("");
            return;
        }

        const img = imgRef.current;
        const canvas = canvasRef.current;

        if (canvas && img) {
            setImageSrc(""); // 清空舊圖片

            const context = canvas.getContext("2d");

            const handleLoad = () => {
                const MAX_SIZE = 500; // 限制最大尺寸以節省效能

                // 設置 canvas 尺寸
                const srcWidth = img.naturalWidth;
                const srcHeight = img.naturalHeight;
                const scale = Math.min(
                    MAX_SIZE / srcWidth,
                    MAX_SIZE / srcHeight,
                    1, // 不放大
                );
                const targetWidth = Math.floor(srcWidth * scale);
                const targetHeight = Math.floor(srcHeight * scale);
                canvas.width = targetWidth;
                canvas.height = targetHeight;

                // 繪製圖像
                context.drawImage(img, 0, 0, canvas.width, canvas.height);

                // 使用 JPEG 格式減少處理時間
                setImageSrc(canvas.toDataURL("image/jpeg", 0.8));

                // 取得縮圖後清空 img src，停止串流
                img.src = "";
            };

            img.addEventListener("load", handleLoad);

            return () => {
                img.removeEventListener("load", handleLoad);
            };
        }
    }, [url]);

    return (
        <Box display="flex" flexDirection="column" alignItems="center">
            <Card
                sx={{
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    width: "100%",
                    height: "25vh",
                }}
            >
                <Typography variant="body1" padding={0.5}>
                    {unit}
                </Typography>

                <Box
                    sx={{
                        flex: 1,
                        position: "relative",
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                    }}
                >
                    {/* 播放按鈕 */}
                    <IconButton
                        aria-label="play"
                        onClick={handleDialogOpen}
                        sx={{
                            position: "absolute",
                            top: "50%",
                            left: "50%",
                            transform: "translate(-50%, -50%)",
                        }}
                    >
                        <PlayCircleFilledWhite
                            sx={{
                                fontSize: 100,
                            }}
                        />
                    </IconButton>

                    {/* 縮圖 */}
                    {imageSrc && (
                        <CardMedia
                            component="img"
                            src={imageSrc}
                            title={`${unit}: ${url}`}
                            sx={{
                                width: "100%",
                                height: "100%",
                                objectFit: "cover",
                            }}
                        />
                    )}
                </Box>
                <img
                    ref={imgRef}
                    src={url}
                    style={{ display: "none" }}
                    crossOrigin="anonymous"
                />
                <canvas ref={canvasRef} style={{ display: "none" }} />
            </Card>
        </Box>
    );
};

export default CameraThumbnail;
