import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from src.api.routers import api_router
from src.config.settings import settings
from src.api.routes.webhook import webhook_router
from src.api.routes.test import test_router

# Docs / OpenAPI visibility: disabled in production, enabled in dev if APP_DEBUG is true
show_docs = settings.app_debug and not settings.is_production()
docs_url = "/" if show_docs else None
redoc_url = "/redoc" if show_docs else None
openapi_url = "/openapi.json" if show_docs else None

app = FastAPI(
    title=settings.app_name,
    version="1.0.0",
    debug=settings.app_debug,
    docs_url=docs_url,
    redoc_url=redoc_url,
    openapi_url=openapi_url,
)

# CORS Middleware
origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix="/api")
app.include_router(webhook_router, prefix="/webhook", tags=["Webhook"])
app.include_router(test_router, tags=["Test"])

if __name__ == "__main__":
    config = uvicorn.Config("app:app", host=settings.host, port=settings.port)
    uvicorn.Server(config).run()
