import asyncio

from src.scheduler.scheduler import create_scheduler


async def main():
    sched = create_scheduler()
    sched.start()
    while True:
        await asyncio.sleep(3600)


if __name__ == "__main__":
    asyncio.run(main())
