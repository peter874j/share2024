from typing import Optional, List
from sqlalchemy.orm import selectinload

from src.database.models.condition import Condition
from src.database.models.fence import Fence
from src.api.services.fence_service import FenceService
from src.database.schemas.fence import FenceCreate, FenceUpdate
from src.utils.logger import get_logger

logger = get_logger("fence")


class FenceController:
    def __init__(self, fence_service: FenceService):
        self.fence_service = fence_service

    async def get_multi(
        self,
        unit_id: Optional[int] = None,
    ) -> List[Fence]:
        """根據提供的 unit_id 條件，取得所有未被刪除（deleted_at 為 None）的 Fence 資料。若未指定 unit_id，則回傳所有符合條件的 Fence 清單。

        Args:
            unit_id (Optional[int], optional): 單位 ID，用於篩選特定單位的 Fence 資料。預設為 None。
        """
        return await self.fence_service.get_multi(unit_id=unit_id)

    async def get_one(self, _id: int) -> Optional[Fence]:
        """根據指定的 Fence ID 取得對應資料，並確認該資料尚未被標記為刪除（deleted_at 為 None）。若該 Fence 不存在或已刪除則回傳 None。

        Args:
            _id (int): Fence 的唯一識別 ID。
        """
        return await self.fence_service.get_one(_id)

    async def create(self, data: FenceCreate) -> Fence:
        """根據提供的 Fence 資料建立新的 Fence 實體，若對應的 unit_id 不存在則回傳錯誤訊息，否則儲存至資料庫並回傳建立結果。

        Args:
            data (FenceCreate): 包含 Fence 所需資訊的資料物件，例如名稱、繪製範圍、unit_id 等。
        """
        return await self.fence_service.create(data=data)

    async def update(self, _id: int, data: FenceUpdate) -> Optional[Fence]:
        """根據指定的 Fence ID 與更新資料，嘗試更新對應的 Fence 實體。若更新資料中的 unit_id 不存在，則回傳對應的錯誤訊息；更新成功則回傳更新後的結果。

        Args:
            _id (int): 要更新的 Fence 的唯一識別 ID。
            data (FenceUpdate): 包含更新資訊的資料物件，例如名稱、繪製範圍、unit_id 等。
        """
        return await self.fence_service.update(_id=_id, data=data)

    async def remove(self, _id: int) -> bool:
        return await self.fence_service.remove(_id=_id)
