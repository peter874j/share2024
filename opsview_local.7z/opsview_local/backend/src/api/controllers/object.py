from typing import Optional, List

from sqlalchemy.orm import selectinload

from src.api.services.object_service import ObjectService
from src.database.models.condition_object import ConditionObject
from src.database.models.object import Object as ObjectModel
from src.database.schemas.object import (
    ObjectCreate,
    ObjectWithConditionResponse,
    ObjectUpdate,
)
from src.utils.logger import get_logger

logger = get_logger("object")


class ObjectController:
    def __init__(self, object_service: ObjectService):
        self.object_service = object_service

    async def get_multi(
        self, unit_id: Optional[int] = None
    ) -> List[ObjectWithConditionResponse]:
        """根據提供的 unit_id 條件，取得所有尚未被標記刪除（deleted_at 為 None）的 Object 資料。若未指定 unit_id，則回傳所有符合條件的 Object 清單。

        Args:
            unit_id (Optional[int], optional): 單位 ID，用於篩選特定單位的 Object 資料。預設為 None。
        """
        filters = []

        if unit_id:
            filters.append(ObjectModel.unit_id == unit_id)

        return await self.object_service.get_multi(
            filters=filters,
            eager_options=[
                selectinload(ObjectModel.condition),
                selectinload(ObjectModel.condition_object).selectinload(
                    ConditionObject.condition
                ),
            ],
        )

    async def get_one(self, _id: int) -> Optional[ObjectWithConditionResponse]:
        """根據指定的 Object ID 取得對應資料，並確認該資料尚未被標記為刪除（deleted_at 為 None）。若資料不存在或已被刪除則回傳 None。

        Args:
            _id (int): Object 的唯一識別 ID。
        """
        return await self.object_service.get_one(_id)

    async def create(self, data: ObjectCreate) -> ObjectModel:
        return await self.object_service.create(data=data)

    async def update(
        self, _id: int, data: ObjectUpdate
    ) -> Optional[ObjectWithConditionResponse]:
        """根據指定的 Object ID 與更新資料，呼叫基礎控制器的 update 方法，執行部分欄位的更新。更新成功則回傳更新後的 Object 資料，否則回傳 None。

        Args:
            _id (int): 要更新的 Object 的唯一識別 ID。
            data (ObjectUpdate): 包含欲更新欄位的資料物件。
        """
        return await self.object_service.update(_id=_id, data=data)
