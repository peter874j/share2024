import asyncio, boto3, subprocess
from fastapi import HTTPException, status
from typing import Optional
from botocore.client import Config
from minio import Minio
from src.config.settings import settings
from src.utils.logger import get_logger

logger = get_logger("minio")


class MinioController:
    def __init__(
        self,
        endpoint=settings.minio_endpoint,
        access_key=settings.minio_admin_access_key,
        secret_key=settings.minio_admin_secret_key,
        secure=False,
    ):
        # 初始化 MinIO 客戶端
        self.minio_client = Minio(
            endpoint, access_key=access_key, secret_key=secret_key, secure=secure
        )

        # 初始化 S3 客戶端
        self.endpoint_url = f"http{'s' if secure else ''}://{endpoint}"
        # 使用 boto3 建立 S3 客戶端，以兼容 S3 API
        self.s3_client = boto3.client(
            "s3",
            endpoint_url=self.endpoint_url,
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            config=Config(signature_version="s3v4"),
        )

    def get_video_stream(
        self,
        bucket_name: str,
        object_name: str,
        start: int = 0,
        end: Optional[int] = None,
    ):
        """
        獲取影片檔案的資料流。
        :param bucket_name: MinIO 儲存桶名稱
        :param object_name: 影片檔案名稱
        :param start: 起始位元組位置
        :param end: 結束位元組位置
        :return: 影片資料流，影片總長度
        """
        # 獲取物件資訊以取得總大小
        stat = self.minio_client.stat_object(bucket_name, object_name)
        total_length = stat.size

        # 如果未指定 end，則讀取到檔案末尾
        if end is None or end >= total_length:
            end = total_length - 1

        # 計算要讀取的長度
        length = end - start + 1
        if length <= 0:
            # 如果請求的範圍無效，拋出 416 錯誤
            raise HTTPException(
                status_code=status.HTTP_416_REQUESTED_RANGE_NOT_SATISFIABLE,
                detail="Requested Range Not Satisfiable",
            )

        # 獲取物件的資料流
        data = self.minio_client.get_object(
            bucket_name, object_name, offset=start, length=length
        )
        return data, total_length  # 回傳資料流和總長度

    async def validate_mp4_h264(self, file_path: str) -> bool:
        """
        驗證檔案是否為 MP4 格式並使用 H.264 編碼。

        :param file_path: 檔案路徑
        :return: 若驗證通過返回 True，否則返回 False
        """
        try:
            # 使用 ffprobe 獲取格式和編碼資訊
            cmd = [
                "ffprobe",
                "-v",
                "error",
                "-select_streams",
                "v:0",
                "-show_entries",
                "format=format_name",
                "-show_entries",
                "stream=codec_name,codec_type",
                "-of",
                "default=noprint_wrappers=1:nokey=1",
                file_path,
            ]
            # 執行 ffprobe 命令
            process = await asyncio.create_subprocess_exec(
                *cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
            stdout, stderr = await process.communicate()
            # 解析輸出結果
            output = stdout.decode().strip().split("\n")
            output = [line.strip() for line in output]

            # 檢查格式和編碼
            codec_name = output[0] if len(output) > 0 else None
            codec_type = output[1] if len(output) > 1 else None
            format_name = output[2] if len(output) > 2 else None

            if (
                codec_type == "video"
                and codec_name == "h264"
                and "mp4" in format_name.lower()
            ):
                return True
            else:
                return False
        except Exception as e:
            # 如果發生錯誤，記錄錯誤訊息並返回 False
            logger.warning(f"Error in validate_mp4_h264: {str(e)}")
            return False
