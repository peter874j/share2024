from sqlalchemy.ext.asyncio import AsyncSession

from src.api.services.auth_service import AuthService
from src.database.session import get_db
from src.database.schemas.auth import (
    AuthLoginRequest,
    AuthTokenResponse,
    RefreshTokenRequest,
)


class AuthController:
    def __init__(self, auth_service: AuthService):
        self.auth_service = auth_service

    async def login(self, payload: AuthLoginRequest) -> AuthTokenResponse:
        return await self.auth_service.login(payload)

    async def refresh(self, payload: RefreshTokenRequest) -> AuthTokenResponse:
        return await self.auth_service.refresh(payload)
