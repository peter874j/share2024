from typing import Optional, List
from sqlalchemy import select
from sqlalchemy.exc import NoResultFound
from sqlalchemy.orm import selectinload

from src.database.models.department import Department
from src.database.models.fab import Fab
from src.database.models.stage import Stage
from src.database.schemas.stage import StageList
from src.utils.logger import get_logger
from src.api.services.stage_service import StageService


logger = get_logger("stage")


class StageController:
    def __init__(self, stage_service: StageService):
        self.stage_service = stage_service

    async def get_multi(self, form_data: Optional[StageList] = None) -> List[Stage]:
        """根據提供的查詢條件（如 location），取得符合條件的 Stage 清單，並同時預載關聯的 Fab 與 Department 資料。

        Args:
            form_data (Optional[StageList]): 包含搜尋條件（例如地點）的表單資料，預設為 None。

        Returns:
            List[Stage]: 符合搜尋條件的 Stage 實體列表。
        """
        filters = []

        if form_data and getattr(form_data, "location", None) is not None:
            filters.append(Stage.fab.has(Fab.name.ilike(f"%{form_data.location}%")))

        return await self.stage_service.get_multi(
            filters=filters,
            eager_options=[selectinload(Stage.fab), selectinload(Stage.department)],
        )

    async def fetch_or_create_stage_from_fab_and_department(
        self, stage_name: str, fab_id: int, department_id: int
    ) -> Stage:
        """根據輸入的 stage 名稱、fab ID 與 department ID，查詢是否已有對應的 Stage 資料。若已存在則直接回傳，否則建立新 Stage 實體並儲存至資料庫後回傳。

        Args:
            stage_name (str): 站點名稱。
            fab_id (int): 所屬工廠 ID。
            department_id (int): 所屬部門 ID。

        Returns:
            Stage: 查詢或建立後的 Stage 實體。
        """
        stage = await self.db.scalar(select(Stage).where(Stage.name == stage_name))
        if stage:
            return stage

        fab = await self.db.get(Fab, fab_id)
        if not fab:
            logger.info(
                f"fetch_or_create_stage_from_fab_and_department: Fab {fab_id} not found"
            )
            raise NoResultFound(f"Fab {fab_id} not found")

        department = await self.db.get(Department, department_id)
        if not department:
            logger.info(
                f"fetch_or_create_stage_from_fab_and_department: Department {department_id} not found"
            )
            raise NoResultFound(f"Department {department_id} not found")

        new_stage = Stage(name=stage_name, fab_id=fab_id, department_id=department_id)
        self.db.add(new_stage)
        await self.db.flush()
        return new_stage
