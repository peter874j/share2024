from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from typing import Type, TypeVar, Generic, Optional, List

from pydantic import BaseModel
from datetime import datetime, timezone

TModel = TypeVar("TModel")  # SQLAlchemy model 類別
TSchema = TypeVar("TSchema", bound=BaseModel)  # Pydantic schema 類別


class BaseController(Generic[TModel, TSchema]):
    def __init__(self, model: Type[TModel], schema: Type[TSchema], db: AsyncSession):
        self.model = model
        self.schema = schema
        self.db = db

    async def get_one(self, _id: int) -> Optional[TModel]:
        result = await self.db.execute(select(self.model).filter_by(id=_id))
        return result.scalars().first()

    async def get_multi(self, **filters) -> List[TModel]:
        result = await self.db.execute(select(self.model).filter_by(**filters))
        return result.scalars().all()

    async def create(self, data: TSchema) -> TModel:
        obj = self.model(**data.model_dump())
        self.db.add(obj)
        await self.db.commit()
        await self.db.refresh(obj)
        return obj

    async def update(self, _id: int, data: TSchema) -> Optional[TModel]:
        result = await self.db.execute(select(self.model).filter_by(id=_id))
        db_obj = result.scalars().first()
        if not db_obj:
            return None
        for field, value in data.dict(exclude_unset=True).items():
            setattr(db_obj, field, value)
        await self.db.commit()
        await self.db.refresh(db_obj)
        return db_obj

    async def remove(self, _id: int) -> Optional[TModel]:
        result = await self.db.execute(select(self.model).filter_by(id=_id))
        db_obj = result.scalars().first()
        if not db_obj:
            return None
        await self.db.delete(db_obj)
        await self.db.commit()
        return db_obj

    async def soft_remove(self, _id: int) -> Optional[TModel]:
        # 軟刪除
        result = await self.db.execute(select(self.model).filter_by(id=_id))
        db_obj = result.scalars().first()
        if not db_obj or db_obj.deleted_at is not None:
            return None

        db_obj.deleted_at = datetime.now(timezone.utc)
        self.db.add(db_obj)
        await self.db.commit()
        await self.db.refresh(db_obj)
        return db_obj
