from fastapi import BackgroundTasks
from typing import Optional, List
from sqlalchemy.ext.asyncio import AsyncSession
from src.api.services.cam_service import CamService
from src.api.orchestrators.cam_orchestrator import CamOrchestrator
from src.database.schemas.cam import CreateCam, UpdateCam, StreamResponse, CamBase


class CamController:
    def __init__(self, cam_service: CamService, cam_orchestrator: CamOrchestrator):
        self.cam_service = cam_service
        self.cam_orchestrator = cam_orchestrator

    async def get_multi(
        self,
        fab_id: Optional[int],
        stage_id: Optional[int],
        unit_ids: Optional[List[int]],
    ) -> List[CamBase]:
        return await self.cam_service.get_multi(fab_id, stage_id, unit_ids)

    async def get_one(self, cam_id: int) -> CamBase:
        return await self.cam_service.get_one(cam_id)

    async def create(self, data: CreateCam) -> CamBase:
        return await self.cam_service.create(data)

    async def update(
        self, cam_id: int, data: UpdateCam, background_tasks: BackgroundTasks
    ) -> CamBase:
        result = await self.cam_service.update(cam_id, data)
        await self.cam_orchestrator.check_cam_initialization(cam_id, background_tasks)
        return result

    async def remove(self, cam_id: int):
        return await self.cam_service.remove(cam_id)

    async def get_stream_list(
        self,
        fab_id: Optional[int],
        stage_id: Optional[int],
        unit_ids: Optional[List[int]],
    ) -> List[StreamResponse]:
        return await self.cam_orchestrator.get_stream_list(fab_id, stage_id, unit_ids)
