from fastapi import HTTPException, status
from typing import Any, Dict, Optional, List

from src.database.models.condition import Condition
from src.database.schemas.condition import ConditionCreate, ConditionUpdate, ObjectType
from src.api.services.condition_service import ConditionService
from src.utils.logger import get_logger

logger = get_logger("condition")


class ConditionController:
    def __init__(self, condition_service: ConditionService):
        self.condition_service = condition_service

    async def get_multi(self, unit_id: Optional[int] = None) -> List[Condition]:
        return await self.condition_service.get_multi(unit_id=unit_id)

    async def get_one(self, _id: int) -> Optional[Condition]:
        return await self.condition_service.get_one(_id)

    async def create(self, data: ConditionCreate) -> Condition:
        try:
            return await self.condition_service.create(data=data)
        except ValueError as e:
            logger.warning(f"create: {str(e)}")
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    async def update(self, _id: int, data: ConditionUpdate) -> Optional[Condition]:
        try:
            return await self.condition_service.update(_id=_id, data=data)
        except ValueError as e:
            logger.warning(f"create: {str(e)}")
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    def _prepare_condition_data(self, data: ConditionCreate) -> Dict[str, Any]:
        """
        根據 object_count 和 fence_id 準備 Condition 資料。
        """
        object_count = len(data.object_ids) if data.object_ids else 0
        fence_id = data.fence_id

        # 初始資料排除 object_ids 字段
        data_dict = data.model_dump(exclude={"object_ids"})

        if object_count == 1:
            data_dict["type"] = ObjectType.in_fence if fence_id else ObjectType.exists
        elif object_count > 1:
            data_dict["type"] = (
                ObjectType.overlap_in_fence if fence_id else ObjectType.overlap
            )
        else:
            logger.warning(f"_prepare_condition_data: 物件數量必須至少為 1。")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Unexpected error occurred while removing the condition.",
            )
