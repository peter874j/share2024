from typing import Dict, List, Optional
from fastapi import status, HTTPException
from sqlalchemy.exc import NoResultFound

from src.api.services.department_service import DepartmentService
from src.database.models.department import Department
from src.utils.logger import get_logger

logger = get_logger("department_controller")


class DepartmentController:
    def __init__(self, department_service: DepartmentService):
        self.department_service = department_service

    async def get_multi(
        self, filters: Optional[Dict[str, str]] = {}
    ) -> List[Department]:
        return await self.department_service.get_multi(filters)

    async def fetch_or_create_department_from_fab(
        self, department_name: str, fab_id: int
    ) -> Department:
        try:
            self.department_service.fetch_or_create_department_from_fab(
                department_name=department_name, fab_id=fab_id
            )
        except NoResultFound:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail=f"Fab {fab_id} not found"
            )
