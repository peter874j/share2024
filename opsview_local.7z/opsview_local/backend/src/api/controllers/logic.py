from typing import Optional, List
from fastapi import HTTPException, status
from src.database.schemas.logic import LogicCreate, LogicUpdate
from src.api.services.logic_service import LogicService
from src.database.models.logic import Logic
from src.utils.logger import get_logger

logger = get_logger("logic")


class LogicController:
    def __init__(self, logic_service: LogicService):
        self.logic_service = logic_service

    async def get_multi(self, unit_id: Optional[int] = None) -> List[Logic]:
        return await self.logic_service.get_multi(unit_id=unit_id)

    async def get_one(self, _id: int) -> Optional[Logic]:
        return await self.logic_service.get_one(_id)

    async def create(self, data: LogicCreate) -> Logic:
        try:
            return await self.logic_service.create(data=data)
        except ValueError as e:
            logger.warning(f"create: {str(e)}")
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    async def update(self, _id: int, data: LogicUpdate) -> Optional[Logic]:
        try:
            return await self.logic_service.update(_id=_id, data=data)
        except ValueError as e:
            logger.warning(f"update: {str(e)}")
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    async def remove(self, _id: int) -> bool:
        try:
            return await self.logic_service.remove(_id=_id)
        except ValueError as e:
            logger.warning(f"remove: {str(e)}")
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
        except Exception as e:
            logger.exception(f"remove (unexpected error): {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Unexpected error occurred while removing the logic.",
            )
