from typing import Dict, List, Optional
from src.api.services.fab_service import FabService
from src.database.models.fab import Fab
from src.database.schemas.fab import FabCreateRequest
from src.utils.logger import get_logger

logger = get_logger("fab")


class FabController:
    def __init__(self, fab_service: FabService):
        self.fab_service = fab_service

    async def get_multi(self, filters: Optional[Dict[str, str]] = {}) -> List[Fab]:
        return await self.fab_service.get_multi(filters)

    async def fetch_or_create_fab(self, payload: FabCreateRequest) -> Fab:
        return await self.fab_service.fetch_or_create_fab(payload)
