from fastapi import BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.services.client_service import ClientService


class ClientController:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.client_service = ClientService(db)

    async def assemble_sync_payload(
        self, background_tasks: BackgroundTasks, unit_id: int
    ) -> None:
        await self.client_service.assemble_sync_payload(background_tasks, unit_id)
