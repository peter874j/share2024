from fastapi import Request, UploadFile
from typing import List, Optional

from src.api.services.report_service import ReportService
from src.database.schemas.report_import import ReportBatchImportResponse
from src.api.orchestrators.report_import_orchestrator import ReportImportOrchestrator
from src.database.schemas.report import (
    ReportBase,
    StageAnalysisReportResponseList,
    UnitAnalysisCycleDetailResponse,
    UnitAnalysisResponse,
    UpdateWorkIdRequest,
)


class ReportController:
    """Controller 層：接收 route 的輸入，轉給 service，回傳輸出"""

    def __init__(self, report_service: ReportService):
        self.service = report_service

    async def get_original_data(
        self,
        start_time: str,
        end_time: str,
        fab_id: Optional[int],
        stage_id: Optional[int],
        unit_ids: Optional[List[int]],
    ) -> List[ReportBase]:
        return await self.service.get_original_data(
            start_time=start_time,
            end_time=end_time,
            fab_id=fab_id,
            stage_id=stage_id,
            unit_ids=unit_ids,
        )

    async def get_stage_analysis_report_data(
        self,
        start_time: str,
        end_time: str,
        fab_id: Optional[int],
        stage_id: Optional[int],
        unit_ids: Optional[List[int]],
    ) -> List[StageAnalysisReportResponseList]:
        return await self.service.get_stage_analysis_report_data(
            start_time=start_time,
            end_time=end_time,
            fab_id=fab_id,
            stage_id=stage_id,
            unit_ids=unit_ids,
        )

    async def get_unit_analysis_report_data(
        self,
        start_time: str,
        end_time: str,
        fab_id: Optional[int],
        stage_id: Optional[int],
        unit_id: Optional[int],
    ) -> UnitAnalysisResponse:
        return await self.service.get_unit_analysis_report_data(
            start_time=start_time,
            end_time=end_time,
            fab_id=fab_id,
            stage_id=stage_id,
            unit_id=unit_id,
        )

    async def get_unit_analysis_cycle_detail_data(
        self,
        unit_id: int,
        cycle_start_time: str,
        request: Request,
    ) -> UnitAnalysisCycleDetailResponse:
        return await self.service.get_unit_analysis_cycle_detail_data(
            unit_id=unit_id, cycle_start_time=cycle_start_time, request=request
        )

    async def update_work_id(
        self,
        report_id: int,
        request: UpdateWorkIdRequest,
    ) -> UnitAnalysisCycleDetailResponse:
        return await self.service.update_work_id(
            report_id=report_id,
            new_work_id=request.work_id,
            cycle_start_time=request.cycle_start_time,
        )

    async def import_reports(
        self,
        unit_id: int,
        files: List[UploadFile],
    ) -> ReportBatchImportResponse:
        orchestrator = ReportImportOrchestrator(self.service)
        return await orchestrator.process(unit_id=unit_id, files=files)
