from typing import Dict, Optional, List, Sequence, Tuple, Literal
from sqlalchemy.orm import selectinload

from src.api.services.department_service import DepartmentService
from src.api.services.stage_service import StageService
from src.api.orchestrators.unit_orchestrator import UnitOrchestrator
from src.api.services.fab_service import FabService
from src.api.services.unit_service import UnitService
from src.database.models.stage import Stage
from src.database.models.unit import Unit
from src.database.models.server import Server
from src.database.schemas.unit import (
    FabImportRateResponse,
    UnitCreate,
)
from src.utils.logger import get_logger


logger = get_logger("unit")


class UnitController:
    def __init__(
        self,
        fab_service: FabService,
        department_service: DepartmentService,
        stage_service: StageService,
        unit_service: UnitService,
        unit_orchestrator: UnitOrchestrator,
    ):
        self.fab_service = fab_service
        self.department_service = department_service
        self.stage_service = stage_service
        self.unit_service = unit_service
        self.unit_orchestrator = unit_orchestrator

    async def get_by_id(self, unit_id: int) -> Optional[Unit]:
        return await self.unit_service.get_by_id_with_filters(
            unit_id=unit_id,
            eager_options=[
                selectinload(Unit.stage).selectinload(Stage.fab),
                selectinload(Unit.stage).selectinload(Stage.department),
                selectinload(Unit.cams),
            ],
        )

    async def get_paginated_multi(
        self,
        page: int = 1,
        limit: int = 10,
        search: Optional[str] = None,
        sort_field: str = "id",
        sort_order: Literal["asc", "desc"] = "asc",
    ) -> Tuple[List[Unit], dict]:
        return await self.unit_service.get_paginated_multi(
            page=page,
            limit=limit,
            search=search,
            sort_field=sort_field,
            sort_order=sort_order,
        )

    async def get_multi(self, filters: Dict[str, str]) -> List[Server]:
        return await self.unit_service.get_multi(
            filters=filters,
            eager_options=[
                selectinload(Unit.stage).selectinload(Stage.fab),
                selectinload(Unit.stage).selectinload(Stage.department),
                selectinload(Unit.cams),
            ],
        )

    async def create_unit_from_stage(self, unit_name: str, stage_id: int) -> Unit:
        return await self.create_unit_from_stage(unit_name=unit_name, stage_id=stage_id)

    async def create_unit(self, form_data: UnitCreate):
        return await self.unit_orchestrator.create_unit(form_data=form_data)

    async def update_unit(
        self,
        unit_id: int,
        fab_name: Optional[str] = None,
        department_name: Optional[str] = None,
        stage_name: Optional[str] = None,
        name: Optional[str] = None,
    ) -> Unit:
        unit: Unit = await self.unit_service.get_by_id_with_filters(
            unit_id=unit_id,
            eager_options=[selectinload(Unit.stage).selectinload(Stage.fab)],
        )

        if fab_name:
            fab = await self.fab_service.fetch_or_create_fab(fab_name=fab_name)
        else:
            fab = unit.stage.fab

        if department_name:
            department = (
                await self.department_service.fetch_or_create_department_from_fab(
                    department_name=department_name, fab_id=fab.id
                )
            )
        else:
            department = unit.stage.department

        if stage_name:
            stage = (
                await self.stage_service.fetch_or_create_stage_from_fab_and_department(
                    stage_name=stage_name, fab_id=fab.id, department_id=department.id
                )
            )
        else:
            stage = unit.stage

        return await self.unit_service.update_unit(
            unit_id=unit_id, name=name, stage_id=stage.id
        )

    async def delete_unit_by_id(self, unit_id: int) -> bool:
        return await self.unit_service.delete_unit_by_id(unit_id=unit_id)

    async def get_fab_import_rate(self) -> List[FabImportRateResponse]:
        return await self.fab_service.get_fab_import_rate()

    async def get_server_status(self, unit_id: int) -> bool:
        return await self.unit_service.get_server_status(unit_id=unit_id)

    async def get_server_status_bulk(self, unit_ids: Sequence[int]) -> Dict[int, bool]:
        return await self.unit_service.get_server_status_bulk(unit_ids=unit_ids)
