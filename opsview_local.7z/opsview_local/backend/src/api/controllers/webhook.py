from typing import List
from fastapi import Request
from sqlalchemy.ext.asyncio import AsyncSession
from src.api.orchestrators.webhook_orchestrator import WebhookOrchestrator
from src.database.schemas.webhook import CameraReportData


class WebhookController:
    def __init__(self, db: AsyncSession):
        self.orch = WebhookOrchestrator(db)

    async def receive_camera_report(
        self, *, request: Request, signature: str, reports: List[CameraReportData]
    ):
        body_bytes = await request.body()
        return await self.orch.handle_camera_report(
            signature=signature, body=body_bytes, reports=reports
        )
