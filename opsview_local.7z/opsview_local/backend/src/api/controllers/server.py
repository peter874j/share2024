from typing import List, Optional, Literal, Tuple
from sqlalchemy.ext.asyncio import AsyncSession
from src.api.orchestrators.server_orchestrator import ServerOrchestrator
from src.api.services.server_service import ServerService
from src.database.models.server import Server
from src.database.schemas.server import (
    CreateServer,
    UpdateServer,
    ServerResponse,
    ServerList,
)
from src.utils.logger import get_logger

logger = get_logger("server.controller")


class ServerController:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.service = ServerService(db)
        self.orchestrator = ServerOrchestrator(db)

    async def create(self, data: CreateServer) -> ServerResponse:
        return await self.service.create_server(data)

    async def fetch(self) -> List[ServerResponse]:
        return await self.service.list_servers()

    async def get(self, server_id: int) -> ServerResponse:
        return await self.service.get_server_with_relations(server_id)

    async def update(self, server_id: int, data: UpdateServer) -> ServerResponse:
        return await self.service.update_server(server_id, data)

    async def remove(self, server_id: int) -> None:
        return await self.service.delete_server(server_id)

    async def get_paginated_multi(
        self,
        form_data: Optional[ServerList] = None,
        page: int = 1,
        limit: int = 10,
        sort_field: str = "id",
        sort_order: Literal["asc", "desc"] = "asc",
    ) -> Tuple[List[Server], dict]:
        return await self.service.get_paginated_servers(
            form_data, page, limit, sort_field, sort_order
        )

    async def get_multi(self, form_data: Optional[ServerList] = None) -> List[Server]:
        return await self.service.list_filtered_servers(form_data)

    async def initialize_server(self, server_id: int) -> None:
        return await self.orchestrator.initialize_server(server_id)
