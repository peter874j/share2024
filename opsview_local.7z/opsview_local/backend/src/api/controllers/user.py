from typing import Optional, List, Tuple, Dict
from src.database.schemas.user import UserFilter, UserRole
from src.database.models.user import User
from src.api.services.user_service import UserService


class UserController:
    def __init__(self, user_service: UserService):
        self.user_service = user_service

    async def get_one(self, user_id: str) -> Optional[User]:
        return await self.user_service.get_one(user_id)

    async def get_multi(self, filters: Dict[str, str]) -> List[User]:
        return await self.user_service.get_multi(filters)

    async def get_paginated_multi(
        self,
        form_data: Optional[UserFilter],
        page: int,
        limit: int,
        search: Optional[str],
        sort_field: str,
        sort_order: str,
    ) -> Tuple[List[User], Dict[str, int]]:
        return await self.user_service.get_paginated_multi(
            form_data, page, limit, search, sort_field, sort_order
        )

    async def update_user_role(self, user_id: str, new_role: UserRole) -> User:
        return await self.user_service.update_user_role(user_id, new_role)
