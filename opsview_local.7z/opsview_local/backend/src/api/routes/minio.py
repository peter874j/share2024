import re
from fastapi import APIRouter, Request, HTTPException, Header, Path, status
from fastapi.responses import StreamingResponse
from typing import Optional
from ..controllers.minio import MinioController
from src.utils.logger import get_logger

logger = get_logger("minio")
minio_router = APIRouter()
minio_controller = MinioController()


@minio_router.get("/video-streaming/{bucket_name}/{object_name:path}")
async def stream_video(
    request: Request,
    bucket_name: str,
    object_name: str = Path(...),
    range: Optional[str] = Header(None),
):
    """
    影片串流端點。
    :param request: 請求物件
    :param bucket_name: 請求儲存庫名稱
    :param object_name: 影片檔案路徑名
    :param range: Range 請求標頭
    :return: 影片資料流回應
    """

    # 處理 Range 請求標頭
    if range is None:
        # 如果沒有提供 Range 標頭，設定開始位置為 0，結束位置為 None（直到檔案結束
        start = 0
        end = None
    else:
        # 解析 Range 請求標頭，例如 "bytes=0-1023"
        match = re.match(r"bytes=(\d+)-(\d*)", range)
        if match:
            # 如果匹配成功，提取開始和結束位置
            start = int(match.group(1))
            end_str = match.group(2)
            # 如果結束位置存在，轉換為整數；否則設為 None
            end = int(end_str) if end_str else None
        else:
            # 如果 Range 標頭格式無效，記錄錯誤並拋出 400 錯誤
            logger.warning("Invalid Range header")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid Range header"
            )

    def iterfile(file_obj, chunk_size=1024 * 1024):
        # 定義一個生成器函數，用於以指定大小的區塊讀取檔案
        while True:
            chunk = file_obj.read(chunk_size)
            if not chunk:
                # 如果已經讀取完畢，結束迴圈
                break
            yield chunk

    try:
        # 獲取影片資料流和總長度
        video_stream, total_length = minio_controller.get_video_stream(
            bucket_name, object_name, start, end
        )

        # 設定回應標頭
        if end is None or end >= total_length:
            # 如果結束位置為 None 或超過檔案總長度，將結束位置設為總長度減一
            end = total_length - 1

        content_length = end - start + 1

        headers = {
            "Content-Type": "video/mp4",  # 根據影片格式調整 MIME 類型
            "Accept-Ranges": "bytes",  # 告知客戶端支援 bytes 範圍請求
            "Content-Length": str(content_length),  # 設定內容長度
            "Content-Range": f"bytes {start}-{end}/{total_length}",  # 設定內容範圍
        }

        # 回傳 StreamingResponse，狀態碼為 206（部分內容）
        return StreamingResponse(
            iterfile(video_stream),
            status_code=status.HTTP_206_PARTIAL_CONTENT,
            headers=headers,
        )

    except Exception as e:
        logger.exception(f"Error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=f"Error: {str(e)}"
        )
