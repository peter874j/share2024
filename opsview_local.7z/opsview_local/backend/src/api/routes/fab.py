from fastapi import APIRouter, Depends, status

from src.api.services.fab_service import FabService
from src.database.repositories.fab_repository import FabRepository
from src.database.schemas.fab import (
    FabResponse,
)
from ..controllers.fab import FabController
from src.utils.logger import get_logger
from typing import List
from sqlalchemy.ext.asyncio import AsyncSession
from src.database.session import get_db


logger = get_logger("fab")
fab_router = APIRouter()


# Dependency 注入 FabController
async def get_fab_ctrl(db: AsyncSession = Depends(get_db)) -> FabController:
    fab_repo = FabRepository(db)
    fab_service = FabService(fab_repo=fab_repo, db=db)
    return FabController(fab_service=fab_service)


@fab_router.get(
    "",
    response_model=List[FabResponse],
    status_code=status.HTTP_200_OK,
    summary="獲取廠區列表",
)
async def get_fab_list(
    ctrl: FabController = Depends(get_fab_ctrl),
):
    fabs = await ctrl.get_multi()

    # 直接返回 FabResponse 的列表
    return fabs
