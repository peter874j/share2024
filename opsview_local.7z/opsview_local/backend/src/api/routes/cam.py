from fastapi import (
    APIRouter,
    Depends,
    Query,
    BackgroundTasks,
    Response,
    status,
    HTTPException,
)
from typing import Optional, List
from sqlalchemy.ext.asyncio import AsyncSession
from src.api.orchestrators.cam_orchestrator import CamOrchestrator
from src.api.services.cam_service import CamService
from src.database.repositories.cam_repository import CamRepository
from src.utils.auth import Auth
from src.database.session import get_db
from src.database.schemas.cam import CamBase, CreateCam, UpdateCam, StreamResponse
from src.api.controllers.cam import CamController
from src.utils.logger import get_logger


logger = get_logger("cam")
cam_router = APIRouter(dependencies=[Depends(Auth.get_current_user)])


def get_cam_controller(db: AsyncSession = Depends(get_db)) -> CamController:
    cam_repo = CamRepository(db=db)
    cam_service = CamService(db=db, repo=cam_repo)
    cam_orchestrator = CamOrchestrator(
        db=db, cam_repo=cam_repo, cam_service=cam_service
    )
    return CamController(cam_service=cam_service, cam_orchestrator=cam_orchestrator)


@cam_router.get("", response_model=List[CamBase])
async def fetch_cams(
    fab_id: Optional[int] = Query(None),
    stage_id: Optional[int] = Query(None),
    unit_ids: Optional[List[int]] = Query(None, alias="unit_ids[]"),
    ctrl: CamController = Depends(get_cam_controller),
):
    return await ctrl.get_multi(fab_id, stage_id, unit_ids)


@cam_router.get("/stream-list", response_model=List[StreamResponse])
async def get_stream_list(
    fab_id: Optional[int] = Query(None),
    stage_id: Optional[int] = Query(None),
    unit_ids: Optional[List[int]] = Query(None),
    ctrl: CamController = Depends(get_cam_controller),
):
    return await ctrl.get_stream_list(fab_id, stage_id, unit_ids)


@cam_router.get("/{cam_id}", response_model=CamBase)
async def get_cam(cam_id: int, ctrl: CamController = Depends(get_cam_controller)):
    return await ctrl.get_one(cam_id)


@cam_router.post("", response_model=CamBase, status_code=status.HTTP_201_CREATED)
async def create_cam(
    data: CreateCam, ctrl: CamController = Depends(get_cam_controller)
):
    return await ctrl.create(data)


@cam_router.patch("/{cam_id}", response_model=CamBase)
async def edit_cam(
    cam_id: int,
    data: UpdateCam,
    background_tasks: BackgroundTasks,
    ctrl: CamController = Depends(get_cam_controller),
):
    return await ctrl.update(cam_id, data, background_tasks)


@cam_router.delete("/{cam_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_cam(cam_id: int, ctrl: CamController = Depends(get_cam_controller)):
    deleted = await ctrl.remove(cam_id)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=f"Cam {cam_id} not found"
        )
    return Response(status_code=status.HTTP_204_NO_CONTENT)
