from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    Query,
    Request,
    UploadFile,
    status,
    HTTPException,
)
from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.services.report_service import ReportService
from src.database.repositories.report_repository import ReportRepository
from src.api.controllers.report import ReportController
from src.database.session import get_db
from src.database.schemas.report import (
    ReportBase,
    StageAnalysisReportResponseList,
    UnitAnalysisCycleDetailResponse,
    UnitAnalysisResponse,
    UpdateWorkIdRequest,
)
from src.database.schemas.report_import import ReportBatchImportResponse
from src.utils.logger import get_logger
from src.utils.auth import Auth

logger = get_logger("report")
report_router = APIRouter(dependencies=[Depends(Auth.get_current_user)])


def get_report_ctrl(db: AsyncSession = Depends(get_db)) -> ReportController:
    report_repo = ReportRepository(db)
    report_service = ReportService(db, report_repo)
    return ReportController(report_service)


@report_router.get(
    "",
    response_model=List[ReportBase],
    status_code=status.HTTP_200_OK,
    summary="獲取 report 數據",
)
async def get_original_data(
    start_at: str = Query(...),
    end_at: str = Query(...),
    fab_id: Optional[int] = Query(None),
    stage_id: Optional[int] = Query(None),
    unit_ids: Optional[List[int]] = Query(None),
    ctrl: ReportController = Depends(get_report_ctrl),
):
    return await ctrl.get_original_data(
        start_time=start_at,
        end_time=end_at,
        fab_id=fab_id,
        stage_id=stage_id,
        unit_ids=unit_ids,
    )


@report_router.get(
    "/stage-analysis-report",
    response_model=List[StageAnalysisReportResponseList],
    status_code=status.HTTP_200_OK,
)
async def get_stage_analysis_report(
    start_at: str = Query(...),
    end_at: str = Query(...),
    fab_id: Optional[int] = Query(None),
    stage_id: Optional[int] = Query(None),
    unit_ids: Optional[List[int]] = Query(None),
    ctrl: ReportController = Depends(get_report_ctrl),
):
    return await ctrl.get_stage_analysis_report_data(
        start_time=start_at,
        end_time=end_at,
        fab_id=fab_id,
        stage_id=stage_id,
        unit_ids=unit_ids,
    )


@report_router.get(
    "/unit-analysis-report",
    response_model=UnitAnalysisResponse,
    status_code=status.HTTP_200_OK,
)
async def get_unit_analysis_report(
    start_at: str = Query(...),
    end_at: str = Query(...),
    fab_id: Optional[int] = Query(None),
    stage_id: Optional[int] = Query(None),
    unit_id: Optional[int] = Query(None),
    ctrl: ReportController = Depends(get_report_ctrl),
):
    return await ctrl.get_unit_analysis_report_data(
        start_time=start_at,
        end_time=end_at,
        fab_id=fab_id,
        stage_id=stage_id,
        unit_id=unit_id,
    )


@report_router.get(
    "/unit-analysis-cycle-detail/{cycle_start_time}",
    response_model=UnitAnalysisCycleDetailResponse,
    status_code=status.HTTP_200_OK,
)
async def get_unit_analysis_ct_report(
    unit_id: int,
    cycle_start_time: str,
    request: Request,
    ctrl: ReportController = Depends(get_report_ctrl),
):
    return await ctrl.get_unit_analysis_cycle_detail_data(
        unit_id=unit_id, cycle_start_time=cycle_start_time, request=request
    )


@report_router.patch(
    "/report/{report_id}/workId",
    response_model=UnitAnalysisCycleDetailResponse,
    status_code=status.HTTP_200_OK,
)
async def update_work_id(
    report_id: int,
    body: UpdateWorkIdRequest,
    ctrl: ReportController = Depends(get_report_ctrl),
):
    try:
        return await ctrl.update_work_id(report_id, body)
    except Exception as e:
        logger.exception(f"Error: {str(e)}")
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@report_router.post(
    "/report/import",
    response_model=ReportBatchImportResponse,
    status_code=status.HTTP_200_OK,
    summary="報表批量匯入（manual）",
)
async def batch_import_reports(
    unit_id: int = Form(...),
    files: List[UploadFile] = File(...),
    ctrl: ReportController = Depends(get_report_ctrl),
):
    return await ctrl.import_reports(unit_id=unit_id, files=files)
