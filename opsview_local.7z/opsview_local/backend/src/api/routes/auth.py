from typing import Dict
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi.security import HTTPAuthorizationCredentials

from src.database.schemas.user import UserResponse
from src.database.repositories.user_repository import UserRepository
from src.api.services.auth_service import AuthService
from src.api.services.uac_service import UacService
from src.api.controllers.auth import AuthController
from src.database.session import get_db
from src.database.schemas.auth import (
    AuthLoginRequest,
    AuthTokenResponse,
    RefreshTokenRequest,
)
from src.utils.token_blacklist import revoke_jti
from src.utils.security import SecurityUtils
from src.utils.auth import Auth
from src.database.models.user import User
from src.utils.exceptions import TokenExpiredError, TokenInvalidError

auth_router = APIRouter()

# DI container
def get_auth_controller(db: AsyncSession = Depends(get_db)) -> AuthController:
    user_repo = UserRepository(db)
    uac_service = UacService()
    auth_service = AuthService(user_repo=user_repo, uac_service=uac_service, db=db)
    return AuthController(auth_service=auth_service)


@auth_router.post(
    "/login",
    response_model=AuthTokenResponse,
    status_code=status.HTTP_200_OK,
    summary="用戶登入或註冊",
    description="若用戶存在則回傳現有資料，否則註冊並回傳新用戶資料。",
)
async def login(
    payload: AuthLoginRequest,
    ctrl: AuthController = Depends(get_auth_controller),
):
    return await ctrl.login(payload)


@auth_router.post(
    "/refresh",
    response_model=AuthTokenResponse,
    status_code=status.HTTP_200_OK,
    summary="使用 refresh token 刷新 access token",
)
async def refresh(
    payload: RefreshTokenRequest,
    ctrl: AuthController = Depends(get_auth_controller),
):
    try:
        return await ctrl.refresh(payload)
    except TokenExpiredError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="refresh_token_expired",
            headers={
                "WWW-Authenticate": 'Bearer error="invalid_token", error_description="Refresh token expired"'
            },
        )
    except TokenInvalidError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="invalid_refresh_token",
            headers={"WWW-Authenticate": 'Bearer error="invalid_token"'},
        )


@auth_router.post(
    "/logout",
    response_model=Dict[str, str],
    status_code=status.HTTP_200_OK,
    summary="用戶登出",
    responses={
        200: {
            "description": "Successful Response",
            "content": {"application/json": {"example": {"message": "Logout success"}}},
        }
    },
)
async def logout(credentials: HTTPAuthorizationCredentials = Depends(Auth.oauth2)):
    token_data = SecurityUtils.decode_token(credentials.credentials)
    jti: str = token_data.get("jti")
    if jti:
        await revoke_jti(jti)
    return {"detail": "Logout successful"}


@auth_router.get(
    "/me",
    response_model=UserResponse,
    status_code=status.HTTP_200_OK,
    summary="獲取當前登入者資訊",
)
async def get_me(current_user: User = Depends(Auth.get_current_user)):
    return current_user
