from fastapi import APIRouter, Depends, HTTPException, status, Query
from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession


from ..controllers.unit import UnitController
from ..controllers.fab import FabController
from ..controllers.stage import StageController
from src.api.orchestrators.unit_orchestrator import UnitOrchestrator
from src.api.services.department_service import DepartmentService
from src.api.services.fab_service import FabService
from src.api.services.stage_service import StageService
from src.api.services.unit_service import UnitService
from src.database.models.fab import Fab
from src.database.models.stage import Stage
from src.database.models.unit import Unit
from src.database.repositories.department_repository import DepartmentRepository
from src.database.repositories.fab_repository import FabRepository
from src.database.repositories.stage_repository import StageRepository
from src.database.repositories.unit_repository import UnitRepository
from src.database.schemas.unit import (
    FabImportRateResponse,
    UnitListResponse,
    UnitResponse,
    UnitCreate,
    UnitSortField,
    UnitUpdate,
)
from src.database.schemas.base import SortOrder
from src.database.schemas.base import PaginatedResponse
from src.database.session import get_db
from src.utils.auth import Auth
from src.utils.logger import get_logger


logger = get_logger("unit")
unit_router = APIRouter(dependencies=[Depends(Auth.get_current_user)])


# Dependency 注入 FabController
async def get_fab_ctrl(db: AsyncSession = Depends(get_db)) -> FabController:
    repo = FabRepository(db=db)
    service = FabService(fab_repo=repo, db=db)
    return FabController(service)


# Dependency 注入 StageController
async def get_stage_ctrl(db: AsyncSession = Depends(get_db)) -> StageController:
    fab_repo = FabRepository(db=db)
    department_repo = DepartmentRepository(db=db)
    repo = StageRepository(db=db)
    service = StageService(
        fab_repo=fab_repo, department_repo=department_repo, stage_repo=repo, db=db
    )
    return StageController(service)


# Dependency 注入 UnitController
async def get_unit_ctrl(db: AsyncSession = Depends(get_db)) -> UnitController:
    fab_repo = FabRepository(db=db)
    department_repo = DepartmentRepository(db=db)
    stage_repo = StageRepository(db=db)
    repo = UnitRepository(db=db)
    fab_service = FabService(fab_repo=fab_repo, db=db)
    department_service = DepartmentService(
        fab_repo=fab_repo, department_repo=department_repo, db=db
    )
    stage_service = StageService(
        fab_repo=fab_repo, department_repo=department_repo, stage_repo=stage_repo, db=db
    )
    service = UnitService(stage_repo=stage_repo, unit_repo=repo, db=db)
    unit_orchestrator = UnitOrchestrator(
        db=db,
        unit_service=service,
        fab_service=fab_service,
        department_service=department_service,
        stage_service=stage_service,
    )
    return UnitController(
        fab_service=fab_service,
        department_service=department_service,
        stage_service=stage_service,
        unit_service=service,
        unit_orchestrator=unit_orchestrator,
    )


@unit_router.get(
    "",
    response_model=PaginatedResponse[UnitListResponse],
    status_code=status.HTTP_200_OK,
    summary="獲取崗位列表",
)
async def get_unit_list(
    ctrl: UnitController = Depends(get_unit_ctrl),
    page: int = Query(1, ge=1),
    limit: int = Query(10, ge=1),
    search: Optional[str] = Query(None),
    sort_field: Optional[UnitSortField] = Query("id"),
    sort_order: Optional[SortOrder] = Query("asc"),
):
    units, metadata = await ctrl.get_paginated_multi(
        page=page,
        limit=limit,
        search=search,
        sort_field=sort_field.value,
        sort_order=sort_order,
    )

    unit_ids = [u.id for u in units]
    status_map = await ctrl.get_server_status_bulk(unit_ids)

    for unit in units:
        setattr(unit, "server_status", bool(status_map.get(unit.id, False)))

    return PaginatedResponse(
        success=True,
        data=units,
        total_count=metadata.get("total"),
        page=metadata.get("page"),
        limit=metadata.get("limit"),
        message="",
    )


@unit_router.get(
    "/list",
    response_model=List[UnitResponse],
    status_code=status.HTTP_200_OK,
    summary="獲取崗位總表",
)
async def get_units(
    location: Optional[str] = None,
    stage_name: Optional[str] = None,
    ctrl: UnitController = Depends(get_unit_ctrl),
):
    filters = []
    if location:
        filters.append(Unit.stage.has(Stage.fab.has(Fab.name == location)))
    if stage_name:
        filters.append(Unit.stage.has(Stage.name == stage_name))

    return await ctrl.get_multi(filters=filters)


@unit_router.post(
    "",
    response_model=UnitResponse,
    status_code=status.HTTP_201_CREATED,
    summary="創建崗位",
)
async def create_unit(
    form_data: UnitCreate,
    ctrl: UnitController = Depends(get_unit_ctrl),
):
    try:
        unit = await ctrl.create_unit(form_data=form_data)
    except Exception as e:
        logger.exception(f"create_unit 創建崗位失敗: {str(e)}")

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="創建崗位失敗"
        )

    return UnitResponse.model_validate(unit)


@unit_router.patch(
    "/{unit_id}",
    response_model=UnitResponse,
    summary="部分修改崗位",
)
async def update_unit(
    unit_id: int,
    form_data: UnitUpdate,
    ctrl: UnitController = Depends(get_unit_ctrl),
):
    updated_unit = await ctrl.update_unit(
        unit_id=unit_id,
        fab_name=form_data.fab_name,
        department_name=form_data.department_name,
        stage_name=form_data.stage_name,
        name=form_data.unit_name,
    )

    updated_unit = await ctrl.get_by_id(unit_id=unit_id)

    return UnitResponse.model_validate(updated_unit)


@unit_router.delete(
    "/{unit_id}",
    response_model=dict,
    status_code=status.HTTP_200_OK,
    summary="刪除崗位",
)
async def delete_unit(
    unit_id: int,
    ctrl: UnitController = Depends(get_unit_ctrl),
):
    success = await ctrl.delete_unit_by_id(unit_id)
    if not success:
        logger.info(f"delete_unit: 崗位不存在")
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="崗位不存在")

    return {"message": f"崗位 {unit_id} 已刪除"}


@unit_router.get(
    "/import-stats",
    response_model=List[FabImportRateResponse],
    summary="各廠區導入率統計",
)
async def get_import_rate_stats(
    ctrl: UnitController = Depends(get_unit_ctrl),
):
    return await ctrl.get_fab_import_rate()
