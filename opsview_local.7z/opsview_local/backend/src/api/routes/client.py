from fastapi import APIRouter, BackgroundTasks, Depends, status
from typing import Dict
from sqlalchemy.ext.asyncio import AsyncSession

from ..controllers.client import ClientController
from src.database.session import get_db
from src.database.schemas.client import ConfigSync
from src.utils.logger import get_logger


logger = get_logger("department")
client_router = APIRouter()


# Dependency 注入 ClientController
async def get_client_ctrl(
    db: AsyncSession = Depends(get_db),
) -> ClientController:
    return ClientController(db)


@client_router.post(
    "/sync-config",
    response_model=Dict,
    status_code=status.HTTP_200_OK,
    summary="同步崗位設定到 Client 端",
)
async def sync_payload(
    form_data: ConfigSync,
    background_tasks: BackgroundTasks,
    ctrl: ClientController = Depends(get_client_ctrl),
):
    await ctrl.assemble_sync_payload(background_tasks, form_data.unit_id)

    return {"detail": "ok"}
