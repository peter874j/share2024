from typing import Optional, List
from fastapi import APIRouter, BackgroundTasks, Depends, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from src.database.session import get_db

from src.utils.logger import get_logger
from src.utils.auth import Auth
from src.database.schemas.base import PaginatedResponse
from src.api.controllers.server import ServerController
from src.database.schemas.server import (
    CreateServer,
    ServerList,
    UpdateServer,
    ServerResponse,
)

logger = get_logger("server")
server_router = APIRouter(dependencies=[Depends(Auth.get_current_user)])

# Dependency 注入 ServerController
async def get_server_ctrl(
    db: AsyncSession = Depends(get_db),
) -> ServerController:
    return ServerController(db)


@server_router.get(
    "", response_model=PaginatedResponse[ServerResponse], summary="列出所有伺服器"
)
async def fetch_servers(
    fab_id: Optional[int] = None,
    ctrl: ServerController = Depends(get_server_ctrl),
    page: int = Query(1, ge=1),
    limit: int = Query(10, ge=1),
):
    servers, metadata = await ctrl.get_paginated_multi(
        form_data=ServerList(fab_id=fab_id),
        page=page,
        limit=limit,
    )

    return PaginatedResponse(
        success=True,
        data=servers,
        total_count=metadata.get("total"),
        page=metadata.get("page"),
        limit=metadata.get("limit"),
        message="",
    )


@server_router.get(
    "/list",
    response_model=List[ServerResponse],
    status_code=status.HTTP_200_OK,
    summary="取得伺服器總表",
)
async def get_servers(
    fab_id: Optional[int] = None,
    ctrl: ServerController = Depends(get_server_ctrl),
):
    return await ctrl.get_multi(form_data=ServerList(fab_id=fab_id))


@server_router.get("/{server_id}", response_model=ServerResponse, summary="取得單一伺服器")
async def get_server(
    server_id: int,
    ctrl: ServerController = Depends(get_server_ctrl),
):
    return await ctrl.get(server_id)


@server_router.post(
    "",
    response_model=ServerResponse,
    status_code=status.HTTP_201_CREATED,
    summary="新增伺服器",
)
async def create_server(
    data: CreateServer,
    background_tasks: BackgroundTasks,
    ctrl: ServerController = Depends(get_server_ctrl),
):
    server: ServerResponse = await ctrl.create(data)

    # 觸發後台 server initialize 事件
    background_tasks.add_task(ctrl.initialize_server, server.id)

    return server


@server_router.patch(
    "/{server_id}",
    response_model=ServerResponse,
    summary="更新伺服器",
)
async def update_server(
    server_id: int,
    data: UpdateServer,
    ctrl: ServerController = Depends(get_server_ctrl),
):
    return await ctrl.update(server_id, data)


@server_router.delete(
    "/{server_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="刪除伺服器",
)
async def delete_server(
    server_id: int,
    ctrl: ServerController = Depends(get_server_ctrl),
):
    await ctrl.remove(server_id)
