from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.services.object_service import ObjectService
from src.database.repositories.object_repository import ObjectRepository
from src.database.schemas.object import (
    ObjectCreate,
    ObjectWithConditionResponse,
    ObjectUpdate,
    ObjectResponse,
)
from src.database.session import get_db
from src.utils.logger import get_logger
from src.utils.auth import Auth
from ..controllers.object import ObjectController

logger = get_logger("object")
object_router = APIRouter(dependencies=[Depends(Auth.get_current_user)])


# Dependency 注入 ObjectController
async def get_obj_ctrl(db: AsyncSession = Depends(get_db)) -> ObjectController:
    object_repo = ObjectRepository(db=db)
    obj_service = ObjectService(object_repo=object_repo, db=db)
    return ObjectController(object_service=obj_service)


@object_router.post(
    "",
    response_model=ObjectResponse,
    status_code=status.HTTP_201_CREATED,
    summary="建立新 作業物件",
)
async def create_object(
    payload: ObjectCreate,
    ctrl: ObjectController = Depends(get_obj_ctrl),
):
    try:
        return await ctrl.create(payload)
    except Exception as e:
        logger.warning(f"create_object: 無法建立 作業物件", exc_info=e)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="無法建立 作業物件",
        )


@object_router.get(
    "",
    response_model=List[ObjectWithConditionResponse],
    status_code=status.HTTP_200_OK,
    summary="取得 作業物件 列表",
)
async def list_objects(
    unit_id: Optional[int] = None,
    ctrl: ObjectController = Depends(get_obj_ctrl),
):
    return await ctrl.get_multi(unit_id=unit_id)


@object_router.get(
    "/{object_id}",
    response_model=ObjectWithConditionResponse,
    status_code=status.HTTP_200_OK,
    summary="取得單一 作業物件",
)
async def get_object(
    object_id: int,
    ctrl: ObjectController = Depends(get_obj_ctrl),
):
    obj = await ctrl.get_one(object_id)
    if not obj:
        logger.info(f"get_object: 作業物件 id={object_id} 不存在")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"作業物件 id={object_id} 不存在",
        )
    return obj


@object_router.patch(
    "/{object_id}",
    response_model=ObjectWithConditionResponse,
    status_code=status.HTTP_200_OK,
    summary="更新 作業物件",
)
async def update_object(
    object_id: int,
    payload: ObjectUpdate,
    ctrl: ObjectController = Depends(get_obj_ctrl),
):
    try:
        obj = await ctrl.update(object_id, payload)
        if not obj:
            logger.info(f"update_object: 作業物件 id={object_id} 不存在")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"作業物件 id={object_id} 不存在",
            )
        return obj
    except Exception as e:
        logger.warning(f"update_object: 作業物件 id={object_id} 不存在或更新失敗", exc_info=e)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"作業物件 id={object_id} 不存在或更新失敗",
        )


@object_router.delete(
    "/{object_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="刪除 作業物件",
)
async def delete_object():
    logger.warning(f"delete_object: 當前版本禁止刪除作業物件")
    raise HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail=f"當前版本禁止刪除作業物件",
    )
