from typing import Optional, List, Dict
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession

from src.utils.auth import Auth
from src.database.session import get_db
from src.database.schemas.user import (
    UserFilter,
    UserResponse,
    UpdateUserRoleRequest,
    UserSortField,
)
from src.database.schemas.base import PaginatedResponse, SortOrder
from src.utils.logger import get_logger

from src.database.repositories.user_repository import UserRepository
from src.api.services.user_service import UserService
from src.api.controllers.user import UserController

logger = get_logger("user")
user_router = APIRouter(dependencies=[Depends(Auth.get_current_user)])


def get_user_ctrl(db: AsyncSession = Depends(get_db)) -> UserController:
    repo = UserRepository(db=db)
    service = UserService(user_repo=repo, db=db)
    return UserController(user_service=service)


@user_router.get(
    "",
    response_model=PaginatedResponse[UserResponse],
    status_code=status.HTTP_200_OK,
    summary="取得用戶列表",
)
async def get_user_list(
    location: Optional[str] = None,
    ctrl: UserController = Depends(get_user_ctrl),
    page: int = Query(1, ge=1),
    limit: int = Query(10, ge=1),
    search: Optional[str] = Query(None),
    sort_field: Optional[UserSortField] = Query("id"),
    sort_order: Optional[SortOrder] = Query("asc"),
):
    users, metadata = await ctrl.get_paginated_multi(
        form_data=UserFilter(location=location),
        page=page,
        limit=limit,
        search=search,
        sort_field=sort_field.value,
        sort_order=sort_order,
    )
    return PaginatedResponse(
        success=True,
        data=users,
        total_count=metadata.get("total"),
        page=metadata.get("page"),
        limit=metadata.get("limit"),
        message="",
    )


@user_router.get(
    "/list",
    response_model=List[UserResponse],
    status_code=status.HTTP_200_OK,
    summary="取得用戶總表",
)
async def get_users(
    location: Optional[str] = None,
    ctrl: UserController = Depends(get_user_ctrl),
):
    filters = {}
    if location:
        filters["location"] = location
    return await ctrl.get_multi(filters)


@user_router.get(
    "/{user_id}",
    response_model=UserResponse,
    status_code=status.HTTP_200_OK,
    summary="取得單一用戶",
)
async def get_user(
    user_id: str,
    ctrl: UserController = Depends(get_user_ctrl),
):
    user = await ctrl.get_one(user_id)
    if not user:
        logger.info(f"get_user: User {user_id} not found")
        raise HTTPException(status.HTTP_404_NOT_FOUND, detail="User Not Found")
    return user


@user_router.put(
    "/{user_id}/role",
    response_model=UserResponse,
    status_code=status.HTTP_200_OK,
    summary="更新用戶角色",
)
async def update_user_role(
    user_id: str,
    request: UpdateUserRoleRequest,
    ctrl: UserController = Depends(get_user_ctrl),
):
    try:
        user = await ctrl.update_user_role(user_id, request.role)
        return UserResponse.model_validate(user)
    except ValueError as e:
        logger.warning(f"update_user_role: Error: {str(e)}")
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
