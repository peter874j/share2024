from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Response
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.schemas.fence import FenceCreate, FenceUpdate, FenceResponse
from src.database.session import get_db
from src.database.repositories.fence_repository import FenceRepository
from src.api.services.fence_service import FenceService
from src.utils.logger import get_logger
from src.utils.auth import Auth
from ..controllers.fence import FenceController

logger = get_logger("fence")
fence_router = APIRouter(dependencies=[Depends(Auth.get_current_user)])


async def get_fence_ctrl(db: AsyncSession = Depends(get_db)) -> FenceController:
    fence_repo = FenceRepository(db=db)
    fence_service = FenceService(db=db, fence_repo=fence_repo)
    return FenceController(fence_service=fence_service)


@fence_router.post(
    "",
    response_model=FenceResponse,
    status_code=status.HTTP_201_CREATED,
    summary="建立新 作業圍籬",
)
async def create_fence(
    payload: FenceCreate, ctrl: FenceController = Depends(get_fence_ctrl)
):
    try:
        return await ctrl.create(payload)
    except HTTPException:
        raise
    except Exception as e:
        logger.warning(f"create_fence: 無法建立 作業圍籬", exc_info=e)
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="無法建立 作業圍籬")


@fence_router.get(
    "",
    response_model=List[FenceResponse],
    status_code=status.HTTP_200_OK,
    summary="取得 作業圍籬 列表",
)
async def list_fences(
    unit_id: Optional[int] = None, ctrl: FenceController = Depends(get_fence_ctrl)
):
    return await ctrl.get_multi(unit_id=unit_id)


@fence_router.get(
    "/{fence_id}",
    response_model=FenceResponse,
    status_code=status.HTTP_200_OK,
    summary="取得單一 作業圍籬",
)
async def get_fence(fence_id: int, ctrl: FenceController = Depends(get_fence_ctrl)):
    obj = await ctrl.get_one(fence_id)
    if not obj:
        logger.info(f"get_fence: 作業圍籬 id={fence_id} 不存在")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=f"作業圍籬 id={fence_id} 不存在"
        )
    return obj


@fence_router.patch(
    "/{fence_id}",
    response_model=FenceResponse,
    status_code=status.HTTP_200_OK,
    summary="更新 作業圍籬",
)
async def update_fence(
    fence_id: int, payload: FenceUpdate, ctrl: FenceController = Depends(get_fence_ctrl)
):
    try:
        obj = await ctrl.update(fence_id, payload)
        if not obj:
            logger.info(f"update_fence: 作業圍籬 id={fence_id} 不存在")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail=f"作業圍籬 id={fence_id} 不存在"
            )
        return obj
    except HTTPException:
        raise
    except Exception as e:
        logger.warning(f"update_fence: 更新 作業圍籬 id={fence_id} 失敗", exc_info=e)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=f"更新 作業圍籬 id={fence_id} 失敗"
        )


@fence_router.delete(
    "/{fence_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="刪除 作業圍籬",
)
async def delete_fence(fence_id: int, ctrl: FenceController = Depends(get_fence_ctrl)):
    deleted = await ctrl.remove(fence_id)
    if not deleted:
        logger.info(f"delete_fence: 作業圍籬 id={fence_id} 不存在")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=f"作業圍籬 id={fence_id} 不存在"
        )
    return Response(status_code=status.HTTP_204_NO_CONTENT)
