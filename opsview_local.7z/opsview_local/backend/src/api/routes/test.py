from typing import Dict, List, Optional
from fastapi import APIRouter
from pydantic import BaseModel

from src.utils.logger import get_logger

test_router = APIRouter()


class Fence(BaseModel):
    name: str
    points: List[List[float]]


class Condition(BaseModel):
    type: str
    object: Optional[str]  # 可選值（允許為 None）
    objects: Optional[List[str]]  # 可選值（允許為 None）
    fence: Optional[str]  # 可選值（允許為 None）


class Step(BaseModel):
    name: str
    condition: str
    stateTransitionMode: str


class Snippet(BaseModel):
    fences: List[Fence]
    conditions: Dict[str, Condition]
    steps: List[Step]
    cycleTriggerCondition: str


@test_router.get("/check_ports")
async def get_check_ports():
    return [
        {
            "port": 8001,
            "camera_ip": "127.0.0.1",
            "status": {
                "system_status": "運行中",
                "is_running": True,
                "camera_connected": True,
                "error_message": None,
            },
            "available": True,
        },
        {
            "port": 8002,
            "camera_ip": "127.0.0.1",
            "status": {
                "system_status": "錯誤",
                "is_running": False,
                "camera_connected": False,
                "error_message": "連接逾時",
            },
            "available": False,
        },
        {
            "port": 8003,
            "camera_ip": "127.0.0.1",
            "status": {
                "system_status": "錯誤",
                "is_running": False,
                "camera_connected": False,
                "error_message": "連接逾時",
            },
            "available": False,
        },
        {
            "port": 8004,
            "camera_ip": "127.0.0.1",
            "status": {
                "system_status": "錯誤",
                "is_running": False,
                "camera_connected": False,
                "error_message": "連接逾時",
            },
            "available": False,
        },
        {
            "port": 8005,
            "camera_ip": "127.0.0.1",
            "status": {
                "system_status": "錯誤",
                "is_running": False,
                "camera_connected": False,
                "error_message": "連接逾時",
            },
            "available": False,
        },
        {
            "port": 8006,
            "camera_ip": "127.0.0.1",
            "status": {
                "system_status": "錯誤",
                "is_running": False,
                "camera_connected": False,
                "error_message": "連接逾時",
            },
            "available": False,
        },
        {
            "port": 8007,
            "camera_ip": "127.0.0.1",
            "status": {
                "system_status": "錯誤",
                "is_running": False,
                "camera_connected": False,
                "error_message": "連接逾時",
            },
            "available": False,
        },
        {
            "port": 8008,
            "camera_ip": "127.0.0.1",
            "status": {
                "system_status": "錯誤",
                "is_running": False,
                "camera_connected": False,
                "error_message": "連接逾時",
            },
            "available": False,
        },
    ]


@test_router.get("/names")
async def get_names():
    return {
        "names": {
            "0": "persons",
            "1": "hands",
            "2": "panel",
            "3": "keyboard",
            "4": "mouse",
            "5": "flashlight",
            "6": "lupe",
            "7": "caliper",
            "8": "Matrix",
        }
    }


@test_router.get("/config")
async def get_config():
    return {
        "fences": [
            {
                "name": "FenceA",
                "points": [
                    [1, 1439],
                    [1, 1080],
                    [519, 787],
                    [1230, 680],
                    [1860, 801],
                    [2559, 1183],
                    [2559, 1439],
                ],
            },
            {
                "name": "FenceB",
                "points": [
                    [2265, 385],
                    [2333, 398],
                    [2511, 579],
                    [2324, 880],
                    [2196, 880],
                    [2151, 803],
                ],
            },
            {
                "name": "FenceC",
                "points": [[281, 327], [442, 205], [524, 220], [368, 340]],
            },
        ],
        "conditions": {
            "panelExists": {
                "type": "exists",
                "object": "panel",
                "objects": None,
                "fence": None,
            },
            "handsInFenceA": {
                "type": "in_fence",
                "object": "hands",
                "objects": None,
                "fence": "FenceA",
            },
            "panelHandsOverlap": {
                "type": "overlap",
                "object": None,
                "objects": ["panel", "hands"],
                "fence": None,
            },
            "keyboardHandsOverlapInFenceB": {
                "type": "overlap_in_fence",
                "object": None,
                "objects": ["keyboard", "hands"],
                "fence": "FenceB",
            },
            "mouseHandsOverlapInFenceB": {
                "type": "overlap_in_fence",
                "object": None,
                "objects": ["mouse", "hands"],
                "fence": "FenceB",
            },
            "handsInFenceB": {
                "type": "in_fence",
                "object": "hands",
                "objects": None,
                "fence": "FenceB",
            },
            "keyboardHandsOverlapInFenceC": {
                "type": "overlap_in_fence",
                "object": None,
                "objects": ["keyboard", "hands"],
                "fence": "FenceC",
            },
            "mouseHandsOverlapInFenceC": {
                "type": "overlap_in_fence",
                "object": None,
                "objects": ["mouse", "hands"],
                "fence": "FenceC",
            },
            "handsInFenceC": {
                "type": "in_fence",
                "object": "hands",
                "objects": None,
                "fence": "FenceC",
            },
        },
        "steps": [
            {
                "name": "OP Idle",
                "condition": "not panelExists",
                "stateTransitionMode": "A",
            },
            {"name": "EQ Idle", "condition": "", "stateTransitionMode": "A"},
            {
                "name": "StepA",
                "condition": "panelExists and handsInFenceA and panelHandsOverlap",
                "stateTransitionMode": "A",
            },
            {
                "name": "StepB",
                "condition": "panelExists and handsInFenceB or (keyboardHandsOverlapInFenceB or mouseHandsOverlapInFenceB)",
                "stateTransitionMode": "A",
            },
            {
                "name": "StepC",
                "condition": "panelExists and (handsInFenceC or keyboardHandsOverlapInFenceC or mouseHandsOverlapInFenceC)",
                "stateTransitionMode": "A",
            },
        ],
        "cycleTriggerCondition": "panelExists",
    }


@test_router.post("/config")
async def update_config(form_data: Snippet):
    logger = get_logger("update_config")

    logger.info(f"Recive update config data: {form_data}")
    return form_data
