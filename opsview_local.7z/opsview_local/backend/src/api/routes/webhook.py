from typing import List
from fastapi import APIRouter, Body, Depends, Header, Request
from sqlalchemy.ext.asyncio import AsyncSession
from src.database.session import get_db
from src.api.controllers.webhook import WebhookController
from src.database.schemas.webhook import CameraReportData
from src.utils.logger import get_logger

webhook_router = APIRouter()
logger = get_logger("webhook_router")


def get_webhook_ctrl(db: AsyncSession = Depends(get_db)) -> WebhookController:
    return WebhookController(db)


@webhook_router.post(
    "/camera-report",
    summary="接收攝影機報告",
    description="""
                此端點用於接收 Client 主機定期回傳的攝影機報告資料。

                安全性要求：
                - **X-Signature Header**：使用 HMAC-SHA256 對報告 JSON 內容進行簽名
                - **Content-Type**：必須為 `application/json`

                簽名計算方式（Python 範例）：
                ```python
                import hmac, hashlib, json

                SECRET_KEY = "your_shared_secret_key"
                body = json.dumps(payload).encode()
                signature = hmac.new(SECRET_KEY.encode(), body, hashlib.sha256).hexdigest()
                ```

                Header 範例：
                ```
                X-Signature: <HMAC-SHA256簽名值>
                ```
                """,
)
async def receive_camera_report(
    request: Request,
    x_signature: str = Header(..., alias="X-Signature"),
    reports: List[CameraReportData] = Body(...),
    ctrl: WebhookController = Depends(get_webhook_ctrl),
):
    return await ctrl.receive_camera_report(
        request=request, signature=x_signature, reports=reports
    )
