from fastapi import APIRouter, Depends, status
from typing import List
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.services.department_service import DepartmentService
from src.database.repositories.department_repository import DepartmentRepository
from src.database.repositories.fab_repository import FabRepository
from src.database.schemas.department import (
    DepartmentResponse,
)
from ..controllers.department import DepartmentController
from src.utils.logger import get_logger
from src.database.session import get_db


logger = get_logger("department")
department_router = APIRouter()


# Dependency 注入 DepartmentController
async def get_department_ctrl(
    db: AsyncSession = Depends(get_db),
) -> DepartmentController:
    fab_repo = FabRepository(db)
    department_repo = DepartmentRepository(db)
    department_service = DepartmentService(
        fab_repo=fab_repo, department_repo=department_repo, db=db
    )
    return DepartmentController(department_service=department_service)


@department_router.get(
    "",
    response_model=List[DepartmentResponse],
    status_code=status.HTTP_200_OK,
    summary="獲取部門列表",
)
async def get_department_list(
    ctrl: DepartmentController = Depends(get_department_ctrl),
):
    departments = await ctrl.get_multi()

    # 直接返回 DepartmentResponse 的列表
    return departments
