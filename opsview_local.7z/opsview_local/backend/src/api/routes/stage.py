from fastapi import APIRouter, Depends, status
from typing import Optional, List
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.services.stage_service import StageService
from src.database.repositories.fab_repository import FabRepository
from src.database.repositories.department_repository import DepartmentRepository
from src.database.repositories.stage_repository import StageRepository
from src.database.schemas.stage import (
    StageList,
    StageResponse,
)
from ..controllers.stage import StageController
from src.utils.logger import get_logger
from src.database.session import get_db


logger = get_logger("stage")
stage_router = APIRouter()


# Dependency 注入 StageController
async def get_stage_ctrl(db: AsyncSession = Depends(get_db)) -> StageController:
    fab_repo = FabRepository(db)
    department_repo = DepartmentRepository(db)
    stage_repo = StageRepository(db)
    stage_service = StageService(
        fab_repo=fab_repo, department_repo=department_repo, stage_repo=stage_repo, db=db
    )
    return StageController(stage_service=stage_service)


@stage_router.get(
    "",
    response_model=List[StageResponse],
    status_code=status.HTTP_200_OK,
    summary="獲取站點列表",
)
async def get_stage_list(
    location: Optional[str] = None,
    ctrl: StageController = Depends(get_stage_ctrl),
):
    filters = {}
    if location:
        filters["location"] = location

    return await ctrl.get_multi(form_data=StageList(location=location))
