from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Response
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.services.condition_service import ConditionService
from src.database.repositories.condition_repository import ConditionRepository
from src.database.schemas.condition import (
    ConditionCreate,
    ConditionUpdate,
    ConditionResponse,
    ConditionWithObjectsResponse,
)
from src.database.session import get_db
from src.utils.logger import get_logger
from src.utils.auth import Auth
from ..controllers.condition import ConditionController

logger = get_logger("condition")
condition_router = APIRouter(dependencies=[Depends(Auth.get_current_user)])


async def get_condition_ctrl(db: AsyncSession = Depends(get_db)) -> ConditionController:
    condition_repo = ConditionRepository(db=db)
    condition_service = ConditionService(db=db, condition_repo=condition_repo)
    return ConditionController(condition_service=condition_service)


@condition_router.post(
    "",
    response_model=ConditionResponse,
    status_code=status.HTTP_201_CREATED,
    summary="建立 作業觸發條件",
)
async def create_condition(
    payload: ConditionCreate, ctrl: ConditionController = Depends(get_condition_ctrl)
):
    try:
        return await ctrl.create(payload)
    except HTTPException:
        raise
    except Exception as e:
        logger.warning("create_condition: 無法建立 作業觸發條件", exc_info=e)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="無法建立 作業觸發條件"
        )


@condition_router.get(
    "",
    response_model=List[ConditionWithObjectsResponse],
    status_code=status.HTTP_200_OK,
    summary="列出所有 作業觸發條件",
)
async def list_conditions(
    unit_id: Optional[int] = None,
    ctrl: ConditionController = Depends(get_condition_ctrl),
):
    return await ctrl.get_multi(unit_id=unit_id)


@condition_router.get(
    "/{condition_id}",
    response_model=ConditionWithObjectsResponse,
    status_code=status.HTTP_200_OK,
    summary="取得單一 作業觸發條件",
)
async def get_condition(
    condition_id: int, ctrl: ConditionController = Depends(get_condition_ctrl)
):
    obj = await ctrl.get_one(condition_id)
    if not obj:
        logger.info(f"get_condition: 作業觸發條件 id={condition_id} 不存在")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"作業觸發條件 id={condition_id} 不存在",
        )
    return obj


@condition_router.patch(
    "/{condition_id}",
    response_model=ConditionWithObjectsResponse,
    status_code=status.HTTP_200_OK,
    summary="更新 作業觸發條件",
)
async def update_condition(
    condition_id: int,
    payload: ConditionUpdate,
    ctrl: ConditionController = Depends(get_condition_ctrl),
):
    try:
        obj = await ctrl.update(condition_id, payload)
        if not obj:
            logger.info(f"update_condition: 作業觸發條件 id={condition_id} 不存在")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"作業觸發條件 id={condition_id} 不存在",
            )
        return obj
    except HTTPException:
        raise
    except Exception as e:
        logger.warning(f"update_condition: 更新 作業觸發條件 id={condition_id} 失敗", exc_info=e)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"更新 作業觸發條件 id={condition_id} 失敗",
        )


@condition_router.delete(
    "/{condition_id}", status_code=status.HTTP_204_NO_CONTENT, summary="刪除 作業觸發條件"
)
async def delete_condition(
    condition_id: int, ctrl: ConditionController = Depends(get_condition_ctrl)
):
    deleted = await ctrl.remove(condition_id)
    if not deleted:
        logger.info(f"delete_condition: 作業觸發條件 id={condition_id} 不存在")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"作業觸發條件 id={condition_id} 不存在",
        )
    return Response(status_code=status.HTTP_204_NO_CONTENT)
