from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Response
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.schemas.logic import LogicCreate, LogicUpdate, LogicResponse
from src.database.session import get_db
from src.utils.logger import get_logger
from src.utils.auth import Auth
from src.api.controllers.logic import LogicController
from src.api.services.logic_service import LogicService
from src.database.repositories.logic_repository import LogicRepository

logger = get_logger("logic")
logic_router = APIRouter(dependencies=[Depends(Auth.get_current_user)])


async def get_logic_ctrl(db: AsyncSession = Depends(get_db)) -> LogicController:
    logic_repo = LogicRepository(db=db)
    logic_service = LogicService(db=db, logic_repo=logic_repo)
    return LogicController(logic_service=logic_service)


@logic_router.post(
    "",
    response_model=LogicResponse,
    status_code=status.HTTP_201_CREATED,
    summary="建立 作業步驟解析邏輯",
)
async def create_logic(
    payload: LogicCreate, ctrl: LogicController = Depends(get_logic_ctrl)
):
    try:
        return await ctrl.create(payload)
    except HTTPException:
        raise
    except Exception as e:
        logger.warning(f"create_logic: 無法建立 作業步驟解析邏輯", exc_info=e)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="無法建立 作業步驟解析邏輯"
        )


@logic_router.get(
    "",
    response_model=List[LogicResponse],
    status_code=status.HTTP_200_OK,
    summary="列出所有 作業步驟解析邏輯",
)
async def list_logics(
    unit_id: Optional[int] = None, ctrl: LogicController = Depends(get_logic_ctrl)
):
    return await ctrl.get_multi(unit_id=unit_id)


@logic_router.get(
    "/{logic_id}",
    response_model=LogicResponse,
    status_code=status.HTTP_200_OK,
    summary="取得單一 作業步驟解析邏輯",
)
async def get_logic(logic_id: int, ctrl: LogicController = Depends(get_logic_ctrl)):
    obj = await ctrl.get_one(logic_id)
    if not obj:
        logger.info(f"get_logic: 作業步驟解析邏輯 id={logic_id} 不存在")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"作業步驟解析邏輯 id={logic_id} 不存在",
        )
    return obj


@logic_router.patch(
    "/{logic_id}",
    response_model=LogicResponse,
    status_code=status.HTTP_200_OK,
    summary="更新 作業步驟解析邏輯",
)
async def update_logic(
    logic_id: int, payload: LogicUpdate, ctrl: LogicController = Depends(get_logic_ctrl)
):
    try:
        obj = await ctrl.update(logic_id, payload)
        if not obj:
            logger.info(f"update_logic: 作業步驟解析邏輯 id={logic_id} 不存在")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"作業步驟解析邏輯 id={logic_id} 不存在",
            )
        return obj
    except HTTPException:
        raise
    except Exception as e:
        logger.warning(f"update_logic: 更新 作業步驟解析邏輯 id={logic_id} 失敗", exc_info=e)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"更新 作業步驟解析邏輯 id={logic_id} 失敗",
        )


@logic_router.delete(
    "/{logic_id}", status_code=status.HTTP_204_NO_CONTENT, summary="刪除 作業步驟解析邏輯"
)
async def delete_logic(logic_id: int, ctrl: LogicController = Depends(get_logic_ctrl)):
    deleted = await ctrl.remove(logic_id)
    if not deleted:
        logger.info(f"delete_logic: 作業步驟解析邏輯 id={logic_id} 不存在")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"作業步驟解析邏輯 id={logic_id} 不存在",
        )
    return Response(status_code=status.HTTP_204_NO_CONTENT)
