from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import selectinload

from src.api.services.unit_service import UnitService
from src.api.services.fab_service import FabService
from src.api.services.department_service import DepartmentService
from src.api.services.stage_service import StageService
from src.database.schemas.unit import UnitCreate
from src.database.models.unit import Unit
from src.database.models.fab import Fab
from src.database.models.stage import Stage
from src.utils.logger import get_logger
from src.utils.exceptions import ConflictError, OrchestrationError

logger = get_logger("unit_orchestrator")


class UnitOrchestrator:
    def __init__(
        self,
        db: AsyncSession,
        unit_service: UnitService,
        fab_service: FabService,
        department_service: DepartmentService,
        stage_service: StageService,
    ):
        self.db = db
        self.unit_service = unit_service
        self.fab_service = fab_service
        self.department_service = department_service
        self.stage_service = stage_service

    async def create_unit(self, form_data: UnitCreate):
        # 建議：在 Service 層也做名稱正規化，這裡可再記錄原始輸入
        logger.info(
            "creating unit",
            extra={
                "fab": form_data.fab_name,
                "department": form_data.department_name,
                "stage": form_data.stage_name,
                "unit": form_data.unit_name,
            },
        )
        try:
            fab = await self.fab_service.fetch_or_create_fab(
                fab_name=form_data.fab_name, commit=False
            )

            department = (
                await self.department_service.fetch_or_create_department_from_fab(
                    department_name=form_data.department_name,
                    fab_id=fab.id,
                    commit=False,
                )
            )

            stage = (
                await self.stage_service.fetch_or_create_stage_from_fab_and_department(
                    stage_name=form_data.stage_name,
                    fab_id=fab.id,
                    department_id=department.id,
                    commit=False,
                )
            )

            unit = await self.unit_service.create_unit_from_stage(
                unit_name=form_data.unit_name, stage_id=stage.id, commit=False
            )

            await self.db.commit()
            await self.db.refresh(unit)

            unit = await self.unit_service.get_by_id_with_filters(
                unit_id=unit.id,
                eager_options=[
                    selectinload(Unit.stage)
                    .selectinload(Stage.fab)
                    .selectinload(Fab.departments),
                    selectinload(Unit.cams),
                ],
            )

            return unit

        except IntegrityError as ie:
            # 由唯一鍵衝突導致，回到上層可映成 409 Conflict
            logger.warning("integrity error on create_unit", extra={"error": str(ie)})
            raise ConflictError(
                "Unit creation conflict. Possibly already exists."
            ) from ie

        except OrchestrationError as oe:
            # 已知業務/協作錯誤，原樣往上丟
            logger.warning(
                "orchestration error on create_unit", extra={"error": str(oe)}
            )
            raise

        except Exception as e:
            logger.error("unexpected error creating unit", exc_info=e)
            # 不在這層回傳 HTTP；交由上層轉換
            raise OrchestrationError("Failed to create unit.") from e
