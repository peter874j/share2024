import json
import re
from datetime import date, datetime, timedelta, timezone
from typing import List, Optional

from fastapi import UploadFile

from src.api.services.report_service import ReportService
from src.database.schemas.report_import import (
    ManualReportData,
    ReportBatchImportResponse,
    ReportBatchImportFileResult,
)
from src.utils.logger import get_logger

logger = get_logger(__name__)

MAX_DAILY_CYCLES = 600


class ReportImportOrchestrator:
    def __init__(self, service: ReportService):
        self.service = service

    async def process(
        self, unit_id: int, files: List[UploadFile]
    ) -> ReportBatchImportResponse:
        results: List[ReportBatchImportFileResult] = []
        success = skipped = failed = 0

        for f in files:
            try:
                res = await self._process_single(unit_id, f)
                results.append(res)
                if res.status == "success":
                    success += 1
                elif res.status == "skipped":
                    skipped += 1
                else:
                    failed += 1
            except Exception:
                logger.exception("Batch import single file error")
                results.append(
                    ReportBatchImportFileResult(
                        filename=f.filename or "",
                        date=None,
                        total=0,
                        inserted=0,
                        skipped=0,
                        errors=["Unexpected server error"],
                        status="failed",
                    )
                )
                failed += 1

        return ReportBatchImportResponse(
            total_files=len(files),
            success_files=success,
            skipped_files=skipped,
            failed_files=failed,
            results=results,
        )

    async def _process_single(
        self, unit_id: int, file: UploadFile
    ) -> ReportBatchImportFileResult:
        MAX_FILE_CYCLES = 600  # 單檔有效筆數上限

        filename = file.filename or ""
        content_bytes = await file.read()
        text = content_bytes.decode("utf-8", errors="replace").strip()

        file_dt = self._extract_date_from_filename(filename)
        if file_dt is None:
            return ReportBatchImportFileResult(
                filename=filename,
                date=None,
                total=0,
                inserted=0,
                skipped=0,
                errors=["Filename must contain date like YYYY-MM-DD or YYYYMMDD"],
                status="failed",
            )

        # 檢核檔名日期不可為未來日期（台灣時區 +8）
        taiwan_tz = timezone(timedelta(hours=8))
        today_tw = datetime.now(taiwan_tz).date()
        if file_dt > today_tw:
            return ReportBatchImportFileResult(
                filename=filename,
                date=file_dt.isoformat(),
                total=0,
                inserted=0,
                skipped=0,
                errors=[f"Date in filename ({file_dt}) is in the future compared to today's date ({today_tw}) in UTC+8 timezone"],
                status="failed",
            )

        # 日衝突檢核：同 unit + 同日期若已有人工匯入項目則略過整檔
        has_conflict = await self.service.repo.exists_manual_items_for_unit_on_date(
            unit_id, file_dt
        )
        if has_conflict:
            return ReportBatchImportFileResult(
                filename=filename,
                date=file_dt.isoformat(),
                total=0,
                inserted=0,
                skipped=0,
                errors=[
                    f"Conflict: unit_id={unit_id} already has items on {file_dt.isoformat()}"
                ],
                status="skipped",
            )

        # 解析 payload
        try:
            payloads = self._parse_payload(text)  # List[dict]
        except ValueError as e:
            return ReportBatchImportFileResult(
                filename=filename,
                date=file_dt.isoformat(),
                total=0,
                inserted=0,
                skipped=0,
                errors=[f"Parse error: {str(e)}"],
                status="failed",
            )

        total = len(payloads)
        if total == 0:
            return ReportBatchImportFileResult(
                filename=filename,
                date=file_dt.isoformat(),
                total=0,
                inserted=0,
                skipped=0,
                errors=["Empty payload"],
                status="failed",
            )

        models: List[ManualReportData] = []
        transformed: List[dict] = []
        errors: List[str] = []

        # 驗證與轉換 + 檔名/內容日期一致（以 UTC 日曆日判定）
        for idx, obj in enumerate(payloads, start=1):
            try:
                model = ManualReportData.model_validate(obj)
            except Exception as e:
                errors.append(f"record#{idx}: schema invalid: {str(e)}")
                continue

            rec, _ = self.service.transform_cycle_data(model)

            cst = rec.get("cycle_start_time")
            if not isinstance(cst, datetime):
                errors.append(f"record#{idx}: cycle_start_time missing or invalid")
                continue

            cst_utc = cst if cst.tzinfo else cst.replace(tzinfo=timezone.utc)
            cst_utc = cst_utc.astimezone(timezone.utc)
            if cst_utc.date() != file_dt:
                errors.append(
                    f"record#{idx}: date mismatch (file={file_dt.isoformat()}, cycle={cst_utc.date().isoformat()})"
                )
                continue

            models.append(model)
            transformed.append(rec)

        if not transformed:
            return ReportBatchImportFileResult(
                filename=filename,
                date=file_dt.isoformat(),
                total=total,
                inserted=0,
                skipped=total,
                errors=(errors or ["No valid records"]),
                status="failed",
            )

        # 檔案內有效筆數上限檢查：超過 600 則整檔失敗且不寫入
        valid_count = len(transformed)
        if valid_count > MAX_FILE_CYCLES:
            errors.append(
                f"File has {valid_count} valid records, exceeds limit {MAX_FILE_CYCLES}"
            )
            return ReportBatchImportFileResult(
                filename=filename,
                date=file_dt.isoformat(),
                total=total,
                inserted=0,
                skipped=total,
                errors=errors,
                status="failed",
            )

        # 寫入（source='manual'）
        try:
            await self.service.create_report(
                unit_id=unit_id,
                transformed_list=transformed,
                original_data=models,
                source="manual",
            )
        except Exception as e:
            logger.exception("create_report failed")
            return ReportBatchImportFileResult(
                filename=filename,
                date=file_dt.isoformat(),
                total=total,
                inserted=0,
                skipped=total,
                errors=[f"DB error: {str(e)}"],
                status="failed",
            )

        inserted = len(transformed)
        skipped_cnt = total - inserted  # 包含 schema/date 不符的筆數
        return ReportBatchImportFileResult(
            filename=filename,
            date=file_dt.isoformat(),
            total=total,
            inserted=inserted,
            skipped=skipped_cnt,
            errors=errors,
            status="success",
        )

    def _extract_date_from_filename(self, name: str) -> Optional[date]:
        """
        從檔名擷取日期（優先 YYYY-MM-DD，其次 YYYYMMDD）
        """
        m = re.search(r"(\d{4}-\d{2}-\d{2})", name)
        if m:
            try:
                return datetime.strptime(m.group(1), "%Y-%m-%d").date()
            except ValueError:
                pass
        m = re.search(r"(\d{8})", name)
        if m:
            try:
                return datetime.strptime(m.group(1), "%Y%m%d").date()
            except ValueError:
                pass
        return None

    def _parse_payload(self, text: str) -> List[dict]:
        """
        支援：
        - JSON array: [ {...}, {...} ]
        - NDJSON: 每行一筆 JSON
        """
        if not text:
            return []
        s = text.lstrip()
        if s.startswith("["):
            try:
                arr = json.loads(text)
            except json.JSONDecodeError as e:
                raise ValueError(f"Invalid JSON array: {str(e)}")
            if not isinstance(arr, list):
                raise ValueError("Top-level JSON must be an array")
            return [x for x in arr if isinstance(x, dict)]
        # NDJSON
        objs: List[dict] = []
        for i, line in enumerate(text.splitlines(), start=1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as e:
                raise ValueError(f"NDJSON line {i} invalid: {str(e)}")
            if isinstance(obj, dict):
                objs.append(obj)
        return objs
