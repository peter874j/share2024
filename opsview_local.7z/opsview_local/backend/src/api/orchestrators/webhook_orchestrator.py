from typing import List
from fastapi import HTTPException, status
from fastapi.encoders import jsonable_encoder
from sqlalchemy.ext.asyncio import AsyncSession
from src.database.repositories.stage_repository import StageRepository
from src.api.services.unit_service import UnitService
from src.api.services.report_service import ReportService
from src.database.repositories.unit_repository import UnitRepository
from src.database.repositories.report_repository import ReportRepository
from src.database.schemas.webhook import CameraReportData
from src.utils.security import SecurityUtils
from src.utils.logger import get_logger
from src.config.settings import settings

logger = get_logger("webhook_orchestrator")


class WebhookOrchestrator:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.unit_service = UnitService(StageRepository(db), UnitRepository(db), db)
        self.report_service = ReportService(db, ReportRepository(db))

    def _ensure_uniform_source(self, reports: List[CameraReportData]):
        # 確保一批 reports 來自相同 cam/server（保留原來「單一 unit」的語意）
        first = reports[0]
        for r in reports[1:]:
            if not (
                r.Server_IP == first.Server_IP
                and r.Cam_IP == first.Cam_IP
                and r.Cam_Port == first.Cam_Port
            ):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Reports must originate from the same camera and server.",
                )
        return first.Server_IP, first.Cam_IP, first.Cam_Port

    async def handle_camera_report(
        self, *, signature: str, body: bytes, reports: List[CameraReportData]
    ):
        logger.debug(f"receive_camera_report: Body: f{body}")
        # 1) 驗證簽章
        try:
            SecurityUtils.verify_hmac_sha256(settings.webhook_secret, body, signature)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN, detail="Invalid signature"
            )

        if not reports:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="Empty report payload",
            )

        # 2) 檢查同一來源並解析 Unit
        server_ip, cam_ip, cam_port = self._ensure_uniform_source(reports)
        unit = await self.unit_service.resolve_unit(
            server_ip=server_ip, cam_ip=cam_ip, cam_port=cam_port
        )

        # 3) 轉換所有報表
        transformed_list = []
        missing_fields_agg = set()
        for report in reports:
            transformed, missing = self.report_service.transform_cycle_data(report)
            transformed_list.append(transformed)
            for m in missing:
                missing_fields_agg.add(m)

        logger.debug(
            f"webhook.handle_camera_report: transformed_list size={len(transformed_list)}"
        )

        # 4) 建立 Report（提交交易在 Service）
        created = await self.report_service.create_report(
            unit_id=unit.id, transformed_list=transformed_list, original_data=reports
        )

        # 5) 回傳結果（保留原輸出語意）
        return created
