from typing import Dict, List, Optional
from fastapi import BackgroundTasks, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.models.fab import Fab
from src.database.models.server import Server
from src.api.services.cam_service import CamService
from src.database.repositories.cam_repository import ICamRepository
from src.database.schemas.cam import StreamResponse
from src.database.schemas.unit import UnitImportStatus
from src.database.schemas.condition import ObjectType
from src.database.models.object import Object
from src.database.models.fence import Fence
from src.database.models.logic import Logic
from src.database.models.condition import Condition
from src.database.models.condition_object import ConditionObject
from src.utils.client_requests import ClientRequests
from src.utils.logger import get_logger

logger = get_logger("cam_orchestrator")


class CamOrchestrator:
    def __init__(
        self, db: AsyncSession, cam_repo: ICamRepository, cam_service: CamService
    ):
        self.db = db
        self.repo = cam_repo
        self.cam_service = cam_service

    # ---------- Pass-throughs to Service when simple ----------
    async def get_stream_list(
        self,
        fab_id: Optional[int] = None,
        stage_id: Optional[int] = None,
        unit_ids: Optional[List[int]] = None,
    ) -> List[StreamResponse]:
        return await self.cam_service.get_stream_list(
            fab_id=fab_id, stage_id=stage_id, unit_ids=unit_ids
        )

    # ---------- Background-init coordination ----------
    async def check_cam_initialization(
        self, cam_id: int, background_tasks: BackgroundTasks
    ) -> None:
        cam = await self.repo.get_cam_with_units(cam_id)
        if cam is None:
            logger.info(
                f"check_cam_initialization: Cam with ID {cam_id} does not exist."
            )
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Cam with ID {cam_id} does not exist.",
            )

        if not cam.units or cam.import_status is True:
            return

        background_tasks.add_task(self.initialize_cam, cam_id)

    async def initialize_cam(self, cam_id: int) -> None:
        log = get_logger("initialize_cam")
        try:
            # 1) Load cam with server/fab
            cam = await self.repo.get_cam_with_server_fab(cam_id)
            if not cam:
                log.info(f"initialize_cam: Cam {cam_id} not found")
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Cam {cam_id} not found",
                )

            # 2) Resolve bound unit
            unit = await self.repo.get_unit_by_cam_id(cam_id)
            if not unit:
                log.info(f"initialize_cam: Unit for Cam {cam_id} not found")
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Unit for Cam {cam_id} not found",
                )
            unit_id = unit.id

            # 3) Fetch host data
            server: Server = cam.server
            server_fab: Fab = server.fab
            host_names = await ClientRequests.fetch_host_names(
                server_ip=f"{server.ip}:{cam.port}", server_location=server_fab.name
            )
            host_cfg = await ClientRequests.fetch_host_config(
                server_ip=f"{server.ip}:{cam.port}", server_location=server_fab.name
            )

            # 4) Parse
            objects_data: Dict = host_names.get("names", [])
            fences_data: List[Dict] = host_cfg.get("fences", [])
            logics_data: List[Dict] = host_cfg.get("steps", [])
            conditions_data: Dict = host_cfg.get("conditions", [])

            if not objects_data:
                log.warning(
                    "initialize_cam: No objects data found in host configuration."
                )
                raise ValueError("No objects data found in host configuration.")

            # 4a) Objects
            for o in list(objects_data.values()):
                existing = await self.repo.find_object_by_name_unit(o, unit_id)
                if not existing:
                    await self.repo.add_object(Object(name=o, unit_id=unit_id))
                else:
                    log.info(
                        f"Object '{o}' with unit_id {unit_id} already exists. Skipping."
                    )

            # 4a) Fences
            for f in fences_data:
                await self.repo.add_fence(
                    Fence(name=f["name"], drawn_area=f["points"], unit_id=unit_id)
                )

            # 4a) Logics (prepend Cycle Start)
            await self.repo.add_logic(
                Logic(
                    state="Cycle Start",
                    name="Cycle End",
                    mode="release",
                    expression=host_cfg.get("cycleTriggerCondition"),
                    unit_id=unit_id,
                )
            )
            for l in logics_data:
                stm = str(l.get("stateTransitionMode")).lower()
                mode = {
                    "a": "switch",
                    "b": "release",
                    "switch": "switch",
                    "release": "release",
                }.get(stm, "release")
                await self.repo.add_logic(
                    Logic(
                        state=l.get("name"),
                        name=l.get("name"),
                        mode=mode,
                        expression=l.get("condition"),
                        unit_id=unit_id,
                    )
                )

            # 4b) Name maps
            objs = await self.repo.list_objects_by_unit(unit_id)
            fences = await self.repo.list_fences_by_unit(unit_id)
            name2obj_id = {o.name: o.id for o in objs}
            name2fence_id = {f.name: f.id for f in fences}

            # 4c) Conditions
            for key, condition in conditions_data.items():
                if not condition.get("object") and not condition.get("objects"):
                    log.warning(
                        f"initialize_cam: Condition '{key}' 必須包含至少一個 'object' 或 'objects'"
                    )
                    raise ValueError(f"Condition '{key}' 必須包含至少一個 'object' 或 'objects'")

                if (
                    condition.get("type")
                    and condition.get("type") not in ObjectType._value2member_map_
                ):
                    log.info(
                        f"initialize_cam: Condition '{condition.get('type')}' 不存在於系統紀錄中"
                    )
                    raise ValueError(f"Condition '{condition.get('type')}' 不存在於系統紀錄中")

                fence_id = (
                    name2fence_id.get(condition["fence"])
                    if condition.get("fence")
                    else None
                )
                new_condition = await self.repo.add_condition(
                    Condition(
                        name=key,
                        type=condition.get("type"),
                        unit_id=unit_id,
                        fence_id=fence_id,
                    )
                )

                objects = condition.get("objects") or [condition["object"]]
                log.info(
                    f"objects: {condition.get('objects')}, object: {condition.get('object')}"
                )
                for obj_name in objects:
                    object_id = name2obj_id.get(obj_name)
                    if object_id is None:
                        log.info(f"initialize_cam: Object '{obj_name}' 未找到")
                        raise ValueError(f"Object '{obj_name}' 未找到")
                    await self.repo.add_condition_object(
                        ConditionObject(
                            condition_id=new_condition.id, object_id=object_id
                        )
                    )

            # 5) Mark imported for cam
            cam.import_status = True
            await self.repo.flush()

            # 6) Unit import status if all cams imported
            cams_in_unit = await self.repo.list_cams_in_unit(unit_id)
            if cams_in_unit and all(c.import_status for c in cams_in_unit):
                unit.import_status = UnitImportStatus.IMPORTED.value

            # 7) Commit as single app-level transaction
            await self.db.commit()

        except HTTPException:
            log.info(f"initialize_cam: HTTP error for cam {cam_id}")
            raise
        except Exception as exc:
            log.exception(
                f"initialize_cam: Unexpected error initializing cam {cam_id}: {exc}"
            )
            # Best effort rollback to keep tx clean
            await self.db.rollback()
            raise
