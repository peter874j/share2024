from fastapi import HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload
from sqlalchemy import select
from src.database.repositories.cam_repository import CamRepository
from src.api.services.server_service import ServerService
from src.api.services.cam_service import CamService
from src.database.models.server import Server
from src.database.models.fab import Fab
from src.utils.client_requests import ClientRequests
from src.utils.logger import get_logger

logger = get_logger("server.orchestrator")


class ServerOrchestrator:
    def __init__(self, db: AsyncSession):
        self.db = db
        cam_repo = CamRepository(db)
        self.server_service = ServerService(db)
        self.cam_service = CamService(db, cam_repo)

    async def check_client_server_status(self, server_id: int) -> None:
        # Load server with cams and fab
        stmt = (
            select(Server)
            .options(
                selectinload(Server.cams),
                selectinload(Server.fab),
            )
            .where(Server.id == server_id)
        )
        result = await self.db.execute(stmt)
        server: Server = result.scalar_one_or_none()
        if not server:
            logger.warning(f"check_client_server_status: Server {server_id} not found")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Server {server_id} not found",
            )

        try:
            server_fab: Fab = server.fab
            health = await ClientRequests.fetch_host_health(
                server_ip=f"{server.ip}:8000", server_location=server_fab.name
            )
        except Exception as ex:
            logger.warning(
                f"check_client_server_status: Failed to fetch health for server {server.ip}: {ex}"
            )
            # mark offline in one commit
            server.status = False
            self.db.add(server)
            for cam in server.cams:
                cam.status = False
                self.db.add(cam)
            await self.db.commit()
            return

        # Compose updates and commit once
        server.status = True
        self.db.add(server)
        await self.cam_service.update_statuses_from_health(server, health, commit=False)
        await self.db.commit()

    async def initialize_server(self, server_id: int) -> None:
        # Load server with cams and fab
        stmt = (
            select(Server)
            .options(
                selectinload(Server.cams),
                selectinload(Server.fab),
            )
            .where(Server.id == server_id)
        )
        result = await self.db.execute(stmt)
        server = result.scalar_one_or_none()
        if not server:
            logger.info(
                f"initialize_server: Server {server_id} not found. Initialization aborted."
            )
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Server {server_id} not found",
            )

        try:
            server_fab: Fab = server.fab
            server_info = await ClientRequests.fetch_host_health(
                server_ip=f"{server.ip}:8000", server_location=server_fab.name
            )
        except Exception as ex:
            logger.warning(
                f"initialize_server: Failed to fetch settings for server {server.ip}: {ex}"
            )
            # mark offline for server and cams
            server.status = False
            self.db.add(server)
            for cam in server.cams:
                cam.status = False
                self.db.add(cam)
            await self.db.commit()
            return

        if not server_info:
            logger.warning(
                f"initialize_server: Failed to fetch settings for server {server.ip}. Initialization aborted."
            )
            server.status = False
            self.db.add(server)
            for cam in server.cams:
                cam.status = False
                self.db.add(cam)
            await self.db.commit()
            return

        logger.info(
            f"initialize_server: Initializing server: {server.name} ({server.ip}:8000)."
        )
        await self.cam_service.initialize_from_server_info(
            server, server_info, commit=False
        )
        server.status = True
        self.db.add(server)
        await self.db.commit()
