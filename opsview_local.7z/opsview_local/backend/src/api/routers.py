from fastapi import APIRouter

from .routes.minio import minio_router
from .routes.user import user_router
from .routes.fab import fab_router
from .routes.department import department_router
from .routes.stage import stage_router
from .routes.auth import auth_router
from .routes.unit import unit_router
from .routes.object import object_router
from .routes.fence import fence_router
from .routes.condition import condition_router
from .routes.logic import logic_router
from .routes.report import report_router
from .routes.cam import cam_router
from .routes.server import server_router
from .routes.client import client_router

api_router = APIRouter()

api_router.include_router(auth_router, prefix="/auth", tags=["auth"])
api_router.include_router(minio_router, prefix="/minio", tags=["minio"])
api_router.include_router(user_router, prefix="/user", tags=["users"])
api_router.include_router(fab_router, prefix="/fab", tags=["fabs"])
api_router.include_router(department_router, prefix="/department", tags=["departments"])
api_router.include_router(stage_router, prefix="/stage", tags=["stages"])
api_router.include_router(unit_router, prefix="/unit", tags=["units"])
api_router.include_router(object_router, prefix="/object", tags=["objects"])
api_router.include_router(fence_router, prefix="/fences", tags=["fences"])
api_router.include_router(condition_router, prefix="/conditions", tags=["conditions"])
api_router.include_router(logic_router, prefix="/logics", tags=["logics"])
api_router.include_router(report_router, prefix="/reports", tags=["report"])
api_router.include_router(cam_router, prefix="/cams", tags=["cam"])
api_router.include_router(server_router, prefix="/servers", tags=["server"])
api_router.include_router(client_router, prefix="/clients", tags=["client"])
