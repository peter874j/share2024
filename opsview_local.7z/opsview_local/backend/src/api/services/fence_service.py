from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import selectinload

from src.database.models.condition import Condition
from src.database.models.fence import Fence
from src.database.schemas.fence import FenceCreate, FenceUpdate
from src.database.repositories.fence_repository import IFenceRepository
from src.utils.logger import get_logger

logger = get_logger("fence_service")


class FenceService:
    def __init__(self, db: AsyncSession, fence_repo: IFenceRepository):
        self.db = db
        self.fence_repo = fence_repo

    async def get_multi(self, unit_id: Optional[int] = None) -> List[Fence]:
        filters = {"deleted_at": None}
        if unit_id:
            filters["unit_id"] = unit_id

        return await self.fence_repo.get_multi(
            filters=filters,
            eager_options=[
                selectinload(Fence.conditions).selectinload(Condition.condition_objects)
            ],
        )

    async def get_one(self, _id: int) -> Optional[Fence]:
        obj = await self.fence_repo.get_by_id(_id)
        if obj and obj.deleted_at is None:
            return obj
        return None

    async def create(self, data: FenceCreate) -> Fence:
        new_fence = Fence(**data.model_dump())
        try:
            created_fence = await self.fence_repo.add(new_fence)
            await self.db.commit()
            await self.db.refresh(created_fence)
            return created_fence
        except IntegrityError as e:
            await self.db.rollback()
            if "fences_unit_id_fkey" in str(e.orig):
                logger.warning(f"create: unit_id {data.unit_id} 不存在")
                raise ValueError(f"unit_id={data.unit_id} 不存在")
            raise

    async def update(self, _id: int, data: FenceUpdate) -> Optional[Fence]:
        try:
            updated_fence = await self.fence_repo.update(
                _id, data.dict(exclude_unset=True)
            )
            await self.db.commit()
            return updated_fence
        except IntegrityError as e:
            await self.db.rollback()
            if "fences_unit_id_fkey" in str(e.orig):
                logger.warning(f"update: unit_id {data.unit_id} 不存在")
                raise ValueError(f"unit_id={data.unit_id} 不存在")
            raise

    async def remove(self, _id: int) -> bool:
        fence = await self.fence_repo.get_by_id(_id)
        if not fence or fence.deleted_at is not None:
            return False
        await self.fence_repo.delete(_id)
        await self.db.commit()
        return True
