from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import IntegrityError
from src.database.models.logic import Logic
from src.database.schemas.logic import LogicCreate, LogicUpdate
from src.database.repositories.logic_repository import ILogicRepository
from src.utils.logger import get_logger

logger = get_logger("logic_service")


class LogicService:
    def __init__(self, db: AsyncSession, logic_repo: ILogicRepository):
        self.db = db
        self.logic_repo = logic_repo

    async def get_multi(self, unit_id: Optional[int] = None) -> List[Logic]:
        filters = {"deleted_at": None}
        if unit_id:
            filters["unit_id"] = unit_id

        return await self.logic_repo.get_multi(filters=filters)

    async def get_one(self, _id: int) -> Optional[Logic]:
        obj = await self.logic_repo.get_by_id(_id)
        if obj and obj.deleted_at is None:
            return obj
        return None

    async def create(self, data: LogicCreate) -> Logic:
        try:
            new_logic = Logic(**data.model_dump())
            created_logic = await self.logic_repo.add(new_logic)
            await self.db.commit()
            return created_logic
        except IntegrityError as e:
            await self.db.rollback()
            msg = str(e.orig)
            if "logics_unit_id_fkey" in msg:
                logger.warning(f"create: unit_id={data.unit_id} not found")
                raise ValueError(f"unit_id={data.unit_id} not found")
            raise ValueError(msg)

    async def update(self, _id: int, data: LogicUpdate) -> Optional[Logic]:
        try:
            logic = await self.logic_repo.get_by_id(_id)
            if not logic:
                logger.warning(f"update: Logic id {_id} 不存在")
                raise ValueError(f"Logic id {_id} 不存在")

            update_data = data.model_dump(exclude_unset=True)
            updated_logic = await self.logic_repo.update(_id, update_data)
            await self.db.commit()
            return updated_logic
        except IntegrityError as e:
            await self.db.rollback()
            msg = str(e.orig)
            if "logics_unit_id_fkey" in msg:
                logger.warning(f"update: unit_id={data.unit_id} 不存在")
                raise ValueError(f"unit_id={data.unit_id} 不存在")
            raise ValueError(msg)

    async def remove(self, _id: int) -> bool:
        logic = await self.logic_repo.get_by_id(_id)
        if not logic or logic.deleted_at is not None:
            return False
        await self.logic_repo.delete(_id)
        await self.db.commit()
        return True
