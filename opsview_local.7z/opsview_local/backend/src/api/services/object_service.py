from typing import Any, List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from src.database.schemas.object import ObjectCreate, ObjectUpdate
from src.database.models.object import Object
from src.database.repositories.object_repository import IObjectRepository
from src.utils.logger import get_logger

logger = get_logger("object_service")


class ObjectService:
    def __init__(
        self,
        object_repo: IObjectRepository,
        db: AsyncSession,
    ):
        self.db = db
        self.object_repo = object_repo

    async def get_multi(
        self,
        filters: Optional[List[Any]] = None,
        eager_options: List[Any] = [],
    ) -> List[Object]:
        """根據提供的 unit_id 條件，取得所有尚未被標記刪除（deleted_at 為 None）的 Object 資料。若未指定 unit_id，則回傳所有符合條件的 Object 清單。

        Args:
            unit_id (Optional[int], optional): 單位 ID，用於篩選特定單位的 Object 資料。預設為 None。
        """
        # 只撈未被標記刪除的
        filters.append(Object.deleted_at == None)

        return await self.object_repo.get_multi(
            filters=filters, eager_options=eager_options
        )

    async def get_one(self, _id: int) -> Optional[Object]:
        """根據指定的 Object ID 取得對應資料，並確認該資料尚未被標記為刪除（deleted_at 為 None）。若資料不存在或已被刪除則回傳 None。

        Args:
            _id (int): Object 的唯一識別 ID。
        """
        # 只撈未被標記刪除的
        filters = {"deleted_at": None}

        return await self.object_repo.get_by_id_with_filters(
            object_id=_id,
            fields=filters,
            eager_options=[selectinload(Object.condition)],
        )

    async def create(self, data: ObjectCreate) -> Object:
        new_obj = Object(name=data.name, unit_id=data.unit_id)
        created_obj = await self.object_repo.add(new_obj)

        await self.db.commit()
        await self.db.refresh(created_obj)

        return await self.object_repo.get_by_id_with_filters(
            object_id=created_obj.id,
            eager_options=[selectinload(Object.condition)],
        )

    async def update(self, _id: int, data: ObjectUpdate) -> Optional[Object]:
        """根據指定的 Object ID 與更新資料，呼叫基礎控制器的 update 方法，執行部分欄位的更新。更新成功則回傳更新後的 Object 資料，否則回傳 None。

        Args:
            _id (int): 要更新的 Object 的唯一識別 ID。
            data (ObjectUpdate): 包含欲更新欄位的資料物件。
        """
        # 直接呼叫 BaseController.update，支援部分欄位更新
        await self.object_repo.update(object_id=_id, fields=data.model_dump())

        await self.db.commit()

        return await self.object_repo.get_by_id_with_filters(
            object_id=_id,
            eager_options=[selectinload(Object.condition)],
        )
