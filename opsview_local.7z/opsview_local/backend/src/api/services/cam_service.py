from typing import Dict, Optional, List
from fastapi import HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.ext.mutable import MutableList

from src.database.repositories.cam_repository import ICamRepository
from src.database.models.cam import Cam
from src.database.models.unit import Unit
from src.database.models.stage import Stage
from src.database.models.server import Server
from src.database.schemas.cam import CreateCam, UpdateCam, StreamResponse
from src.utils.logger import get_logger

logger = get_logger("cam_service")


class CamService:
    def __init__(self, db: AsyncSession, repo: ICamRepository):
        self.db = db
        self.repo = repo

    # ---------- Queries ----------
    async def get_multi(
        self,
        fab_id: Optional[int] = None,
        stage_id: Optional[int] = None,
        unit_ids: Optional[List[int]] = None,
    ) -> List[Cam]:
        return await self.repo.list_cams(
            fab_id=fab_id, stage_id=stage_id, unit_ids=unit_ids
        )

    async def get_one(self, cam_id: int) -> Cam:
        cam = await self.repo.get_cam_by_id(cam_id)
        if not cam:
            logger.info(f"get_one: Cam {cam_id} not found")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail=f"Cam {cam_id} not found"
            )
        return cam

    async def get_stream_list(
        self,
        fab_id: Optional[int] = None,
        stage_id: Optional[int] = None,
        unit_ids: Optional[List[int]] = None,
    ) -> List[StreamResponse]:
        rows = await self.repo.list_cams_with_unit_name(
            fab_id=fab_id, stage_id=stage_id, unit_ids=unit_ids
        )
        result: List[StreamResponse] = []
        for cam, unit_name in rows:
            result.append(
                StreamResponse(
                    id=cam.id,
                    name=cam.name,
                    stream_pre_uri=cam.stream_pre_uri,
                    stream_det_uri=cam.stream_det_uri,
                    unit_name=unit_name,
                )
            )
        return result

    # ---------- Commands (commit in Service) ----------
    async def create(self, data: CreateCam) -> Cam:
        # 1. 驗證 Stage
        stage: Stage | None = await self.repo.get_stage(data.stage_id)
        if not stage:
            logger.info(f"create: Stage {data.stage_id} not found")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Stage {data.stage_id} not found",
            )

        # 2. 驗證 Unit 所屬 Stage
        unit: Unit | None = await self.repo.get_unit(data.unit_id)
        if not unit or unit.stage_id != data.stage_id:
            logger.warning(
                f"create: Unit {data.unit_id} is not under Stage {data.stage_id}"
            )
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Unit {data.unit_id} is not under Stage {data.stage_id}",
            )

        # 3. 驗證 Server
        server: Server | None = await self.repo.get_server(data.server_id)
        if not server:
            logger.info(f"create: Server {data.server_id} not found")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Server {data.server_id} not found",
            )

        # 4. 建立 Cam
        cam = Cam(
            ip=data.ip,
            port=data.port,
            name=f"{data.ip}:{data.port}",
            status=True,
            stream_pre_uri=f"http://{data.ip}:{data.port}/video_stream/preview",
            stream_det_uri=f"http://{data.ip}:{data.port}/video_stream/frame",
            obj_name_uri=f"{data.ip}:{data.port}",
            config_uri=f"http://{data.ip}:{data.port}/config",
            server_id=data.server_id,
        )
        cam = await self.repo.add_cam(cam)

        # 5. 綁定 UnitCam
        await self.repo.add_unit_cam(cam_id=cam.id, unit_id=unit.id)

        # 6. commit + refresh
        await self.db.commit()
        await self.db.refresh(cam)
        return cam

    async def update(self, cam_id: int, data: UpdateCam) -> Cam:
        cam = await self.repo.get_cam_by_id(cam_id)
        if not cam:
            logger.info(f"update: Cam {cam_id} not found")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail=f"Cam {cam_id} not found"
            )

        if data.stage_id is not None:
            stage = await self.repo.get_stage(data.stage_id)
            if not stage:
                logger.info(f"update: Stage {data.stage_id} not found")
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Stage {data.stage_id} not found",
                )

        if data.unit_id is not None:
            unit = await self.repo.get_unit(data.unit_id)
            if not unit or (data.stage_id and unit.stage_id != data.stage_id):
                logger.warning(
                    f"update: Unit {data.unit_id} not valid"
                    + (f" under Stage {data.stage_id}" if data.stage_id else "")
                )
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=(
                        f"Unit {data.unit_id} not valid"
                        + (f" under Stage {data.stage_id}" if data.stage_id else "")
                    ),
                )

            existing_unit_cam = await self.repo.get_unit_cam_by_unit_id(unit.id)
            if existing_unit_cam and existing_unit_cam.cam_id != cam.id:
                logger.warning(
                    f"update: Unit {unit.id} 已經綁定到 Cam {existing_unit_cam.cam_id}，無法再綁定到其他 Cam。"
                )
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Unit {unit.id} 已經綁定到 Cam {existing_unit_cam.cam_id}，無法再綁定到其他 Cam。",
                )

            link = await self.repo.get_unit_cam_by_cam_id(cam.id)
            if link:
                link.unit_id = unit.id
            else:
                await self.repo.add_unit_cam(cam_id=cam.id, unit_id=unit.id)

        # 更新 IP/Port 及 URI
        ip = data.ip if data.ip is not None else cam.ip
        port = data.port if data.port is not None else cam.port
        if (data.ip is not None) or (data.port is not None):
            cam.ip = ip
            cam.port = port
            cam.name = f"{ip}:{port}"
            cam.stream_pre_uri = f"http://{ip}:{port}/video_stream/preview"
            cam.stream_det_uri = f"http://{ip}:{port}/video_stream/frame"
            cam.obj_name_uri = f"{ip}:{port}"
            cam.config_uri = f"http://{ip}:{port}/config"

        await self.db.commit()
        await self.db.refresh(cam)
        return cam

    async def remove(self, cam_id: int) -> Optional[Cam]:
        cam = await self.repo.get_cam_by_id(cam_id)
        if not cam:
            return None
        await self.repo.delete_unit_cam_by_cam_id(cam_id)
        await self.repo.delete_cam(cam)
        await self.db.commit()
        return cam

    async def update_statuses_from_health(
        self, server: Server, health: List[Dict], commit: bool = True
    ) -> None:
        for cam_obj in server.cams:
            match_info = next(
                (c for c in health if str(c.get("port")) == str(cam_obj.port)), None
            )
            if not match_info:
                logger.warning(
                    f"update_statuses_from_health: can't find match cam: {cam_obj.id}"
                )
                cam_obj.status = False
                self.repo.add(cam_obj)
                continue
            cam_obj.status = match_info.get("available", False)
            self.repo.add(cam_obj)
        if commit:
            await self.db.commit()

    async def initialize_from_server_info(
        self, server: Server, server_info: List[Dict], commit: bool = True
    ) -> None:
        new_cams = []
        for cam in server_info:
            new_cams.append(
                Cam(
                    server_id=server.id,
                    name=f"{server.ip}:{cam['port']}",
                    ip=server.ip,
                    port=str(cam["port"]),
                    status=cam["available"],
                    stream_pre_uri=f"http://{server.ip}:{cam['port']}/video_stream/preview",
                    stream_det_uri=f"http://{server.ip}:{cam['port']}/video_stream/frame",
                    obj_name_uri=f"{server.ip}:{cam['port']}",
                    config_uri=f"http://{server.ip}:{cam['port']}/config",
                    data=MutableList(list(cam.items())),
                )
            )
        await self.repo.add_many(new_cams)
        if commit:
            await self.db.commit()
