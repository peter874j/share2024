from typing import Dict, List, Optional
from sqlalchemy.exc import NoResultFound
from sqlalchemy.ext.asyncio import AsyncSession
from src.database.models.department import Department
from src.database.repositories.fab_repository import IFabRepository
from src.database.repositories.department_repository import IDepartmentRepository
from src.utils.logger import get_logger

logger = get_logger("department_service")


class DepartmentService:
    def __init__(
        self,
        fab_repo: IFabRepository,
        department_repo: IDepartmentRepository,
        db: AsyncSession,
    ):
        self.db = db
        self.fab_repo = fab_repo
        self.department_repo = department_repo

    async def get_multi(
        self, filters: Optional[Dict[str, str]] = {}
    ) -> List[Department]:
        return await self.department_repo.get_multi(filters)

    async def fetch_or_create_department_from_fab(
        self, department_name: str, fab_id: int, commit: bool = True
    ) -> Department:
        """依據提供的部門名稱與工廠 ID，查詢是否已存在該部門。若不存在，則建立新的部門並綁定至指定工廠，最後儲存並回傳建立的部門實體。

        Args:
            department_name (str): 欲查詢或建立的部門名稱。
            fab_id (int): 欲綁定的工廠 ID。
        """
        department = await self.department_repo.get_by_fab_id_and_name(
            fab_id=fab_id, name=department_name
        )
        if department:
            return department

        fab = await self.fab_repo.get_by_id(fab_id=fab_id)
        if not fab:
            logger.warning(
                f"fetch_or_create_department_from_fab: Fab {fab_id} not found"
            )
            raise NoResultFound(f"Fab {fab_id} not found")

        new_dept = Department(name=department_name, fab_id=fab_id)
        created_dept = await self.department_repo.add(new_dept)

        if commit:
            await self.db.commit()
        else:
            await self.db.flush()

        return created_dept
