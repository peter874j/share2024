from typing import Any, List, Optional
from sqlalchemy.exc import NoResultFound
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.repositories.fab_repository import IFabRepository
from src.database.repositories.department_repository import IDepartmentRepository
from src.database.repositories.stage_repository import IStageRepository
from src.database.models.stage import Stage
from src.utils.logger import get_logger

logger = get_logger("stage_service")


class StageService:
    def __init__(
        self,
        fab_repo: IFabRepository,
        department_repo: IDepartmentRepository,
        stage_repo: IStageRepository,
        db: AsyncSession,
    ):
        self.db = db
        self.fab_repo = fab_repo
        self.department_repo = department_repo
        self.stage_repo = stage_repo

    async def get_multi(
        self,
        filters: Optional[List[Any]] = None,
        eager_options: List[Any] = [],
    ) -> List[Stage]:
        return await self.stage_repo.get_multi(
            filters=filters, eager_options=eager_options
        )

    async def fetch_or_create_stage_from_fab_and_department(
        self, stage_name: str, fab_id: int, department_id: int, commit: bool = True
    ) -> Stage:
        """根據輸入的 stage 名稱、fab ID 與 department ID，查詢是否已有對應的 Stage 資料。若已存在則直接回傳，否則建立新 Stage 實體並儲存至資料庫後回傳。

        Args:
            stage_name (str): 站點名稱。
            fab_id (int): 所屬工廠 ID。
            department_id (int): 所屬部門 ID。

        Returns:
            Stage: 查詢或建立後的 Stage 實體。
        """
        stage = await self.stage_repo.get_by_name(stage_name)
        if stage:
            return stage

        fab = await self.fab_repo.get_by_id(fab_id)
        if not fab:
            logger.warning(
                f"fetch_or_create_stage_from_fab_and_department: Fab {fab_id} not found"
            )
            raise NoResultFound(f"Fab {fab_id} not found")

        department = await self.department_repo.get_by_id(department_id)
        if not department:
            logger.warning(
                f"fetch_or_create_stage_from_fab_and_department: Department {department_id} not found"
            )
            raise NoResultFound(f"Department {department_id} not found")

        new_stage = Stage(name=stage_name, fab_id=fab_id, department_id=department_id)
        created_stage = await self.stage_repo.add(new_stage)

        if commit:
            await self.db.commit()
        else:
            await self.db.flush()

        return created_stage
