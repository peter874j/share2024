import httpx
from typing import Any, Dict
from fastapi import HTTPException, status
from src.config.settings import settings
from src.utils.logger import get_logger

logger = get_logger("uac")


class UacService:
    def __init__(self, timeout: float = 5.0):
        self.timeout = timeout
        self.login_url = settings.uac_login_domain

    async def authenticate(self, username: str, password: str) -> Dict[str, Any]:
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(
                    self.login_url, json={"username": username, "password": password}
                )
            data = resp.json()
        except httpx.RequestError as exc:
            logger.error(f"UAC service error: {str(exc)}")
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=f"UAC service error: {str(exc)}",
            )

        if data.get("rtnCode") != "Pass":
            logger.warning(
                f"UAC login failed: {data.get('rtnMessage', 'User is not authorized')}"
            )
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=data.get("rtnMessage", "User is not authorized"),
            )

        return data
