from typing import Optional, List, Tuple, Dict
from sqlalchemy import or_, cast, String
from sqlalchemy.ext.asyncio import AsyncSession
from src.database.schemas.user import UserFilter, UserRole
from src.database.repositories.user_repository import UserRepository
from src.database.models.user import User
from src.utils.logger import get_logger

logger = get_logger("user_service")


class UserService:
    def __init__(self, user_repo: UserRepository, db: AsyncSession):
        self.user_repo = user_repo
        self.db = db

    async def get_one(self, user_id: str) -> Optional[User]:
        return await self.user_repo.get_by_id(user_id)

    async def get_multi(self, filters: Dict[str, str]) -> List[User]:
        return await self.user_repo.get_multi(filters)

    async def get_paginated_multi(
        self,
        form_data: Optional[UserFilter],
        page: int,
        limit: int,
        search: Optional[str],
        sort_field: str,
        sort_order: str,
    ) -> Tuple[List[User], Dict[str, int]]:
        filters = []

        if form_data and form_data.location:
            filters.append(User.location.ilike(f"%{form_data.location}%"))

        if search:
            pattern = f"%{search}%"
            conditions = [
                User.fullname.ilike(pattern),
                User.location.ilike(pattern),
                User.deptno.ilike(pattern),
            ]
            if search.isdigit():
                conditions.append(cast(User.id, String).ilike(pattern))
            filters.append(or_(*conditions))

        return await self.user_repo.get_paginated_multi(
            filters, page, limit, sort_field, sort_order
        )

    async def update_user_role(
        self, user_id: str, new_role: UserRole, commit: bool = True
    ) -> User:
        user = await self.user_repo.update_user_role(user_id, new_role.value)

        if commit:
            await self.db.commit()
        else:
            await self.db.flush()

        return user

    async def add_user(self, user: User, commit: bool = True) -> User:
        new_user = await self.user_repo.add(user)

        if commit:
            await self.db.commit()
        else:
            await self.db.flush()

        return new_user

    async def update_user(
        self, user_id: str, fields: dict, commit: bool = True
    ) -> Optional[User]:
        updated = await self.user_repo.update(user_id, fields)

        if commit:
            await self.db.commit()
        else:
            await self.db.flush()

        return updated
