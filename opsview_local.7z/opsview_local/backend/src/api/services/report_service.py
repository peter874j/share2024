from collections import defaultdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple, Union

from fastapi.encoders import jsonable_encoder
import numpy as np
from dateutil import parser as date_parser
from fastapi import HTTPException, Request, status
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm.attributes import flag_modified

from src.database.models.report_item import ReportItem
from src.database.repositories.report_item_repository import ReportItemRepository
from src.database.schemas.webhook import CameraReportData
from src.config.settings import settings
from src.database.repositories.report_repository import IReportRepository
from src.database.schemas.unit import UnitResponse
from src.database.schemas.report import (
    CombinedData,
    StageAnalysisBoxplotReportResponse,
    StageAnalysisReportResponse,
    StageAnalysisReportResponseList,
    UnitAnalysisCycleDetailResponse,
    UnitAnalysisReportCycleTimeComponent,
    UnitAnalysisReportCycleTimeData,
    UnitAnalysisReportCycleTimeList,
    UnitAnalysisReportIdleTimeComponent,
    UnitAnalysisReportIdleTimeData,
    UnitAnalysisReportIdleTimeList,
    UnitAnalysisReportWorkTimeComponent,
    UnitAnalysisReportWorkTimeData,
    UnitAnalysisReportWorkTimeList,
    UnitAnalysisResponse,
)
from src.database.schemas.report_import import ManualReportData
from src.utils.logger import get_logger

logger = get_logger(__name__)


def _ensure_utc(dt: datetime) -> datetime:
    """確保 datetime 為 UTC 時區"""
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _boxplot_stats(data: List[float]) -> Dict[str, float]:
    """計算 boxplot 統計數據"""
    arr = np.array(data)
    return {
        "Q1": np.percentile(arr, 25),
        "Median": np.percentile(arr, 50),
        "Q3": np.percentile(arr, 75),
        "Min": float(np.min(arr)),
        "Max": float(np.max(arr)),
    }


def _validate_date_range(start_at, end_at, max_days=365):
    # 判斷型別
    if isinstance(start_at, str):
        start_dt = datetime.fromisoformat(start_at)
    elif isinstance(start_at, datetime):
        start_dt = start_at
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid start_at type"
        )

    if isinstance(end_at, str):
        end_dt = datetime.fromisoformat(end_at)
    elif isinstance(end_at, datetime):
        end_dt = end_at
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid end_at type"
        )

    # 業務規則檢查
    if end_dt < start_dt:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="end_at must be after start_at",
        )
    if (end_dt - start_dt).days > max_days:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Date range cannot exceed {max_days} days",
        )

    return start_dt, end_dt


class ReportService:
    def __init__(self, db: AsyncSession, repo: IReportRepository):
        self.db = db
        self.repo = repo
        self.item_repo = ReportItemRepository(db)

    # ---------- Queries (no commit) ----------

    async def get_original_data(
        self,
        start_time: str,
        end_time: str,
        fab_id: Optional[int] = None,
        stage_id: Optional[int] = None,
        unit_ids: Optional[List[int]] = None,
    ):
        try:
            start_dt = _ensure_utc(date_parser.parse(start_time))
            end_dt = _ensure_utc(date_parser.parse(end_time))
        except (ValueError, TypeError):
            logger.warning("get_original_data: 日期格式無效")
            raise HTTPException(400, "日期格式無效")

        _validate_date_range(start_dt, end_dt)

        reports = await self.repo.fetch_reports_between(
            start_dt=start_dt,
            end_dt=end_dt,
            fab_id=fab_id,
            stage_id=stage_id,
            unit_ids=unit_ids,
        )
        if not reports:
            logger.info("get_original_data: 沒有符合篩選條件的報告")
            raise HTTPException(404, "沒有符合篩選條件的報告")

        logger.debug(f"get_original_data: reports : {jsonable_encoder(reports)}")
        return reports

    async def get_stage_analysis_report_data(
        self,
        start_time: str,
        end_time: str,
        fab_id: Optional[int] = None,
        stage_id: Optional[int] = None,
        unit_ids: Optional[List[int]] = None,
    ) -> List[StageAnalysisReportResponseList]:
        try:
            start_dt = _ensure_utc(date_parser.parse(start_time))
            end_dt = _ensure_utc(date_parser.parse(end_time))
        except (ValueError, TypeError):
            logger.warning("get_stage_analysis_report_data: 日期格式無效")
            raise HTTPException(400, "日期格式無效")

        _validate_date_range(start_dt, end_dt)

        rows = await self.repo.fetch_reports_with_unitname_between(
            start_dt=start_dt,
            end_dt=end_dt,
            fab_id=fab_id,
            stage_id=stage_id,
            unit_ids=unit_ids,
        )
        if not rows:
            logger.info("get_stage_analysis_report_data: 沒有符合篩選條件的報告")
            raise HTTPException(404, "沒有符合篩選條件的報告")

        grouped: Dict[str, List[CombinedData]] = defaultdict(list)
        for row in rows:
            unit_name = row["unit_name"]
            for item in row.get("items", []):
                extra = item.get("extra_data") or {}
                grouped[unit_name].append(CombinedData(**extra))

        unit_sums = {
            unit: sum(r.cycle_time for r in recs)
            for unit, recs in grouped.items()
            if recs
        }
        if not unit_sums:
            logger.info("get_stage_analysis_report_data: 沒有符合篩選條件的 cycle_data")
            raise HTTPException(404, "沒有符合篩選條件的 cycle_data")

        global_baseline = sum(unit_sums.values()) / len(unit_sums)

        results: List[StageAnalysisReportResponseList] = []
        for unit_name, recs in grouped.items():
            if not recs:
                continue
            eq_idle = sum(r.eq_idle_time for r in recs)
            op_idle = sum(r.op_idle_time for r in recs)
            work = sum(r.work_time for r in recs)
            boxplot_data = _boxplot_stats([r.cycle_time for r in recs])

            results.append(
                StageAnalysisReportResponseList(
                    unit_name=unit_name,
                    boxplot_worktime_stats=StageAnalysisBoxplotReportResponse(
                        q1=boxplot_data["Q1"],
                        median=boxplot_data["Median"],
                        q3=boxplot_data["Q3"],
                        minimum=boxplot_data["Min"],
                        maximum=boxplot_data["Max"],
                    ),
                    avg_worktime_stats=StageAnalysisReportResponse(
                        eq_idle=eq_idle,
                        op_idle=op_idle,
                        work=work,
                        baseline=global_baseline,
                    ),
                )
            )
        return results

    async def get_unit_analysis_report_data(
        self,
        start_time: str,
        end_time: str,
        fab_id: Optional[int] = None,
        stage_id: Optional[int] = None,
        unit_id: Optional[int] = None,
    ) -> UnitAnalysisResponse:
        try:
            start_dt = _ensure_utc(date_parser.parse(start_time))
            end_dt = _ensure_utc(date_parser.parse(end_time))
        except (ValueError, TypeError):
            logger.warning("get_unit_analysis_report_data: 日期格式無效")
            raise HTTPException(400, "日期格式無效")

        _validate_date_range(start_dt, end_dt)

        rows = await self.repo.fetch_reports_with_unitname_between(
            start_dt=start_dt,
            end_dt=end_dt,
            fab_id=fab_id,
            stage_id=stage_id,
            unit_ids=[unit_id] if unit_id is not None else None,
        )

        if not rows:
            logger.info("get_unit_analysis_report_data: 沒有符合篩選條件的報告")
            raise HTTPException(404, "沒有符合篩選條件的報告")

        records_by_unit: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

        # 全域統計一次完成
        global_work = global_op_idle = global_eq_idle = 0.0
        step_totals: Dict[str, float] = defaultdict(float)
        step_counts: Dict[str, int] = defaultdict(int)

        for row in rows:
            unit_name = row["unit_name"]
            target = records_by_unit[unit_name]
            target_append = target.append

            for it in row.get("items") or []:
                extra = it.get("extra_data") or {}
                steps: Dict[str, Dict[str, Union[float, int]]] = {}

                for k, v in extra.items():
                    if not k.startswith("step_"):
                        continue
                    if k.endswith("_times"):
                        attr, step_name = "times", k[5:-6]
                    elif k.endswith("_counts"):
                        attr, step_name = "counts", k[5:-7]
                    else:
                        continue
                    steps.setdefault(step_name, {"times": 0, "counts": 0})[attr] = v

                work_time = float(extra.get("work_time") or 0)
                op_idle_time = float(extra.get("op_idle_time") or 0)
                eq_idle_time = float(extra.get("eq_idle_time") or 0)
                cycle_time = float(extra.get("cycle_time") or 0)

                # 累計全域統計
                global_work += work_time
                global_op_idle += op_idle_time
                global_eq_idle += eq_idle_time
                for step_name, metrics in steps.items():
                    step_totals[step_name] += float(metrics.get("times", 0) or 0)
                    step_counts[step_name] += int(metrics.get("counts", 0) or 0)

                target_append(
                    {
                        "cycle_start_time": it.get("cycle_start_time"),
                        "work_time": work_time,
                        "op_idle_time": op_idle_time,
                        "eq_idle_time": eq_idle_time,
                        "cycle_time": cycle_time,
                        "steps": steps,
                    }
                )

        if not records_by_unit:
            logger.info("get_unit_analysis_report_data: 時間範圍內無資料")
            raise HTTPException(404, "時間範圍內無資料")

        # 預先綁定類別
        CTD = UnitAnalysisReportCycleTimeData
        WTD = UnitAnalysisReportWorkTimeData
        ITD = UnitAnalysisReportIdleTimeData

        cycle_time_lists: List[UnitAnalysisReportCycleTimeList] = []
        work_time_lists: List[UnitAnalysisReportWorkTimeList] = []
        idle_time_lists: List[UnitAnalysisReportIdleTimeList] = []

        for unit, items in records_by_unit.items():
            n = len(items)
            if not n:
                continue

            # 一次 loop 計三個 sum
            sum_cycle = sum_op_idle = sum_eq_idle = 0.0
            for d in items:
                sum_cycle += d["cycle_time"]
                sum_op_idle += d["op_idle_time"]
                sum_eq_idle += d["eq_idle_time"]

            baseline_local = sum_cycle / n
            op_base = sum_op_idle / n
            eq_base = sum_eq_idle / n
            step_avg = {name: (step_totals[name] / n) for name in step_totals}

            cycle_items = []
            work_items = []
            idle_items = []
            cycle_append, work_append, idle_append = (
                cycle_items.append,
                work_items.append,
                idle_items.append,
            )

            for d in items:
                cst = d["cycle_start_time"]
                cycle_time = d["cycle_time"]
                work_time = d["work_time"]
                op_idle_time = d["op_idle_time"]
                eq_idle_time = d["eq_idle_time"]
                steps = d["steps"]

                denom = cycle_time or 0.0
                work_ratio = (work_time / denom) if denom else 0.0
                op_ratio = (op_idle_time / denom) if denom else 0.0
                eq_ratio = (eq_idle_time / denom) if denom else 0.0

                cycle_append(
                    CTD(
                        Cycle_Start_Time=cst,
                        Work=work_time,
                        OP_Idle=op_idle_time,
                        EQ_Idle=eq_idle_time,
                        Work_Ratio=work_ratio,
                        OP_Idle_Ratio=op_ratio,
                        EQ_Idle_Ratio=eq_ratio,
                        Baseline=baseline_local,
                    )
                )

                wt_kwargs: Dict[str, Any] = {"Cycle_Start_Time": cst}
                for name, metrics in steps.items():
                    t = float(metrics.get("times", 0) or 0)
                    cnt = int(metrics.get("counts", 0) or 0)
                    wt_kwargs[f"Step_{name}_Time"] = t
                    wt_kwargs[f"Step_{name}_Count"] = cnt
                    wt_kwargs[f"Step_{name}_AVG_Time"] = step_avg.get(name, 0.0)
                work_append(WTD(**wt_kwargs))

                idle_append(
                    ITD(
                        Cycle_Start_Time=cst,
                        OP_Idle=op_idle_time,
                        EQ_Idle=eq_idle_time,
                        OP_Base=op_base,
                        EQ_Base=eq_base,
                    )
                )

            cycle_time_lists.append(
                UnitAnalysisReportCycleTimeList(unit_name=unit, data=cycle_items)
            )
            work_time_lists.append(
                UnitAnalysisReportWorkTimeList(unit_name=unit, data=work_items)
            )
            idle_time_lists.append(
                UnitAnalysisReportIdleTimeList(unit_name=unit, data=idle_items)
            )

        return UnitAnalysisResponse(
            cycle_time_component=UnitAnalysisReportCycleTimeComponent(
                Work=global_work,
                OP_Idle=global_op_idle,
                EQ_Idle=global_eq_idle,
            ),
            work_time_component=UnitAnalysisReportWorkTimeComponent(
                **{f"Step_{name}": step_totals.get(name, 0) for name in step_totals}
            ),
            idle_time_component=UnitAnalysisReportIdleTimeComponent(
                OP_Idle=global_op_idle,
                EQ_Idle=global_eq_idle,
            ),
            cycle_time_data_list=cycle_time_lists,
            work_time_data_list=work_time_lists,
            idle_time_data_list=idle_time_lists,
        )

    async def get_unit_analysis_cycle_detail_data(
        self,
        unit_id: int,
        cycle_start_time: str,
        request: Request,
    ) -> UnitAnalysisCycleDetailResponse:
        row = await self.repo.fetch_cycle_detail_row(
            unit_id=unit_id, cycle_start_time=cycle_start_time
        )
        if not row:
            logger.info("get_unit_analysis_cycle_detail_data: 時間範圍內無資料")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Cycle not found"
            )

        report_id = row["id"]
        detail = row["elem"]
        cst = datetime.fromisoformat(
            detail["cycle_start_time"].replace("Z", "+00:00")
        ).astimezone(timezone.utc)

        unit_model = await self.repo.get_unit_with_relations_for_detail(unit_id)
        if not unit_model:
            logger.info("get_unit_analysis_cycle_detail_data: Unit not found")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Unit not found"
            )

        cst = datetime.fromisoformat(detail["cycle_start_time"].replace("Z", "+00:00"))
        unit_resp = UnitResponse.model_validate(unit_model)

        # 影片網址依原邏輯組裝
        video_url = (
            f"{str(request.base_url)}api/minio/video-streaming/{settings.minio_report_video_bucket}/"
            f"{unit_model.unit_cams[0].cam.server.ip}:{unit_model.unit_cams[0].cam.port}/"
            f"{cst.strftime('%Y-%m-%dT%H:%M:%SZ')}"
        )

        return UnitAnalysisCycleDetailResponse(
            id=report_id,
            Cycle_Start_Time=cst,
            Video_Url=video_url,
            Cycle_Time=detail["cycle_time"],
            Work_Time=detail["work_time"],
            OP_Idle_Time=detail["op_idle_time"],
            EQ_Idle_Time=detail["eq_idle_time"],
            WorkId=str(detail.get("workId") or "empty_list"),
            unit=unit_resp,
        )

    # ---------- Commands (commit here) ----------

    async def update_work_id(
        self, report_id: int, new_work_id: str, cycle_start_time: str
    ) -> UnitAnalysisCycleDetailResponse:
        report = await self.repo.get_report_by_id(report_id)
        if not report:
            logger.info("update_work_id: Report not found")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Report not found"
            )

        # 轉 UTC datetime
        norm = (
            cycle_start_time[:-1] + "+00:00"
            if cycle_start_time.endswith("Z")
            else cycle_start_time
        )
        try:
            target_dt = datetime.fromisoformat(norm)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid cycle_start_time format",
            )
        if target_dt.tzinfo is None:
            target_dt = target_dt.replace(tzinfo=timezone.utc)
        else:
            target_dt = target_dt.astimezone(timezone.utc)

        # 找對應的 report_item
        item = await self.item_repo.get_by_report_and_cst(report_id, target_dt)
        if not item:
            logger.info("update_work_id: Cycle not found")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Cycle not found"
            )

        # 更新 scalar 與 JSONB 欄位
        item.work_id = new_work_id
        extra = dict(item.extra_data or {})
        extra["workId"] = new_work_id
        item.extra_data = extra
        flag_modified(item, "extra_data")

        await self.db.flush()
        await self.db.commit()
        await self.db.refresh(item)

        # 組回傳資料（這裡直接用 item 組裝，省去查舊的 report.data）
        unit_model = await self.repo.get_unit_with_relations_basic(item.report.unit_id)
        if not unit_model:
            logger.info("update_work_id: Unit not found")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Unit not found"
            )

        unit_resp = UnitResponse.model_validate(unit_model)

        return UnitAnalysisCycleDetailResponse(
            id=report_id,
            Cycle_Start_Time=item.cycle_start_time.astimezone(timezone.utc),
            Video_Url=extra.get("video_url", ""),
            Cycle_Time=extra.get("cycle_time"),
            Work_Time=extra.get("work_time"),
            OP_Idle_Time=extra.get("op_idle_time"),
            EQ_Idle_Time=extra.get("eq_idle_time"),
            WorkId=new_work_id,
            unit=unit_resp,
        )

    async def create_report(
        self,
        *,
        unit_id: int,
        transformed_list: List[Dict[str, Any]],
        original_data: List[CameraReportData],
        source: str = "webhook",
    ) -> Dict:
        try:
            obj = await self.repo.create(
                unit_id=unit_id,
                data=jsonable_encoder(original_data),
                source=source,
            )

            for transformed_data in transformed_list:
                await self.item_repo.create(
                    ReportItem(
                        cycle_count=transformed_data["cycle_count"],
                        cycle_start_time=transformed_data["cycle_start_time"],
                        work_id=transformed_data["workId"],
                        extra_data=jsonable_encoder(transformed_data),
                        report_id=obj.id,
                    )
                )

            await self.db.commit()
            await self.db.refresh(obj)
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.exception("create_report: db error")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Database error",
            )

    # ---------- Data Transfer (no commit) ----------
    def transform_cycle_data(
        self, report: Union[CameraReportData, ManualReportData]
    ) -> Tuple[Dict[str, Any], List[str]]:
        missing: List[str] = []

        cst_utc = _ensure_utc(report.Cycle_Start_Time)

        rec: Dict[str, Any] = {
            "cycle_count": report.Cycle_Count,
            "cycle_start_time": cst_utc,
            "workId": report.workId,
            "cycle_time": report.Cycle.Time,
            "op_idle_time": report.Cycle.Idle.OP_Idle.Times,
            "op_idle_counts": report.Cycle.Idle.OP_Idle.Counts,
            "eq_idle_time": report.Cycle.Idle.EQ_Idle.Times,
            "eq_idle_counts": report.Cycle.Idle.EQ_Idle.Counts,
            "total_idle_times": report.Cycle.Idle.Total.Times,
            "total_idle_counts": report.Cycle.Idle.Total.Counts,
            "work_time": report.Cycle.Work.Time,
            "avg_step_time": report.Cycle.Work.Avg.Step_Time,
            "max_step_time": report.Cycle.Work.Max.Step_Time,
            "max_step_name": report.Cycle.Work.Max.Step_Name,
            "min_step_time": report.Cycle.Work.Min.Step_Time,
            "min_step_name": report.Cycle.Work.Min.Step_Name,
        }

        excluded = {"Time", "Avg", "Max", "Min"}
        work_dict = report.Cycle.Work.model_dump(exclude_unset=False)
        for attr, detail in work_dict.items():
            if attr in excluded:
                continue
            snake = "".join(f"_{c.lower()}" if c.isupper() else c for c in attr).lstrip(
                "_"
            )
            times_key = f"step_{snake}_times"
            counts_key = f"step_{snake}_counts"

            rec[times_key] = (
                detail.get("Times", None)
                if isinstance(detail, dict)
                else getattr(detail, "Times", None)
            )
            rec[counts_key] = (
                detail.get("Counts", None)
                if isinstance(detail, dict)
                else getattr(detail, "Counts", None)
            )

        rec["avg_cycle_time"] = rec["cycle_time"]

        for k, v in rec.items():
            if v is None:
                missing.append(k)

        return rec, missing
