from typing import List
from fastapi import BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.services.cam_service import CamService
from src.database.repositories.cam_repository import CamRepository
from src.api.orchestrators.cam_orchestrator import CamOrchestrator
from src.database.models.cam import Cam
from src.database.models.condition import Condition
from src.database.models.fab import Fab
from src.database.models.fence import Fence
from src.database.models.logic import Logic
from src.database.models.server import Server
from src.database.models.unit_cam import UnitCam
from src.database.repositories.condition_repository import ConditionRepository
from src.database.repositories.object_repository import ObjectRepository
from src.database.repositories.fence_repository import FenceRepository
from src.database.repositories.logic_repository import LogicRepository
from src.database.repositories.unit_cam_repository import UnitCamRepository
from src.utils.logger import get_logger
from src.utils.client_requests import ClientRequests


logger = get_logger("client_service")


class ClientService:
    def __init__(self, db: AsyncSession):
        self.db = db
        cam_repo = CamRepository(db)
        self.condition_repo = ConditionRepository(db)
        self.object_repo = ObjectRepository(db)
        self.fence_repo = FenceRepository(db)
        self.logic_repo = LogicRepository(db)
        self.unit_cam_repo = UnitCamRepository(db)
        self.cam_orchestrator = CamOrchestrator(db, cam_repo, CamService(db, cam_repo))

    async def clear_unit_configuration(self, unit_id: int) -> None:
        """
        清空指定崗位配置的 Object、Fence、Condition 和 Logic
        """

        try:
            # 清空 ConditionObject 中介表、Condition 表
            await self.condition_repo.delete_by_unit_id(unit_id)

            # 清空 Object
            await self.object_repo.delete_by_unit_id(unit_id)

            # 清空 Fence
            await self.fence_repo.delete_by_unit_id(unit_id)

            # 清空 Logic
            await self.logic_repo.delete_by_unit_id(unit_id)

            await self.db.commit()
            logger.info(f"Successfully cleared configurations for unit_id: {unit_id}")
        except Exception as exc:
            await self.db.rollback()
            logger.exception(
                f"Failed to clear configurations for unit_id: {unit_id}, error: {exc}"
            )

    async def assemble_sync_payload(
        self, background_tasks: BackgroundTasks, unit_id: int
    ) -> None:
        logger = get_logger("assemble_sync_payload")

        # 1. Cams and Servers
        unit_cam: UnitCam = await self.unit_cam_repo.get_with_cam_server_fab(unit_id)
        cam: Cam = unit_cam.cam
        server: Server = cam.server
        server_fab: Fab = server.fab

        # 2. Fences
        fences: List[Fence] = await self.fence_repo.get_by_unit_id(unit_id)
        fences_out = [{"name": f.name, "points": f.drawn_area} for f in fences]

        # 3. Conditions + ConditionObjects
        #   3.1 一次載入所有關聯，避免 N+1
        conds: List[Condition] = await self.condition_repo.get_by_unit_id(unit_id)
        conditions_out = {}
        for c in conds:
            c: Condition
            obj_names = [co.object.name for co in c.condition_objects]
            conditions_out[str(c.name)] = {
                "type": c.type,
                "object": str(obj_names[0]) if len(obj_names) == 1 else None,
                "objects": [str(o) for o in obj_names] if len(obj_names) > 1 else None,
                "fence": str(c.fence_id),
            }

        # 4. Steps (Logic)
        logics: List[Logic] = await self.logic_repo.get_by_unit_id(unit_id)
        steps_out = [
            {
                "name": lg.name,
                "condition": lg.expression,
                "stateTransitionMode": str(lg.mode).capitalize(),
            }
            for lg in logics
        ]

        # 5. Cycle Trigger
        cycle_trigger = await self.logic_repo.get_one(
            [Logic.unit_id == unit_id, Logic.state == "Cycle Start"]
        )

        # 6. 組裝並發送給 Client
        try:
            await ClientRequests.update_host_config(
                server_ip=f"{server.ip}:{cam.port}",
                server_location=server_fab.name,
                config_data={
                    "fences": fences_out,
                    "conditions": conditions_out,
                    "steps": steps_out,
                    "cycleTriggerCondition": cycle_trigger.expression
                    if cycle_trigger
                    else "",
                },
            )
        except Exception as exc:
            logger.exception(f"Unexpected error updating Client config: {exc}")

            # 清空該崗位配置的 Object、Fence、Condition、Logic
            await self.clear_unit_configuration(unit_id=unit_id)

            # 重新初始化該崗位
            background_tasks.add_task(self.cam_orchestrator.initialize_cam, cam.id)
