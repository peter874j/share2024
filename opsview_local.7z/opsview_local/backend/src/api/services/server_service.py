from typing import List, Optional, Literal, Tuple
from fastapi import HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from src.database.models.server import Server
from src.database.repositories.server_repository import ServerRepository
from src.database.repositories.cam_repository import CamRepository
from src.database.schemas.server import (
    CreateServer,
    UpdateServer,
    ServerResponse,
    ServerList,
)

from src.utils.logger import get_logger

logger = get_logger("server.service")


class ServerService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.servers = ServerRepository(db)
        self.cams = CamRepository(db)

    async def create_server(self, data: CreateServer) -> ServerResponse:
        srv = Server(**data.model_dump())
        await self.servers.add(srv)
        await self.db.commit()
        # reload with cams
        loaded = await self.servers.get_by_id(srv.id, with_relations=True)
        return ServerResponse.model_validate(loaded)

    async def list_servers(self) -> List[ServerResponse]:
        items = await self.servers.list_all()
        return [ServerResponse.model_validate(s) for s in items]

    async def get_server_with_relations(self, server_id: int) -> ServerResponse:
        server = await self.servers.get_by_id(server_id, full_relations=True)
        if not server:
            logger.info(f"get: Server {server_id} not found")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Server {server_id} not found",
            )
        return ServerResponse.model_validate(server)

    async def update_server(self, server_id: int, data: UpdateServer) -> ServerResponse:
        srv = await self.servers.get_by_id(server_id)
        if not srv:
            logger.info(f"update: Server {server_id} not found")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Server {server_id} not found",
            )
        updates = data.model_dump(exclude_unset=True)
        await self.servers.update_partial(srv, updates)
        await self.db.commit()
        reloaded = await self.servers.get_by_id(server_id, full_relations=True)
        return ServerResponse.model_validate(reloaded)

    async def delete_server(self, server_id: int) -> None:
        srv = await self.servers.get_by_id(server_id)
        if not srv:
            logger.info(f"remove: Server {server_id} not found")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Server {server_id} not found",
            )
        await self.servers.delete(srv)
        await self.db.commit()

    async def get_paginated_servers(
        self,
        form_data: Optional[ServerList],
        page: int,
        limit: int,
        sort_field: str,
        sort_order: Literal["asc", "desc"],
    ) -> Tuple[List[Server], dict]:
        filters = []
        if form_data and getattr(form_data, "fab_id", None) is not None:
            from src.database.models.server import Server as S

            filters.append(S.fab_id == form_data.fab_id)
        return await self.servers.get_paginated(
            filters, page, limit, sort_field, sort_order
        )

    async def list_filtered_servers(
        self, form_data: Optional[ServerList] = None
    ) -> List[Server]:
        filters = []
        if form_data and getattr(form_data, "fab_id", None) is not None:
            from src.database.models.server import Server as S

            filters.append(S.fab_id == form_data.fab_id)
        return await self.servers.list_filtered_with_relations(filters)

    async def set_server_and_cams_offline(self, server_id: int) -> None:
        server = await self.servers.get_by_id(server_id, with_relations=True)
        if not server:
            logger.info(f"offline: Server {server_id} not found")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Server {server_id} not found",
            )
        server.status = False
        self.db.add(server)
        await self.cams.bulk_set_status_by_server(server, False)
        await self.db.commit()
