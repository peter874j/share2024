from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import selectinload

from src.database.models.condition import Condition
from src.database.models.condition_object import ConditionObject
from src.database.schemas.condition import ConditionCreate, ConditionUpdate, ObjectType
from src.database.repositories.condition_repository import IConditionRepository
from src.utils.logger import get_logger

logger = get_logger("condition_service")


class ConditionService:
    def __init__(self, db: AsyncSession, condition_repo: IConditionRepository):
        self.db = db
        self.condition_repo = condition_repo

    def _prepare_condition_data(self, data: ConditionCreate) -> dict:
        if isinstance(data, dict):
            object_ids = data.get("object_ids") or []
            fence_id = data.get("fence_id")
        else:
            object_ids = data.object_ids or []
            fence_id = data.fence_id

        object_count = len(object_ids)
        data_dict = (
            data if isinstance(data, dict) else data.model_dump(exclude={"object_ids"})
        )

        if object_count == 1:
            data_dict["type"] = ObjectType.in_fence if fence_id else ObjectType.exists
        elif object_count > 1:
            data_dict["type"] = (
                ObjectType.overlap_in_fence if fence_id else ObjectType.overlap
            )
        else:
            logger.warning(f"_prepare_condition_data: 物件數量必須至少為 1。")
            raise ValueError("物件數量必須至少為 1。")
        return data_dict

    async def get_multi(self, unit_id: Optional[int] = None) -> List[Condition]:
        filters = {"deleted_at": None}
        if unit_id:
            filters["unit_id"] = unit_id

        return await self.condition_repo.get_multi(
            filters=filters,
            eager_options=[selectinload(Condition.objects)],
        )

    async def get_one(self, _id: int) -> Optional[Condition]:
        obj = await self.condition_repo.get_one(
            _id, eager_options=[selectinload(Condition.objects)]
        )
        if obj and obj.deleted_at is None:
            return obj
        return None

    async def create(self, data: ConditionCreate) -> Condition:
        if not data.object_ids or len(data.object_ids) < 1:
            logger.warning(f"create: 必須至少指定一個物件。object_ids: {data.object_ids}")
            raise ValueError("必須至少指定一個物件。")
        if len(data.object_ids) > 1 and data.fence_id is not None:
            logger.warning(
                f"create: 當指定多於一個物件時，fence_id 必須為空。object_ids: {data.object_ids}"
            )
            raise ValueError("當指定多於一個物件時，fence_id 必須為空。")

        object_ids = data.object_ids
        data_dict = self._prepare_condition_data(data)

        try:
            new_condition = Condition(**data_dict)
            created_condition = await self.condition_repo.add(new_condition)

            # 處理 object_ids
            condition_objects = [
                ConditionObject(condition_id=created_condition.id, object_id=obj_id)
                for obj_id in object_ids
            ]
            await self.condition_repo.bulk_add(condition_objects)

            await self.db.commit()
            return created_condition
        except IntegrityError as e:
            await self.db.rollback()
            msg = str(e.orig)
            if "conditions_unit_id_fkey" in msg:
                logger.warning(f"create: unit_id={data.unit_id} not found")
                raise ValueError(f"unit_id={data.unit_id} not found")
            if "conditions_fence_id_fkey" in msg:
                logger.warning(f"create: fence_id={data.fence_id} not found")
                raise ValueError(f"fence_id={data.fence_id} not found")
            raise ValueError(msg)

    async def update(self, _id: int, data: ConditionUpdate) -> Optional[Condition]:
        try:
            condition = await self.condition_repo.get_one(
                _id, eager_options=[selectinload(Condition.objects)]
            )
            if not condition:
                logger.warning(f"update: Condition id {_id} 不存在")
                raise ValueError(f"Condition id {_id} 不存在")

            # 處理 object_ids
            if data.object_ids is not None:
                rows = await self.condition_repo.validate_object_ids(data.object_ids)
                existing_obj_ids = {r[0] for r in rows}
                invalid = set(data.object_ids) - existing_obj_ids
                if invalid:
                    logger.warning(f"update: 無效的 Object IDs: {sorted(invalid)}")
                    raise ValueError(f"無效的 Object IDs: {sorted(invalid)}")

                current_ids = {obj.id for obj in condition.objects}
                to_add = set(data.object_ids) - current_ids
                to_remove = current_ids - set(data.object_ids)

                await self.condition_repo.update_condition_objects(
                    _id, to_add, to_remove
                )

            update_data = data.model_dump(exclude_unset=True)
            data_dict = self._prepare_condition_data(update_data)
            data_dict.pop("object_ids", None)  # 最後避免寫入非資料表欄位

            updated_condition = await self.condition_repo.update(_id, data_dict)
            await self.db.commit()

            return await self.condition_repo.get_one(
                _id, eager_options=[selectinload(Condition.objects)]
            )
        except IntegrityError as e:
            await self.db.rollback()
            msg = str(e.orig).lower()
            if "conditions_unit_id_fkey" in msg:
                logger.warning(f"update: unit_id={data.unit_id} 不存在")
                raise ValueError(f"unit_id={data.unit_id} 不存在")
            if "conditions_fence_id_fkey" in msg:
                logger.warning(f"update: fence_id={data.fence_id} 不存在")
                raise ValueError(f"fence_id={data.fence_id} 不存在")
            logger.warning(f"update: {msg}")
            raise ValueError(msg)

    async def remove(self, _id: int) -> bool:
        condition = await self.condition_repo.get_by_id(_id)
        if not condition or condition.deleted_at is not None:
            return False
        await self.condition_repo.delete(_id)
        await self.db.commit()
        return True
