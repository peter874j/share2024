from typing import Any, Mapping, Optional, List, Sequence, Tuple, Dict
from sqlalchemy import or_, cast, String
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import NoResultFound

from src.database.repositories.stage_repository import IStageRepository
from src.database.repositories.unit_repository import IUnitRepository
from src.database.models.fab import Fab
from src.database.models.stage import Stage
from src.database.models.department import Department
from src.database.models.unit import Unit
from src.utils.logger import get_logger
from src.utils.exceptions import (
    UnitAlreadyExistsError,
    UnitGetByServerCamError,
    UnitNotFound,
)

logger = get_logger("unit_service")


class UnitService:
    def __init__(
        self, stage_repo: IStageRepository, unit_repo: IUnitRepository, db: AsyncSession
    ):
        self.stage_repo = stage_repo
        self.unit_repo = unit_repo
        self.db = db

    async def get_by_id(self, unit_id: int) -> Optional[Unit]:
        return await self.unit_repo.get_by_id(unit_id)

    async def get_by_id_with_filters(
        self,
        unit_id: int,
        fields: Optional[Mapping[str, Any]] = None,
        eager_options: List[Any] = [],
    ) -> Optional[Unit]:
        return await self.unit_repo.get_by_id_with_filters(
            unit_id=unit_id, fields=fields, eager_options=eager_options
        )

    async def get_multi(
        self,
        filters: Dict[str, str],
        eager_options: List[Any] = [],
    ) -> List[Unit]:
        return await self.unit_repo.get_multi(
            filters=filters, eager_options=eager_options
        )

    async def get_paginated_multi(
        self,
        page: int,
        limit: int,
        search: Optional[str],
        sort_field: str,
        sort_order: str,
    ) -> Tuple[List[Unit], Dict[str, int]]:
        filters = []

        if search:
            pattern = f"%{search}%"
            conditions = [
                Unit.name.ilike(pattern),
                Unit.stage.has(Stage.name.ilike(pattern)),
                Unit.stage.has(Stage.fab.has(Fab.name.ilike(pattern))),
                Unit.stage.has(Stage.department.has(Department.name.ilike(pattern))),
            ]
            if search.isdigit():
                conditions.append(cast(Unit.id, String).ilike(pattern))
            filters.append(or_(*conditions))

        return await self.unit_repo.get_paginated_multi(
            filters, page, limit, sort_field, sort_order
        )

    async def create_unit_from_stage(
        self, unit_name: str, stage_id: int, commit: bool = True
    ) -> Unit:
        """根據提供的 unit_name 與 stage_id，建立新的 Unit 實體。若該 Stage 不存在或該名稱的 Unit 已在該 Stage 中存在，則回傳錯誤；否則建立 Unit 並儲存至資料庫。

        Args:
            unit_name (str): 欲建立的 Unit 名稱。
            stage_id (int): 所屬的 Stage ID。

        Returns:
            Unit: 建立完成的 Unit 實體。
        """
        unit = await self.unit_repo.get_by_name(unit_name)
        stage = await self.stage_repo.get_by_id(stage_id)
        if not stage:
            logger.warning(f"create_unit_from_stage: Stage {stage_id} does not exist.")
            raise NoResultFound(f"Stage {stage_id} does not exist.")

        if unit:
            exist_unit = await self.unit_repo.get_by_id_with_filters(
                unit_id=unit.id, fields={"stage_id": stage_id}
            )
            if exist_unit:
                logger.warning(f"create_unit_from_stage: 崗位 {unit_name} 已存在。")
                raise UnitAlreadyExistsError()

        unit = Unit(name=unit_name, stage_id=stage_id)
        new_unit = await self.unit_repo.add(unit)

        if commit:
            await self.db.commit()
        else:
            await self.db.flush()

        return new_unit

    async def add_unit(self, unit: Unit, commit: bool = True) -> Unit:
        new_unit = await self.unit_repo.add(unit)

        if commit:
            await self.db.commit()
        else:
            await self.db.flush()

        return new_unit

    async def update_unit(
        self, unit_id: int, name: str, stage_id: int, commit: bool = True
    ) -> Optional[Unit]:
        fields = {"name": name, "stage_id": stage_id}

        duplicate_exists = await self.unit_repo.exists_by_name_and_stage_excluding_id(
            name=name, stage_id=stage_id, exclude_unit_id=unit_id
        )
        if duplicate_exists:
            logger.warning(f"update_unit: 崗位 {name} 已存在。")
            raise UnitAlreadyExistsError()

        updated = await self.unit_repo.update(unit_id, fields)

        if commit:
            await self.db.commit()
        else:
            await self.db.flush()

        return updated

    async def delete_unit_by_id(self, unit_id: int) -> bool:
        """根據指定的 unit_id，嘗試刪除對應的 Unit 實體。若資料不存在則回傳 False；若成功刪除則回傳 True。

        Args:
            unit_id (int): 欲刪除的 Unit 的唯一識別 ID。

        Returns:
            bool: 刪除成功回傳 True，若找不到對應 Unit 則回傳 False。
        """
        result = await self.unit_repo.delete(unit_id=unit_id)
        await self.db.commit()
        return result

    async def get_server_status(self, unit_id: int) -> bool:
        """
        若所有關聯 Cam 與 Server 狀態皆為線上回傳 True；
        存在任一離線或沒有任何鏡頭則回傳 False。
        """
        rows = await self.unit_repo.get_cam_server_status_by_unit(unit_id)

        if not rows:
            return False

        for cam_online, server_online in rows:
            if not cam_online or not server_online:
                return False

        return True

    async def get_server_status_bulk(self, unit_ids: Sequence[int]) -> Dict[int, bool]:
        return await self.unit_repo.get_server_status_bulk(unit_ids)

    async def resolve_unit(self, *, server_ip: str, cam_ip: str, cam_port: int):
        try:
            unit = await self.unit_repo.get_by_server_cam(
                server_ip=server_ip, cam_ip=cam_ip, cam_port=cam_port
            )
        except Exception as e:
            logger.exception(f"resolve_unit: repository error, detail: {str(e)}")
            raise UnitGetByServerCamError()
        if unit is None:
            logger.info(
                f"resolve_unit: No unit was found for the specified stage. Please verify the unit information."
            )
            raise UnitNotFound()
        return unit
