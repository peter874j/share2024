from decimal import ROUND_HALF_UP, Decimal
from typing import Dict, List, Optional
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.schemas.unit import FabImportRateResponse
from src.database.models.fab import Fab
from src.database.repositories.fab_repository import IFabRepository
from src.utils.logger import get_logger

logger = get_logger("fab_service")


class FabService:
    def __init__(self, fab_repo: IFabRepository, db: AsyncSession):
        self.db = db
        self.fab_repo = fab_repo

    async def get_multi(self, filters: Optional[Dict[str, str]] = {}) -> List[Fab]:
        return await self.fab_repo.get_multi(filters)

    async def fetch_or_create_fab(self, fab_name: str, commit: bool = True) -> Fab:
        """根據提供的工廠名稱，查詢是否已有對應的工廠資料。若無，則建立新的工廠實體並儲存至資料庫，最後回傳查詢或建立的工廠資料。

        Args:
            fab_name (str): 欲查詢或建立的工廠名稱。
        """
        # 查
        fab = await self.fab_repo.get_by_name(fab_name)
        if fab:
            return fab

        # 建
        new_fab = Fab(name=fab_name)
        created_fab = await self.fab_repo.add(new_fab)

        if commit:
            await self.db.commit()
        else:
            await self.db.flush()

        return created_fab

    async def get_fab_import_rate(self) -> List[FabImportRateResponse]:
        """
        統計每個 Fab 的匯入率（由 repository 提供聚合結果，這裡僅負責計算與輸出組裝）
        """
        rows = await self.fab_repo.get_fab_import_stats()

        stats: List[FabImportRateResponse] = []
        for row in rows:
            rate = (
                Decimal(row.imported_units) / Decimal(row.total_units)
                if row.total_units
                else Decimal(0)
            ).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

            stats.append(
                FabImportRateResponse(
                    fab_name=row.fab_name,
                    total_units=row.total_units,
                    imported_units=row.imported_units,
                    import_rate=float(rate),
                )
            )

        return stats
