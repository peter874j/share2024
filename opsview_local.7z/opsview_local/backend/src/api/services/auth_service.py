import secrets
from typing import Optional
from fastapi import HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.schemas.auth import (
    AuthLoginRequest,
    AuthTokenResponse,
    RefreshTokenRequest,
)
from src.database.models.user import User
from src.database.repositories.user_repository import IUserRepository
from src.api.services.uac_service import UacService
from src.utils.security import SecurityUtils
from src.config.settings import settings
from src.utils.logger import get_logger

logger = get_logger(__name__)


class AuthService:
    def __init__(
        self, user_repo: IUserRepository, uac_service: UacService, db: AsyncSession
    ):
        self.db = db
        self.user_repo = user_repo
        self.uac_service = uac_service

    async def login(self, payload: AuthLoginRequest) -> AuthTokenResponse:
        user = await self._get_or_create_user(payload.username, payload.password)
        return self._generate_token_response(user)

    async def refresh(self, payload: RefreshTokenRequest) -> AuthTokenResponse:
        decoded = SecurityUtils.decode_token(payload.refresh_token)
        if decoded.get("token_type") != "refresh":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token type"
            )

        email = decoded.get("sub")
        if not email:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Missing subject in token",
            )

        user = await self.user_repo.get_by_email(email)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found"
            )

        return self._generate_token_response(user)

    async def _get_or_create_user(
        self, username: str, password: Optional[str], commit: bool = True
    ) -> User:
        existing_user: Optional[User] = await self.user_repo.get_by_username(
            username.lower()
        )

        # 超級管理員快速通道（僅 debug 且帳密符合）
        if existing_user and await self._is_super_admin_login(
            existing_user.email, password
        ):
            return existing_user

        # 已存在 → 與 UAC 同步必要欄位
        if existing_user:
            uac = await self.uac_service.authenticate(username, password)
            sync_fields = {
                "email": uac["email"],
                "username": uac["alias"],
                "fullname": uac["name"],
                "deptno": uac["deptno"],
                "location": uac["location"],
                "token": uac.get("authkey"),
            }
            changed_fields = {}
            for k, v in sync_fields.items():
                if v is None:
                    continue
                if getattr(existing_user, k) != v:
                    changed_fields[k] = v
            if not changed_fields:
                return existing_user
            try:
                logger.debug(
                    "AuthService.update_user: user_id=%s, keys=%s, type=%s",
                    existing_user.id,
                    list(changed_fields.keys()),
                    type(changed_fields).__name__,
                )
            except Exception:
                pass
            return await self.user_repo.update(existing_user.id, changed_fields)

        # 不存在 → 建立新帳號
        uac = await self.uac_service.authenticate(username, password)
        new_user = User(
            id=uac["userid"],
            email=uac["email"],
            username=uac["alias"],
            fullname=uac["name"],
            deptno=uac["deptno"],
            location=uac["location"],
            token=uac.get("authkey"),
            role="user",
        )
        created_user = await self.user_repo.add(new_user)

        if commit:
            await self.db.commit()
        else:
            await self.db.flush()

        return created_user

    async def _is_super_admin_login(self, email: str, plain_pw: Optional[str]) -> bool:
        if (
            email != settings.super_admin_email
            or not settings.app_debug
            or plain_pw is None
        ):
            return False
        # 先驗證密碼 hash，再常數時間比較 email，降低時序側信道
        return SecurityUtils.verify_password(
            plain_pw, settings.super_admin_pw_hash
        ) and secrets.compare_digest(email, settings.super_admin_email)

    def _generate_token_response(self, user: User) -> AuthTokenResponse:
        access_data = SecurityUtils.create_token(
            data={"sub": user.email},
            expires_in=settings.access_token_expire_seconds,
            token_type="access",
        )
        refresh_data = SecurityUtils.create_token(
            data={"sub": user.email},
            expires_in=settings.refresh_token_expire_seconds,
            token_type="refresh",
        )
        return AuthTokenResponse(
            access_token=access_data["token"],
            refresh_token=refresh_data["token"],
            token_type="bearer",
            expire_in=access_data["expire_in"],
        )
