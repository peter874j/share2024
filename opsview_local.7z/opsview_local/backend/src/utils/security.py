import hmac
import hashlib
from datetime import datetime, timedelta, timezone
from typing import Dict
from uuid import uuid4
from jose import ExpiredSignatureError, JWTError, jwt
from passlib.context import CryptContext

from src.config.settings import settings
from src.utils.exceptions import TokenExpiredError, TokenInvalidError

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


class SecurityUtils:
    @staticmethod
    def create_token(data: Dict, expires_in: int, token_type: str) -> Dict:
        now = datetime.now(timezone.utc)
        expire = now + timedelta(seconds=expires_in)
        jti = str(uuid4())

        payload = {
            **data,
            "exp": expire,
            "iat": now,
            "jti": jti,
            "token_type": token_type,
        }

        encoded = jwt.encode(
            payload, settings.jwt_secret_key, algorithm=settings.algorithm
        )
        return {"token": encoded, "expire_in": int((expire - now).total_seconds())}

    @staticmethod
    def decode_token(token: str) -> Dict:
        try:
            return jwt.decode(
                token, settings.jwt_secret_key, algorithms=[settings.algorithm]
            )
        except ExpiredSignatureError as e:
            raise TokenExpiredError() from e
        except JWTError as e:
            raise TokenInvalidError() from e

    @staticmethod
    def verify_password(plain: str, hashed: str) -> bool:
        return pwd_context.verify(plain, hashed)

    @staticmethod
    def hash_password(plain: str) -> str:
        return pwd_context.hash(plain)

    @staticmethod
    def verify_hmac_sha256(secret_key: str, body: bytes, signature: str) -> None:
        expected = hmac.new(secret_key.encode(), body, hashlib.sha256).hexdigest()
        # 使用 compare_digest 避免時序攻擊
        if not hmac.compare_digest(signature, expected):
            raise ValueError("Invalid signature")

    @classmethod
    def generate_and_verify_token(
        cls, data: Dict, expires_in: int, token_type: str
    ) -> Dict:
        token_info = cls.create_token(data, expires_in, token_type)
        decoded = cls.decode_token(token_info["token"])
        return {"token_info": token_info, "decoded": decoded}
