from __future__ import annotations

from math import ceil
from typing import (
    Any,
    Iterable,
    List,
    Optional,
    Sequence,
    Tuple,
    Type,
    TypedDict,
    Union,
)

from sqlalchemy import Select, func, inspect, select
from sqlalchemy.engine import Result
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import DeclarativeMeta, InstrumentedAttribute
from sqlalchemy.sql import ColumnElement


class PaginationMeta(TypedDict):
    page: int
    limit: int
    total: int
    total_pages: int
    sort_field: str
    sort_order: str


DEFAULT_PAGE: int = 1
DEFAULT_LIMIT: int = 10
MAX_LIMIT: int = 200


def _get_pk_columns(
    model: Type[DeclarativeMeta],
) -> Sequence[Union[InstrumentedAttribute, ColumnElement[Any]]]:
    """
    解析 SQLAlchemy 模型的主鍵欄位，回傳可用於排序與去重的欄位表達式序列。

    說明
    - 從 mapper.primary_key 取得主鍵欄位，並盡可能解析回模型上的 InstrumentedAttribute，
      避免僅有匿名 Column 導致後續 order_by / distinct / join 無法正確推斷來源表。
    - 若模型未定義主鍵，會拋出 ValueError。

    參數
    - model: SQLAlchemy Declarative 模型類別

    回傳
    - Sequence[InstrumentedAttribute | ColumnElement]: 主鍵欄位序列（支援複合主鍵）
    """
    mapper = inspect(model)
    pk_cols = list(mapper.primary_key)
    if not pk_cols:
        raise ValueError(f"模型缺少主鍵定義：{model.__name__}")
    resolved: List[Union[InstrumentedAttribute, ColumnElement[Any]]] = []
    for c in pk_cols:
        key = getattr(c, "key", None)
        attr = getattr(model, key, None) if key else None
        resolved.append(attr or c)
    return tuple(resolved)


def _resolve_sorting(
    model: Type[DeclarativeMeta],
    sort_field: str,
    sort_order: str,
) -> Tuple[ColumnElement[Any], Sequence[InstrumentedAttribute], bool]:
    """
    解析排序設定，支援以點號路徑表示的關聯欄位排序。

    範例
    - "name": 以主表的 name 欄位排序
    - "department.name": join department 後以其 name 欄位排序

    規則
    - sort_order 僅支援 'asc' 或 'desc'
    - 若 sort_field 指向關聯，會回傳需要進行 join 的關聯屬性序列
    - 會檢查目標欄位是否存在於對應模型的 __table__.columns

    參數
    - model: 根模型類別
    - sort_field: 欄位或關聯欄位路徑（以點號分隔）
    - sort_order: 排序方向，'asc' 或 'desc'

    回傳
    - Tuple[ColumnElement, Sequence[InstrumentedAttribute], bool]:
      (排序欄位表達式、需要 join 的關聯屬性序列、是否包含關聯)
    """
    if not sort_field:
        raise ValueError("排序欄位不得為空")

    order = (sort_order or "asc").lower()
    if order not in ("asc", "desc"):
        raise ValueError("sort_order 僅支援 'asc' 或 'desc'")

    parts = [p for p in sort_field.split(".") if p]
    if not parts:
        raise ValueError(f"無效的排序欄位：{sort_field}")

    parent = model
    join_rels: List[InstrumentedAttribute] = []

    if len(parts) > 1:
        for rel_name in parts[:-1]:
            if not hasattr(parent, rel_name):
                raise ValueError(f"關聯不存在：{rel_name}")
            rel_attr = getattr(parent, rel_name)
            if not isinstance(rel_attr, InstrumentedAttribute) or not hasattr(
                rel_attr, "property"
            ):
                raise ValueError(f"非關聯屬性：{rel_name}")
            join_rels.append(rel_attr)
            parent = rel_attr.property.mapper.class_

    col_name = parts[-1]
    # type: ignore[attr-defined]
    if col_name not in parent.__table__.columns:
        raise ValueError(f"無效的排序欄位：{sort_field}")
    sort_col: ColumnElement[Any] = getattr(parent, col_name)
    sort_col = sort_col.desc() if order == "desc" else sort_col.asc()

    return sort_col, tuple(join_rels), len(join_rels) > 0


async def paginate(
    db: AsyncSession,
    model: Type[DeclarativeMeta],
    filters: Sequence[Any],
    page: int,
    limit: int,
    sort_field: str,
    sort_order: str,
    eager_options: Optional[Iterable[Any]] = None,
) -> Tuple[List[Any], PaginationMeta]:
    """
    通用分頁查詢：
    - 支援主表與關聯欄位排序（以點號路徑表示，如 "relation.field"）
    - 對 count 採雙查詢策略，避免 window function 在 join 場景的昂貴代價與重複計數
    - 使用主鍵作為 tie-breaker，確保穩定排序避免翻頁閃動

    回傳:
    - items: 查詢結果的 ORM 實例列表
    - meta: 依 PaginationMeta 定義的分頁資訊
    """
    if page is None or page < 1:
        page = DEFAULT_PAGE
    if limit is None or limit < 1:
        limit = DEFAULT_LIMIT
    if limit > MAX_LIMIT:
        limit = MAX_LIMIT

    offset = (page - 1) * limit
    eager_options = tuple(eager_options or ())

    sort_col, join_rels, has_joins = _resolve_sorting(model, sort_field, sort_order)

    stmt: Select[Any] = select(model).where(*filters).options(*eager_options)
    for rel in join_rels:
        stmt = stmt.join(rel)

    pk_cols = _get_pk_columns(model)
    order_cols: List[ColumnElement[Any]] = [sort_col]
    is_desc = str(sort_col).endswith(" DESC")
    for pk in pk_cols:
        order_cols.append(pk.desc() if is_desc else pk.asc())  # type: ignore[call-arg]

    stmt = stmt.order_by(*order_cols).offset(offset).limit(limit)

    result: Result[Any] = await db.execute(stmt)
    items = result.scalars().all()

    if len(pk_cols) == 1:
        pk = pk_cols[0]
        if has_joins:
            count_stmt = (
                select(func.count(func.distinct(pk))).select_from(model).where(*filters)
            )
            for rel in join_rels:
                count_stmt = count_stmt.join(rel)
        else:
            count_stmt = select(func.count()).select_from(model).where(*filters)
    else:
        if has_joins:
            base = select(*pk_cols).select_from(model).where(*filters)
            for rel in join_rels:
                base = base.join(rel)
            sub = base.distinct().subquery()
            count_stmt = select(func.count()).select_from(sub)
        else:
            sub = (
                select(*pk_cols)
                .select_from(model)
                .where(*filters)
                .distinct()
                .subquery()
            )
            count_stmt = select(func.count()).select_from(sub)

    total = (await db.execute(count_stmt)).scalar_one() or 0

    meta: PaginationMeta = {
        "page": page,
        "limit": limit,
        "total": int(total),
        "total_pages": int(ceil(total / limit)) if total else 0,
        "sort_field": sort_field,
        "sort_order": (sort_order or "asc").lower(),
    }
    return items, meta
