from typing import Callable, Any, Dict
from functools import wraps
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import ExpiredSignatureError
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.session import get_db
from src.database.models.user import User
from src.database.schemas.user import UserRole
from src.utils.exceptions import (
    TokenExpiredError,
    TokenInvalidError,
    UserNotFoundException,
)
from src.utils.logger import get_logger
from src.utils.security import SecurityUtils
from src.utils.token_blacklist import is_jti_revoked


class Auth:
    """
    類別化的驗證工具，提供 FastAPI 依賴與權限 decorator。
    保留模組層 alias 以向下相容原有介面。
    """

    logger = get_logger("auth")
    oauth2 = HTTPBearer(scheme_name="Bearer")

    # -------------------------------------------------------------------
    # Internal: 取得使用者資料
    # -------------------------------------------------------------------
    @staticmethod
    async def _get_user_by_email(email: str, db: AsyncSession) -> User:
        stmt = select(User).filter_by(email=email)
        result = await db.execute(stmt)
        user = result.scalars().first()
        if not user:
            Auth.logger.warning(f"User {email} not found")
            raise UserNotFoundException()
        return user

    # -------------------------------------------------------------------
    # Auth Dependency: 取得目前登入使用者（含黑名單檢查）
    # -------------------------------------------------------------------
    @classmethod
    async def get_current_user(
        cls,
        credentials: HTTPAuthorizationCredentials = Depends(oauth2),
        db: AsyncSession = Depends(get_db),
    ) -> User:
        """
        1. 驗證 token → 2. 檢查 jti 是否在黑名單 → 3. 查 DB 使用者
        """
        try:
            payload = SecurityUtils.decode_token(credentials.credentials)
        except ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token payload"
            )
        except TokenExpiredError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="refresh_token_expired",
                headers={
                    "WWW-Authenticate": 'Bearer error="invalid_token", error_description="Refresh token expired"'
                },
            )
        except TokenInvalidError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="invalid_refresh_token",
                headers={"WWW-Authenticate": 'Bearer error="invalid_token"'},
            )

        if not payload.get("sub") or not payload.get("jti"):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token payload"
            )

        jti = payload["jti"]
        email = payload["sub"]

        if await is_jti_revoked(jti):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has been revoked",
                headers={"WWW-Authenticate": "Bearer"},
            )

        return await cls._get_user_by_email(email, db)

    # -------------------------------------------------------------------
    # Decorator: 檢查使用者角色權限
    # -------------------------------------------------------------------
    @staticmethod
    def role_required(*allowed_roles: UserRole):
        """
        使用者角色權限控制 decorator，例如：
        @Auth.role_required(UserRole.ADMIN, UserRole.SUPER_ADMIN)
        """

        def decorator(fn: Callable[..., Any]):
            @wraps(fn)
            async def wrapper(
                *args, current_user: User = Depends(Auth.get_current_user), **kwargs
            ):
                if current_user.role not in [r.value for r in allowed_roles]:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Not enough permissions",
                    )
                return await fn(*args, **kwargs)

            return wrapper

        return decorator
