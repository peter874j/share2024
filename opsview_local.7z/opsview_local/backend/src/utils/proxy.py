import os
import socket
import yaml
from typing import Dict, List, Union
from urllib.parse import urlparse, ParseResult


class ProxyUtils:
    @staticmethod
    def extract_host_and_port(url: str) -> str:
        parsed: ParseResult = urlparse(url)
        host, port = parsed.hostname, parsed.port
        return f"{host}:{port}" if port else host

    @staticmethod
    def is_in_net(ip: str, network: str, mask: str) -> bool:
        def to_bin(x):
            return int("".join(f"{int(o):08b}" for o in x.split(".")), 2)

        return (to_bin(ip) & to_bin(mask)) == (to_bin(network) & to_bin(mask))

    def _normalize_factory_code(code: str) -> str:
        """私有方法：統一處理特殊廠區代碼轉換"""
        mapping = {
            "M01": "LT",
            "M02": "LK"
        }
        return mapping.get(code, code)

    @staticmethod
    def dns_resolve(host: str) -> Union[str, None]:
        try:
            return socket.gethostbyname(host)
        except socket.error:
            return None

    @classmethod
    def find_proxy_for_host(
        self,
        host: str,  # 目標主機的名稱或 IP 地址
        factory: Union[str, None] = None,  # 廠區代碼，預設為 None
    ) -> Union[str, None]:  # 返回代理伺服器的地址或 None
        # 從 YAML 檔案載入 proxy 規則和 fallback proxy
        yaml_file: str = os.path.join(
            os.path.dirname(__file__), "../../factory_settings.yaml"
        )

        # 確保檔案存在
        if not os.path.exists(yaml_file):
            raise FileNotFoundError(f"設定檔案 {yaml_file} 不存在！")

        # 讀取 YAML 設定檔案
        with open(yaml_file, "r") as file:
            config: Dict[
                str, Union[Dict[str, Union[str, List[Dict[str, str]]]], None]
            ] = yaml.safe_load(file)
            FACTORY_PROXY_RULES: Dict[str, List[Dict[str, str]]] = config.get(
                "proxy_rules", {}
            )
            FACTORY_FALLBACK_PROXY: Dict[str, Union[str, None]] = config.get(
                "fallback_proxy", {}
            )

        # 從參數或環境變數讀取當前廠區（預設 M11）
        current: str = factory or os.getenv("PLANT_CODE", "M11")
        current = self._normalize_factory_code(current)
        rules: List[Dict[str, str]] = FACTORY_PROXY_RULES.get(current, [])
        fallback: Union[str, None] = FACTORY_FALLBACK_PROXY.get(current)

        # 使用 DNS 解析獲取 IP 地址
        ip: Union[str, None] = self.dns_resolve(host)
        if not ip:
            return fallback

        # 依序遍歷規則，判斷 IP 是否符合每個網段
        for rule in rules:
            if self.is_in_net(ip, rule["network"], rule["mask"]):  # 判斷 IP 是否在指定網段內
                return rule["proxy"]

        return fallback  # 如果沒有匹配的規則，返回回退代理
