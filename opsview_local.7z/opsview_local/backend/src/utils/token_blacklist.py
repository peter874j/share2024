from cachetools import TTLCache
import asyncio

from src.config.settings import settings

token_blacklist = TTLCache(maxsize=10_000, ttl=settings.access_token_expire_seconds)
cache_lock = asyncio.Lock()


async def revoke_jti(jti: str) -> None:
    async with cache_lock:
        token_blacklist[jti] = True


async def is_jti_revoked(jti: str) -> bool:
    async with cache_lock:
        token_blacklist.expire()
        return jti in token_blacklist
