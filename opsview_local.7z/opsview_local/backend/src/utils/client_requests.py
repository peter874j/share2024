import httpx
from typing import Dict, Optional, Any
from src.utils.logger import get_logger
from src.utils.proxy import ProxyUtils


class ClientRequests:
    """
    封裝對 Client 服務的 HTTP 請求工具（class-based）。
    - 使用 @staticmethod 提供與類別狀態無關的代理組態計算。
    - 使用 @classmethod 以便共享/覆寫類別層級設定（逾時、SSL 驗證等）。
    """

    DEFAULT_TIMEOUT: float = 20.0
    VERIFY_SSL: bool = False
    _logger = get_logger("client_requests")

    @staticmethod
    def get_proxies_for_server(
        server_ip: str, server_location: str
    ) -> Optional[Dict[str, str]]:
        """
        根據目標服務器 IP 與地點取得代理設定。
        """
        host = ProxyUtils.extract_host_and_port(f"http://{server_ip}")
        proxy = ProxyUtils.find_proxy_for_host(host, server_location)

        if proxy:
            return {
                "http://": proxy,
                "https://": proxy,
            }
        return None

    @classmethod
    async def make_request(
        self, endpoint: str, server_ip: str, server_location: str
    ) -> Optional[Dict[str, Any]]:
        """
        通用 GET 請求（含錯誤處理）。
        """
        url = f"http://{server_ip}/{endpoint}"
        proxies = self.get_proxies_for_server(
            server_ip=server_ip, server_location=server_location
        )

        async with httpx.AsyncClient(
            timeout=self.DEFAULT_TIMEOUT, proxies=proxies, verify=self.VERIFY_SSL
        ) as client:
            try:
                response = await client.get(url)
                response.raise_for_status()
                return response.json()
            except httpx.RequestError as exc:
                self._logger.warning(f"URL: {url}, cannot reach server: {exc}")
                return None
            except httpx.HTTPStatusError as exc:
                text = exc.response.text if exc.response is not None else str(exc)
                self._logger.warning(f"URL: {url}, bad response from server: {text}")
                return None

    @classmethod
    async def fetch_host_names(
        self, server_ip: str, server_location: str
    ) -> Optional[Dict[str, Any]]:
        return await self.make_request(
            endpoint="names", server_ip=server_ip, server_location=server_location
        )

    @classmethod
    async def fetch_host_config(
        self, server_ip: str, server_location: str
    ) -> Optional[Dict[str, Any]]:
        return await self.make_request(
            endpoint="config", server_ip=server_ip, server_location=server_location
        )

    @classmethod
    async def fetch_host_health(
        self, server_ip: str, server_location: str
    ) -> Optional[Dict[str, Any]]:
        return await self.make_request(
            endpoint="check_ports", server_ip=server_ip, server_location=server_location
        )

    @classmethod
    async def update_host_config(
        self, server_ip: str, server_location: str, config_data: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """
        以 POST 更新主機設定。
        """
        url = f"http://{server_ip}/config"
        proxies = self.get_proxies_for_server(
            server_ip=server_ip, server_location=server_location
        )

        async with httpx.AsyncClient(
            timeout=self.DEFAULT_TIMEOUT, proxies=proxies, verify=self.VERIFY_SSL
        ) as client:
            try:
                response = await client.post(url, json=config_data)
                response.raise_for_status()
                return response.json()
            except httpx.RequestError as exc:
                self._logger.warning(f"URL: {url}, cannot reach server: {exc}")
                return None
            except httpx.HTTPStatusError as exc:
                text = exc.response.text if exc.response is not None else str(exc)
                self._logger.warning(f"URL: {url}, bad response from server: {text}")
                return None
