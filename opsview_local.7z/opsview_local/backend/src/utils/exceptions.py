class UserNotFoundException(Exception):
    def __init__(self, message="User not found"):
        super().__init__(message)


class UnitAlreadyExistsError(Exception):
    """Raised when trying to create a Unit that already exists."""

    def __init__(self, message="Unit is already exists."):
        super().__init__(message)


class OrchestrationError(Exception):
    pass


class ConflictError(OrchestrationError):
    pass


class UnitGetByServerCamError(Exception):
    pass


class UnitNotFound(UnitGetByServerCamError):
    pass


class UnitMultipleFound(UnitGetByServerCamError):
    pass


class TokenExpiredError(Exception):
    pass


class TokenInvalidError(Exception):
    pass
