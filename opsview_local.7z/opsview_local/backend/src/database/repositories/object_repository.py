from abc import ABC, abstractmethod
from typing import Any, Mapping, Optional, List, Sequence, Tuple, Dict, Literal
from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import InstrumentedAttribute
from src.database.models.object import Object
from src.utils.pagination import paginate


class IObjectRepository(ABC):
    @abstractmethod
    async def get_by_id(self, object_id: int) -> Optional[Object]:
        ...

    @abstractmethod
    async def get_by_name(self, name: str) -> Optional[Object]:
        ...

    @abstractmethod
    async def get_multi(
        self,
        filters: Dict = {},
        eager_options: List[Any] = [],
    ) -> List[Object]:
        ...

    @abstractmethod
    async def get_paginated_multi(
        self,
        filters: List[Any],
        page: int,
        limit: int,
        sort_field: str,
        sort_order: Literal["asc", "desc"],
    ) -> Tuple[List[Object], Dict[str, Any]]:
        ...

    @abstractmethod
    async def add(self, object: Object) -> Object:
        ...

    @abstractmethod
    async def update(self, object_id: int, fields: dict) -> Optional[Object]:
        ...

    @abstractmethod
    async def get_by_id_with_filters(
        self,
        object_id: int,
        fields: Optional[Mapping[str, Any]] = None,
        eager_options: List[Any] = [],
    ):
        ...

    @abstractmethod
    async def delete_by_unit_id(self, unit_id: int) -> None:
        ...


class ObjectRepository(IObjectRepository):
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_id(self, object_id: int) -> Optional[Object]:
        return await self.db.get(Object, object_id)

    async def get_by_name(self, name: str) -> Optional[Object]:
        stmt = select(Object).filter_by(name=name)
        res = await self.db.execute(stmt)
        return res.scalars().first()

    async def get_multi(
        self,
        filters: Optional[List[Any]] = None,
        eager_options: List[Any] = [],
    ) -> List[Object]:
        filters = filters or []
        eager_options = eager_options or []

        stmt = select(Object).options(*eager_options)

        if filters:
            stmt = stmt.where(and_(*filters))

        res = await self.db.execute(stmt)
        return res.scalars().all()

    async def get_paginated_multi(
        self,
        filters: List[Any],
        page: int,
        limit: int,
        sort_field: str,
        sort_order: Literal["asc", "desc"],
    ) -> Tuple[List[Object], Dict[str, Any]]:
        return await paginate(
            self.db, Object, filters, page, limit, sort_field, sort_order
        )

    async def add(self, object: Object) -> Object:
        self.db.add(object)
        await self.db.flush()
        await self.db.refresh(object)
        return object

    async def update(self, object_id: int, fields: Dict) -> Optional[Object]:
        object = await self.get_by_id(object_id)
        if not object:
            return None
        for k, v in fields.items():
            setattr(object, k, v)
        await self.db.flush()
        await self.db.refresh(object)
        return object

    async def get_by_id_with_filters(
        self,
        object_id: int,
        fields: Optional[Mapping[str, Any]] = None,
        eager_options: List[Any] = [],
    ):
        stmt = select(Object).options(*eager_options).where(Object.id == object_id)

        if fields:
            for key, value in fields.items():
                if key == "id":
                    # 避免與 object_id 衝突，也避免重複條件
                    raise ValueError(
                        "Do not pass 'id' in fields; use the object_id parameter."
                    )

                # 檢查傳入欄位合法性避免錯誤
                col = getattr(Object, key, None)
                if not isinstance(col, InstrumentedAttribute):
                    raise ValueError(f"Invalid filter column: {key}")

                # 基本動態條件：None、序列(IN)、一般等號
                if value is None:
                    stmt = stmt.where(col.is_(None))
                elif isinstance(value, Sequence) and not isinstance(
                    value, (str, bytes)
                ):
                    stmt = stmt.where(col.in_(value))
                else:
                    stmt = stmt.where(col == value)

        # 預期唯一（含 PK），在多筆時拋錯
        res = await self.db.execute(stmt)
        return res.scalars().one_or_none()

    async def delete_by_unit_id(self, unit_id: int) -> None:
        await self.db.execute(select(Object).where(Object.unit_id == unit_id).delete())
