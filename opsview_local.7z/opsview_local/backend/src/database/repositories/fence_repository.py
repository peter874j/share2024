from abc import ABC, abstractmethod
from typing import Any, Dict, List, Literal, Mapping, Optional, Tuple, Sequence
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import InstrumentedAttribute

from src.database.models.fence import Fence
from src.utils.logger import get_logger
from src.utils.pagination import paginate

logger = get_logger("fence_repository")


class IFenceRepository(ABC):
    @abstractmethod
    async def get_by_id(self, fence_id: int) -> Optional[Fence]:
        ...

    @abstractmethod
    async def get_by_name(self, name: str) -> Optional[Fence]:
        ...

    @abstractmethod
    async def get_by_unit_id(self, unit_id: int) -> Optional[Fence]:
        ...

    @abstractmethod
    async def get_multi(
        self,
        filters: Dict = {},
        eager_options: List[Any] = [],
    ) -> List[Fence]:
        ...

    @abstractmethod
    async def get_paginated_multi(
        self,
        filters: List[Any],
        page: int,
        limit: int,
        sort_field: str,
        sort_order: Literal["asc", "desc"],
    ) -> Tuple[List[Fence], Dict[str, Any]]:
        ...

    @abstractmethod
    async def add(self, fence: Fence) -> Fence:
        ...

    @abstractmethod
    async def update(self, fence_id: int, fields: dict) -> Optional[Fence]:
        ...

    @abstractmethod
    async def delete(self, fence_id: int) -> None:
        ...

    @abstractmethod
    async def get_by_id_with_filters(
        self,
        fence_id: int,
        fields: Optional[Mapping[str, Any]] = None,
        eager_options: List[Any] = [],
    ):
        ...

    @abstractmethod
    async def delete_by_unit_id(self, unit_id: int) -> None:
        ...


class FenceRepository(IFenceRepository):
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_id(self, fence_id: int) -> Optional[Fence]:
        return await self.db.get(Fence, fence_id)

    async def get_by_name(self, name: str) -> Optional[Fence]:
        stmt = select(Fence).filter_by(name=name)
        res = await self.db.execute(stmt)
        return res.scalar_one_or_none()

    async def get_by_unit_id(self, unit_id: int) -> List[Fence]:
        stmt = select(Fence).where(Fence.unit_id == unit_id)
        res = await self.db.execute(stmt)
        return res.scalars().all()

    async def get_multi(
        self,
        filters: Dict[str, Any] = None,
        eager_options: List[Any] = None,
    ) -> List[Fence]:
        filters = filters or {}
        eager_options = eager_options or []
        stmt = select(Fence).filter_by(**filters).options(*eager_options)
        res = await self.db.execute(stmt)
        return res.scalars().all()

    async def get_paginated_multi(
        self,
        filters: List[Any],
        page: int,
        limit: int,
        sort_field: str,
        sort_order: Literal["asc", "desc"],
    ) -> Tuple[List[Fence], Dict[str, Any]]:
        return await paginate(
            self.db, Fence, filters, page, limit, sort_field, sort_order
        )

    async def add(self, fence: Fence) -> Fence:
        self.db.add(fence)
        await self.db.flush()
        await self.db.refresh(fence)
        return fence

    async def update(self, fence_id: int, fields: Dict[str, Any]) -> Optional[Fence]:
        fence = await self.get_by_id(fence_id)
        if not fence:
            return None
        for k, v in fields.items():
            setattr(fence, k, v)
        await self.db.flush()
        await self.db.refresh(fence)
        return fence

    async def get_by_id_with_filters(
        self,
        fence_id: int,
        fields: Optional[Mapping[str, Any]] = None,
        eager_options: List[Any] = None,
    ) -> Optional[Fence]:
        eager_options = eager_options or []
        stmt = select(Fence).options(*eager_options).where(Fence.id == fence_id)

        if fields:
            for key, value in fields.items():
                if key == "id":
                    # 避免與 fence_id 衝突，也避免重複條件
                    raise ValueError(
                        "Do not pass 'id' in fields; use the fence_id parameter."
                    )

                col = getattr(Fence, key, None)
                if not isinstance(col, InstrumentedAttribute):
                    raise ValueError(f"Invalid filter column: {key}")

                # 支援 None、序列(IN)、等號
                if value is None:
                    stmt = stmt.where(col.is_(None))
                elif isinstance(value, Sequence) and not isinstance(
                    value, (str, bytes)
                ):
                    stmt = stmt.where(col.in_(value))
                else:
                    stmt = stmt.where(col == value)

        res = await self.db.execute(stmt)
        return res.scalars().one_or_none()

    async def delete(self, fence_id: int) -> None:
        await self.db.delete(await self.get_by_id(fence_id))

    async def delete_by_unit_id(self, unit_id: int) -> None:
        await self.db.execute(select(Fence).where(Fence.unit_id == unit_id).delete())
