from abc import ABC, abstractmethod
from datetime import datetime, date, timedelta, timezone
from typing import Any, Dict, Iterable, List, Mapping, Optional
from sqlalchemy import Integer, select, text, exists, bindparam, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload, with_loader_criteria
from sqlalchemy.dialects.postgresql import ARRAY

from src.database.models.report_item import ReportItem
from src.database.models.cam import Cam
from src.database.models.unit_cam import UnitCam
from src.database.models.report import Report
from src.database.models.unit import Unit
from src.database.models.stage import Stage


class IReportRepository(ABC):
    @abstractmethod
    async def fetch_reports_between(
        self,
        start_dt: datetime,
        end_dt: datetime,
        fab_id: Optional[int] = None,
        stage_id: Optional[int] = None,
        unit_ids: Optional[List[int]] = None,
    ) -> List[Mapping[str, Any]]:
        ...

    @abstractmethod
    async def fetch_reports_with_unitname_between(
        self,
        start_dt: datetime,
        end_dt: datetime,
        fab_id: Optional[int] = None,
        stage_id: Optional[int] = None,
        unit_ids: Optional[Iterable[int]] = None,
    ) -> List[Mapping[str, Any]]:
        ...

    @abstractmethod
    async def fetch_cycle_detail_row(
        self,
        unit_id: int,
        cycle_start_time: str,
    ) -> Optional[Mapping[str, Any]]:
        ...

    @abstractmethod
    async def get_unit_with_relations_for_detail(self, unit_id: int) -> Optional[Unit]:
        ...

    @abstractmethod
    async def get_unit_with_relations_basic(self, unit_id: int) -> Optional[Unit]:
        ...

    @abstractmethod
    async def get_report_by_id(self, report_id: int) -> Optional[Report]:
        ...

    @abstractmethod
    async def count_items_for_unit_on_date(self, unit_id: int, dt: date) -> int:
        ...

    @abstractmethod
    async def create(
        self, *, unit_id: int, data: Dict, source: str = "webhook"
    ) -> Report:
        ...

    @abstractmethod
    async def exists_manual_items_for_unit_on_date(
        self, unit_id: int, date: date
    ) -> bool:
        ...


class ReportRepository(IReportRepository):
    """資料存取層：只負責 CRUD 與 flush，不做 commit，不含業務規則。"""

    def __init__(self, db: AsyncSession):
        self.db = db

    # ---------- Reads (no commit) ----------

    async def fetch_reports_between(
        self,
        start_dt: datetime,
        end_dt: datetime,
        fab_id: Optional[int] = None,
        stage_id: Optional[int] = None,
        unit_ids: Optional[List[int]] = None,
    ):
        # 只抓有符合時間條件的 items 的 Report
        stmt = select(Report).where(
            exists(
                select(1)
                .select_from(ReportItem)
                .where(
                    ReportItem.report_id == Report.id,
                    ReportItem.cycle_start_time.between(start_dt, end_dt),
                )
            )
        )

        # Fab 過濾
        if fab_id is not None:
            stmt = stmt.join(Report.unit).join(Unit.stage).where(Stage.fab_id == fab_id)

        # Stage 過濾
        if stage_id is not None:
            stmt = stmt.join(Report.unit).join(Unit.stage).where(Stage.id == stage_id)

        # Unit 過濾
        if unit_ids:
            stmt = stmt.join(Report.unit).where(Unit.id.in_(unit_ids))

        stmt = stmt.order_by(Report.id)  # 主表排序

        # 預載入並只取時間區間內的 items
        stmt = stmt.options(
            with_loader_criteria(
                ReportItem,
                lambda cls: cls.cycle_start_time.between(start_dt, end_dt),
                include_aliases=True,
            ),
            selectinload(Report.items),
            selectinload(Report.unit).joinedload(Unit.stage),
        )

        result = await self.db.scalars(stmt)
        return result.all()

    async def fetch_reports_with_unitname_between(
        self,
        start_dt: datetime,
        end_dt: datetime,
        fab_id: Optional[int] = None,
        stage_id: Optional[int] = None,
        unit_ids: Optional[Iterable[int]] = None,
    ):
        sql = """
        SELECT
            r.id,
            r.unit_id,
            u.name AS unit_name,
            r.created_at,
            COALESCE(items.items, '[]'::json) AS items
        FROM report r
        JOIN unit u ON u.id = r.unit_id
        LEFT JOIN stage s ON s.id = u.stage_id
        LEFT JOIN fab f   ON f.id = s.fab_id
        LEFT JOIN LATERAL (
            SELECT json_agg(
                    json_build_object(
                        'id', ri.id,
                        'work_id', ri.work_id,
                        'cycle_start_time', ri.cycle_start_time,
                        'cycle_count', ri.cycle_count,
                        'extra_data', ri.extra_data
                    )
                    ORDER BY ri.cycle_start_time
                ) AS items
            FROM report_item ri
            WHERE ri.report_id = r.id
            AND ri.cycle_start_time BETWEEN :start_dt AND :end_dt
        ) AS items ON TRUE
        WHERE EXISTS (
            SELECT 1
            FROM report_item ri
            WHERE ri.report_id = r.id
            AND ri.cycle_start_time BETWEEN :start_dt AND :end_dt
        )
        AND (:fab_id   IS NULL OR f.id = :fab_id)
        AND (:stage_id IS NULL OR s.id = :stage_id)
        AND (:unit_ids IS NULL OR u.id = ANY(:unit_ids))
        ORDER BY r.id;
        """

        params = {
            "start_dt": start_dt,
            "end_dt": end_dt,
            "fab_id": fab_id,
            "stage_id": stage_id,
            "unit_ids": list(unit_ids) if unit_ids else None,
        }

        stmt = text(sql).bindparams(
            bindparam("start_dt"),
            bindparam("end_dt"),
            bindparam("fab_id", type_=Integer),
            bindparam("stage_id", type_=Integer),
            bindparam("unit_ids", type_=ARRAY(Integer)),
        )

        result = await self.db.execute(stmt, params)
        # 保持原方法的返回格式
        return result.mappings().all()

    async def fetch_cycle_detail_row(
        self,
        unit_id: int,
        cycle_start_time: str,
    ) -> Optional[Mapping[str, Any]]:
        # 先轉成 tz-aware datetime
        dt_val = datetime.fromisoformat(cycle_start_time.replace("Z", "+00:00"))

        sql = text(
            """
            SELECT
            r.id,
            r.unit_id,
            (
                jsonb_build_object(
                'id', ri.id,
                'work_id', ri.work_id,
                'cycle_start_time',
                    to_char(ri.cycle_start_time AT TIME ZONE 'UTC',
                            'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),
                'cycle_count', ri.cycle_count
                )
                || COALESCE(ri.extra_data, '{}'::jsonb)
            ) AS elem
            FROM report r
            JOIN report_item ri ON ri.report_id = r.id
            WHERE r.unit_id = :unit_id
            AND ri.cycle_start_time = :cst
            LIMIT 1
            """
        )

        result = await self.db.execute(
            sql,
            {
                "unit_id": unit_id,
                "cst": dt_val,  # 傳 datetime 而不是 str
            },
        )
        return result.mappings().first()

    async def get_unit_with_relations_for_detail(self, unit_id: int) -> Optional[Unit]:
        """取得 Unit 與影像相關的深關聯（給 detail 用）"""
        stmt = (
            select(Unit)
            .options(
                selectinload(Unit.stage).selectinload(Stage.department),
                selectinload(Unit.stage).selectinload(Stage.fab),
                selectinload(Unit.unit_cams)
                .selectinload(UnitCam.cam)
                .selectinload(Cam.server),
                selectinload(Unit.cams).selectinload(Cam.server),
            )
            .filter_by(id=unit_id)
        )
        res = await self.db.execute(stmt)
        return res.scalars().first()

    async def get_unit_with_relations_basic(self, unit_id: int) -> Optional[Unit]:
        """更新 workId 後回傳基本關聯即可"""
        stmt = (
            select(Unit)
            .options(
                selectinload(Unit.stage).selectinload(Stage.department),
                selectinload(Unit.stage).selectinload(Stage.fab),
                selectinload(Unit.cams),
            )
            .filter_by(id=unit_id)
        )
        res = await self.db.execute(stmt)
        return res.scalars().first()

    async def get_report_by_id(self, report_id: int) -> Optional[Report]:
        return await self.db.get(Report, report_id)

    async def count_items_for_unit_on_date(self, unit_id: int, dt: date) -> int:
        """
        回傳指定 unit + 指定日期(UTC) 的資料筆數。
        """
        start = datetime(dt.year, dt.month, dt.day, tzinfo=timezone.utc)
        end = start + timedelta(days=1)

        conditions = [
            Report.unit_id == unit_id,
            Report.created_at >= start,
            Report.created_at < end,
        ]

        stmt = select(func.count()).select_from(Report).where(*conditions)
        res = await self.db.scalar(stmt)
        return int(res or 0)

    # ---------- Writes (flush only, no commit) ----------

    async def create(
        self, *, unit_id: int, data: Dict, source: str = "webhook"
    ) -> Report:
        """
        建立 Report（不 commit）
        - source: 區分 'webhook' 與 'manual'，預設 webhook
        - ,原始資料（webhook 與 manual 皆保存）
        """
        obj = Report(unit_id=unit_id, data=data, source=source)
        self.db.add(obj)
        await self.db.flush()  # 不 commit
        return obj

    async def exists_manual_items_for_unit_on_date(
        self, unit_id: int, date: date
    ) -> bool:
        """
        檢查是否存在「人工匯入」之同 unit + 同日期的任何 ReportItem
        規則：
          - 以 DATE(report_item.cycle_start_time) 為日期邊界
        """
        subq = (
            select(1)
            .select_from(ReportItem)
            .join(Report, ReportItem.report_id == Report.id)
            .where(
                Report.unit_id == unit_id,
                func.date(ReportItem.cycle_start_time) == date,
            )
            .limit(1)
        )

        stmt = select(exists(subq))
        res = await self.db.scalar(stmt)
        return bool(res)
