from abc import ABC, abstractmethod
from typing import Optional
from sqlalchemy import select
from sqlalchemy.orm import joinedload
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.models.unit_cam import UnitCam
from src.database.models.cam import Cam
from src.database.models.server import Server


class IUnitCamRepository(ABC):
    @abstractmethod
    async def get_with_cam_server_fab(self, unit_id: int) -> Optional[UnitCam]:
        ...


class UnitCamRepository(IUnitCamRepository):
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_with_cam_server_fab(self, unit_id: int) -> Optional[UnitCam]:
        stmt = (
            select(UnitCam)
            .options(
                joinedload(UnitCam.cam).joinedload(Cam.server).joinedload(Server.fab)
            )
            .where(UnitCam.unit_id == unit_id)
        )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()
