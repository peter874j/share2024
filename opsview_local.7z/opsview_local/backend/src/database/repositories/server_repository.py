from typing import List, Optional, Literal, Tuple, Sequence, Any
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload
from src.database.models.server import Server
from src.database.models.cam import Cam
from src.database.models.unit_cam import UnitCam
from src.database.models.unit import Unit
from src.utils.pagination import paginate


class ServerRepository:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def add(self, server: Server) -> Server:
        self.db.add(server)
        await self.db.flush()
        return server  # no commit

    async def get_by_id(
        self,
        server_id: int,
        with_relations: bool = False,
        full_relations: bool = False,
    ) -> Optional[Server]:
        stmt = select(Server).where(Server.id == server_id)
        if with_relations:
            stmt = stmt.options(
                selectinload(Server.cams),
                selectinload(Server.fab),
            )
        if full_relations:
            stmt = (
                select(Server)
                .options(
                    selectinload(Server.cams)
                    .selectinload(Cam.unit_cams)
                    .selectinload(UnitCam.unit)
                    .selectinload(Unit.stage),
                    selectinload(Server.cams)
                    .selectinload(Cam.units)
                    .selectinload(Unit.stage),
                    selectinload(Server.fab),
                )
                .where(Server.id == server_id)
            )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()

    async def list_all(self) -> List[Server]:
        result = await self.db.execute(select(Server))
        return list(result.scalars().all())

    async def update_partial(self, server: Server, updates: dict) -> Server:
        for k, v in updates.items():
            setattr(server, k, v)
        self.db.add(server)
        await self.db.flush()
        return server

    async def delete(self, server: Server) -> None:
        await self.db.delete(server)
        # no commit

    async def list_filtered_with_relations(
        self, filters: Sequence[Any]
    ) -> List[Server]:
        result = await self.db.execute(
            select(Server)
            .options(
                selectinload(Server.cams)
                .selectinload(Cam.units)
                .selectinload(Unit.stage),
                selectinload(Server.fab),
            )
            .where(*filters)
        )
        return list(result.scalars().all())

    async def get_paginated(
        self,
        filters: Sequence[Any],
        page: int,
        limit: int,
        sort_field: str,
        sort_order: Literal["asc", "desc"],
    ) -> Tuple[List[Server], dict]:
        return await paginate(
            self.db,
            Server,
            list(filters),
            page,
            limit,
            sort_field,
            sort_order,
            [
                selectinload(Server.cams)
                .selectinload(Cam.units)
                .selectinload(Unit.stage),
                selectinload(Server.fab),
            ],
        )
