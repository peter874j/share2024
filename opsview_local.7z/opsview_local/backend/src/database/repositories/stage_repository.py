from abc import ABC, abstractmethod
from typing import Any, Optional, List, Tuple, Dict, Literal
from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession
from src.database.models.stage import Stage
from src.utils.pagination import paginate


class IStageRepository(ABC):
    @abstractmethod
    async def get_by_id(self, stage_id: int) -> Optional[Stage]:
        ...

    @abstractmethod
    async def get_by_name(self, name: str) -> Optional[Stage]:
        ...

    @abstractmethod
    async def get_multi(
        self,
        filters: Dict = {},
        eager_options: List[Any] = [],
    ) -> List[Stage]:
        ...

    @abstractmethod
    async def get_paginated_multi(
        self,
        filters: List[Any],
        page: int,
        limit: int,
        sort_field: str,
        sort_order: Literal["asc", "desc"],
    ) -> Tuple[List[Stage], Dict[str, Any]]:
        ...

    @abstractmethod
    async def add(self, stage: Stage) -> Stage:
        ...

    @abstractmethod
    async def update(self, stage_id: int, fields: dict) -> Optional[Stage]:
        ...


class StageRepository(IStageRepository):
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_id(self, stage_id: int) -> Optional[Stage]:
        return await self.db.get(Stage, stage_id)

    async def get_by_name(self, name: str) -> Optional[Stage]:
        stmt = select(Stage).filter_by(name=name)
        res = await self.db.execute(stmt)
        return res.scalars().first()

    async def get_multi(
        self,
        filters: Dict = {},
        eager_options: List[Any] = [],
    ) -> List[Stage]:
        filters = filters or []
        eager_options = eager_options or []

        stmt = select(Stage).options(*eager_options)

        if filters:
            stmt = stmt.where(and_(*filters))

        res = await self.db.execute(stmt)
        return res.scalars().all()

    async def get_paginated_multi(
        self,
        filters: List[Any],
        page: int,
        limit: int,
        sort_field: str,
        sort_order: Literal["asc", "desc"],
    ) -> Tuple[List[Stage], Dict[str, Any]]:
        return await paginate(
            self.db, Stage, filters, page, limit, sort_field, sort_order
        )

    async def add(self, stage: Stage) -> Stage:
        self.db.add(stage)
        await self.db.flush()
        await self.db.refresh(stage)
        return stage

    async def update(self, stage_id: int, fields: dict) -> Optional[Stage]:
        stage = await self.get_by_id(stage_id)
        if not stage:
            return None
        for k, v in fields.items():
            setattr(stage, k, v)
        await self.db.flush()
        await self.db.refresh(stage)
        return stage
