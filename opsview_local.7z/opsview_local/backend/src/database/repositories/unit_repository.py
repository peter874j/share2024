from abc import ABC, abstractmethod
from typing import Any, Mapping, Optional, List, Sequence, Tuple, Dict, Literal
from sqlalchemy import select, and_, func, case
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import InstrumentedAttribute, selectinload

from src.database.models.stage import Stage
from src.database.models.server import Server
from src.database.models.cam import Cam
from src.database.models.unit_cam import UnitCam
from src.database.models.unit import Unit
from src.utils.pagination import paginate


class IUnitRepository(ABC):
    @abstractmethod
    async def get_by_id(self, unit_id: int) -> Optional[Unit]:
        ...

    @abstractmethod
    async def get_by_name(self, name: str) -> Optional[Unit]:
        ...

    @abstractmethod
    async def get_multi(
        self,
        filters: Dict = {},
        eager_options: List[Any] = [],
    ) -> List[Unit]:
        ...

    @abstractmethod
    async def get_paginated_multi(
        self,
        filters: List[Any],
        page: int,
        limit: int,
        sort_field: str,
        sort_order: Literal["asc", "desc"],
    ) -> Tuple[List[Unit], Dict[str, Any]]:
        ...

    @abstractmethod
    async def add(self, unit: Unit) -> Unit:
        ...

    @abstractmethod
    async def update(self, unit_id: int, fields: Dict) -> Optional[Unit]:
        ...

    @abstractmethod
    async def delete(self, unit_id: int) -> bool:
        ...

    @abstractmethod
    async def get_by_id_with_filters(
        self,
        unit_id: int,
        fields: Optional[Mapping[str, Any]] = None,
        eager_options: List[Any] = [],
    ):
        ...

    @abstractmethod
    async def exists_by_name_and_stage_excluding_id(
        self, name: str, stage_id: int, exclude_unit_id: int
    ) -> bool:
        ...

    @abstractmethod
    async def get_cam_server_status_by_unit(
        self, unit_id: int
    ) -> List[Tuple[bool, bool]]:
        ...

    @abstractmethod
    async def get_server_status_bulk(self, unit_ids: Sequence[int]) -> Dict[int, bool]:
        ...

    @abstractmethod
    async def get_by_server_cam(
        self, *, server_ip: str, cam_ip: str, cam_port: int
    ) -> Optional[Unit]:
        ...


class UnitRepository(IUnitRepository):
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_id(self, unit_id: int) -> Optional[Unit]:
        return await self.db.get(Unit, unit_id)

    async def get_by_name(self, name: str) -> Optional[Unit]:
        stmt = select(Unit).filter_by(name=name)
        res = await self.db.execute(stmt)
        return res.scalar_one_or_none()

    async def get_multi(
        self,
        filters: Dict = {},
        eager_options: List[Any] = [],
    ) -> List[Unit]:
        filters = filters or []
        eager_options = eager_options or []

        stmt = select(Unit).options(*eager_options)

        if filters:
            stmt = stmt.where(and_(*filters))

        res = await self.db.execute(stmt)
        return res.scalars().all()

    async def get_paginated_multi(
        self,
        filters: List[Any],
        page: int,
        limit: int,
        sort_field: str,
        sort_order: Literal["asc", "desc"],
    ) -> Tuple[List[Unit], Dict[str, Any]]:
        return await paginate(
            self.db, Unit, filters, page, limit, sort_field, sort_order
        )

    async def add(self, unit: Unit) -> Unit:
        self.db.add(unit)
        await self.db.flush()
        await self.db.refresh(unit)
        return unit

    async def update(self, unit_id: int, fields: Dict) -> Optional[Unit]:
        unit = await self.get_by_id(unit_id)
        if not unit:
            return None
        for k, v in fields.items():
            setattr(unit, k, v)
        await self.db.flush()
        await self.db.refresh(unit)
        return unit

    async def delete(self, unit_id: int) -> bool:
        unit = await self.db.get(Unit, unit_id)
        if not unit:
            return False

        await self.db.delete(unit)
        await self.db.flush()
        return True

    async def get_by_id_with_filters(
        self,
        unit_id: int,
        fields: Optional[Mapping[str, Any]] = None,
        eager_options: List[Any] = [],
    ):
        stmt = select(Unit).options(*eager_options).where(Unit.id == unit_id)

        if fields:
            for key, value in fields.items():
                if key == "id":
                    # 避免與 unit_id 衝突，也避免重複條件
                    raise ValueError(
                        "Do not pass 'id' in fields; use the unit_id parameter."
                    )

                # 檢查傳入欄位合法性避免錯誤
                col = getattr(Unit, key, None)
                if not isinstance(col, InstrumentedAttribute):
                    raise ValueError(f"Invalid filter column: {key}")

                # 基本動態條件：None、序列(IN)、一般等號
                if value is None:
                    stmt = stmt.where(col.is_(None))
                elif isinstance(value, Sequence) and not isinstance(
                    value, (str, bytes)
                ):
                    stmt = stmt.where(col.in_(value))
                else:
                    stmt = stmt.where(col == value)

        # 預期唯一（含 PK），在多筆時拋錯
        res = await self.db.execute(stmt)
        return res.scalars().one_or_none()

    async def exists_by_name_and_stage_excluding_id(
        self, name: str, stage_id: int, exclude_unit_id: int
    ) -> bool:
        stmt = select(Unit).where(
            Unit.name == name, Unit.stage_id == stage_id, Unit.id != exclude_unit_id
        )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none() is not None

    async def get_cam_server_status_by_unit(
        self, unit_id: int
    ) -> List[Tuple[bool, bool]]:
        """
        查詢指定 Unit 下所有 Cam 與 Server 的狀態。

        Returns:
            List[Tuple[cam_online: bool, server_online: bool]]
        """
        stmt = (
            select(Cam.status.label("cam_online"), Server.status.label("server_online"))
            .join(UnitCam, UnitCam.cam_id == Cam.id)
            .join(Server, Server.id == Cam.server_id)
            .where(UnitCam.unit_id == unit_id)
        )
        result = await self.db.execute(stmt)
        return result.all()

    async def get_server_status_bulk(self, unit_ids: Sequence[int]) -> Dict[int, Dict]:
        # 先算狀態
        cam_off = func.coalesce(
            func.sum(case((Cam.status == False, 1), else_=0)), 0
        ).label("cam_off")
        srv_off = func.coalesce(
            func.sum(case((Server.status == False, 1), else_=0)), 0
        ).label("srv_off")
        cam_cnt = func.count(Cam.id).label("cam_cnt")

        status_stmt = (
            select(
                Unit.id.label("unit_id"),
                cam_cnt,
                cam_off,
                srv_off,
            )
            .select_from(Unit)
            .outerjoin(UnitCam, UnitCam.unit_id == Unit.id)
            .outerjoin(Cam, Cam.id == UnitCam.cam_id)
            .outerjoin(Server, Server.id == Cam.server_id)
            .where(Unit.id.in_(unit_ids))
            .group_by(Unit.id)
        )
        status_rows = (await self.db.execute(status_stmt)).all()
        status_map = {
            row.unit_id: (row.cam_cnt > 0 and row.cam_off == 0 and row.srv_off == 0)
            for row in status_rows
        }

        # 再查 Unit + 關聯
        units_stmt = (
            select(Unit)
            .options(
                selectinload(Unit.stage).selectinload(Stage.fab),
                selectinload(Unit.stage).selectinload(Stage.department),
                selectinload(Unit.cams),
            )
            .where(Unit.id.in_(unit_ids))
        )
        units = (await self.db.execute(units_stmt)).scalars().all()

        # 回傳成 {unit_id: {...完整資料...}}，保留關聯
        return {
            u.id: {
                "id": u.id,
                "name": u.name,
                "stage": u.stage,
                "cams": u.cams,
                "status": status_map.get(u.id, False),
            }
            for u in units
        }

    async def get_by_server_cam(
        self, *, server_ip: str, cam_ip: str, cam_port: int
    ) -> Optional[Unit]:
        stmt = (
            select(Unit)
            .join(Unit.cams)
            .join(Cam.server)
            .where(
                and_(
                    Server.ip == server_ip,
                    Cam.ip == server_ip,
                    Cam.port == cam_port,
                )
            )
        )
        result = await self.db.execute(stmt)
        units = result.scalars().all()
        if len(units) == 1:
            return units[0]
        if len(units) == 0:
            return None

        # 多筆表示資料異常
        raise
