from abc import ABC, abstractmethod
from typing import Any, Optional, List, Tuple, Dict, Literal
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from src.database.models.user import User
from src.utils.pagination import paginate
from src.utils.logger import get_logger

logger = get_logger(__name__)


class IUserRepository(ABC):
    @abstractmethod
    async def get_by_id(self, user_id: str) -> Optional[User]:
        ...

    @abstractmethod
    async def get_by_username(self, username: str) -> Optional[User]:
        ...

    @abstractmethod
    async def get_by_email(self, email: str) -> Optional[User]:
        ...

    @abstractmethod
    async def get_multi(self, filters: Dict = {}) -> List[User]:
        ...

    @abstractmethod
    async def get_paginated_multi(
        self,
        filters: List[Any],
        page: int,
        limit: int,
        sort_field: str,
        sort_order: Literal["asc", "desc"],
    ) -> Tuple[List[User], Dict[str, Any]]:
        ...

    @abstractmethod
    async def add(self, user: User) -> User:
        ...

    @abstractmethod
    async def update(self, user_id: str, fields: dict) -> Optional[User]:
        ...

    @abstractmethod
    async def update_user_role(self, user_id: str, new_role: str) -> User:
        ...


class UserRepository(IUserRepository):
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_id(self, user_id: str) -> Optional[User]:
        return await self.db.get(User, user_id)

    async def get_by_username(self, username: str) -> Optional[User]:
        stmt = select(User).filter_by(username=username)
        res = await self.db.execute(stmt)
        return res.scalars().first()

    async def get_by_email(self, email: str) -> Optional[User]:
        stmt = select(User).filter_by(email=email)
        res = await self.db.execute(stmt)
        return res.scalars().first()

    async def get_multi(self, filters: Dict = {}) -> List[User]:
        stmt = select(User).filter_by(**filters)
        res = await self.db.execute(stmt)
        return res.scalars().all()

    async def get_paginated_multi(
        self,
        filters: List[Any],
        page: int,
        limit: int,
        sort_field: str,
        sort_order: Literal["asc", "desc"],
    ) -> Tuple[List[User], Dict[str, Any]]:
        return await paginate(
            self.db, User, filters, page, limit, sort_field, sort_order
        )

    async def add(self, user: User) -> User:
        self.db.add(user)
        await self.db.flush()
        await self.db.refresh(user)
        return user

    async def update(self, user_id: str, fields: dict) -> Optional[User]:
        user = await self.get_by_id(user_id)
        if not user:
            return None
        try:
            logger.debug(
                "UserRepository.update: user_id=%s, fields_type=%s, keys=%s",
                user_id,
                type(fields).__name__,
                list(fields.keys()) if hasattr(fields, "keys") else "N/A",
            )
        except Exception:
            pass
        for k, v in fields.items():
            setattr(user, k, v)
        await self.db.flush()
        await self.db.refresh(user)
        return user

    async def update_user_role(self, user_id: str, new_role: str) -> User:
        user = await self.get_by_id(user_id)
        if not user:
            raise ValueError("User not found")
        user.role = new_role
        await self.db.flush()
        await self.db.refresh(user)
        return user
