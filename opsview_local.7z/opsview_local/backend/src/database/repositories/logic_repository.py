from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, case

from src.database.models.logic import Logic


class ILogicRepository(ABC):
    @abstractmethod
    async def get_by_id(self, logic_id: int) -> Optional[Logic]:
        ...

    @abstractmethod
    async def get_by_unit_id(self, unit_id: int) -> List[Logic]:
        ...

    @abstractmethod
    async def get_multi(
        self,
        filters: Dict[str, Any] = None,
        eager_options: List[Any] = None,
    ) -> List[Logic]:
        ...

    @abstractmethod
    async def get_one(
        self, filters: List[Any], eager_options: List[Any] = None
    ) -> Optional[Logic]:
        ...

    @abstractmethod
    async def add(self, logic: Logic) -> Logic:
        ...

    @abstractmethod
    async def update(self, logic_id: int, fields: Dict[str, Any]) -> Optional[Logic]:
        ...

    @abstractmethod
    async def delete(self, logic_id: int) -> None:
        ...

    @abstractmethod
    async def delete_by_unit_id(self, unit_id: int) -> None:
        ...


class LogicRepository(ILogicRepository):
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_id(self, logic_id: int) -> Optional[Logic]:
        return await self.db.get(Logic, logic_id)

    async def get_by_unit_id(self, unit_id: int) -> List[Logic]:
        stmt = select(Logic).where(
            and_(Logic.unit_id == unit_id, Logic.state != "Cycle Start")
        )
        result = await self.db.execute(stmt)
        return result.scalars().all()

    async def get_multi(
        self,
        filters: Dict[str, Any] = None,
        eager_options: List[Any] = None,
    ) -> List[Logic]:
        filters = filters or {}
        eager_options = eager_options or []

        # 排序優先權：
        # Cycle Start -> OP Idle -> EQ Idle -> 其他（維持預設次序，以 id asc 穩定輸出）
        state_priority = case(
            (Logic.state == "Cycle Start", 0),
            (Logic.state == "OP Idle", 1),
            (Logic.state == "EQ Idle", 2),
            else_=99,
        )

        stmt = (
            select(Logic)
            .filter_by(**filters)
            .options(*eager_options)
            .order_by(state_priority, Logic.id.asc())
        )
        res = await self.db.execute(stmt)
        return res.scalars().all()

    async def get_one(
        self, filters: List[Any], eager_options: List[Any] = None
    ) -> Optional[Logic]:
        """
        根據多種條件篩選 Logic 並返回單一結果。
        :param filters: 要篩選的條件列表，例如 [Logic.id == 1, Logic.state == "active"]
        :param eager_options: 要附加的 eager loading 選項，例如 [subqueryload(Logic.related_field)]
        :return: 單一 Logic 或 None
        """
        # 構建查詢語句，並應用篩選條件
        stmt = select(Logic).where(and_(*filters))

        # 如果有 eager loading 選項，則附加到查詢語句
        if eager_options:
            stmt = stmt.options(*eager_options)

        # 執行查詢
        res = await self.db.execute(stmt)
        return res.scalar_one_or_none()

    async def add(self, logic: Logic) -> Logic:
        self.db.add(logic)
        await self.db.flush()
        await self.db.refresh(logic)
        return logic

    async def update(self, logic_id: int, fields: Dict[str, Any]) -> Optional[Logic]:
        logic = await self.get_by_id(logic_id)
        if not logic:
            return None
        for k, v in fields.items():
            setattr(logic, k, v)
        await self.db.flush()
        await self.db.refresh(logic)
        return logic

    async def delete(self, logic_id: int) -> None:
        await self.db.delete(await self.get_by_id(logic_id))

    async def delete_by_unit_id(self, unit_id: int) -> None:
        await self.db.execute(select(Logic).where(Logic.unit_id == unit_id).delete())
