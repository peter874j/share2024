from abc import ABC, abstractmethod
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime
from typing import Optional

from src.database.models.report_item import ReportItem


class IReportItemRepository(ABC):
    @abstractmethod
    async def create(self, *, unit_id: int, data: dict) -> ReportItem:
        ...

    @abstractmethod
    async def get_by_report_and_cst(
        self, report_id: int, cycle_start_time: datetime
    ) -> Optional[ReportItem]:
        ...


class ReportItemRepository(IReportItemRepository):
    """資料存取層：只負責 CRUD 與 flush，不做 commit，不含業務規則。"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, report_item: ReportItem) -> ReportItem:
        self.db.add(report_item)
        await self.db.flush()
        await self.db.refresh(report_item)
        return report_item

    async def get_by_report_and_cst(
        self, report_id: int, cycle_start_time: datetime
    ) -> Optional[ReportItem]:
        stmt = (
            select(ReportItem)
            .options(selectinload(ReportItem.report))
            .where(
                ReportItem.report_id == report_id,
                ReportItem.cycle_start_time == cycle_start_time,
            )
        )
        res = await self.db.execute(stmt)
        return res.scalars().first()
