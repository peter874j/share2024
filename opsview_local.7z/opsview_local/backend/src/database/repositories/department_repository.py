from abc import ABC, abstractmethod
from typing import Any, Optional, List, Tuple, Dict, Literal
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from src.database.models.department import Department
from src.utils.pagination import paginate


class IDepartmentRepository(ABC):
    @abstractmethod
    async def get_by_id(self, department_id: int) -> Optional[Department]:
        ...

    @abstractmethod
    async def get_by_name(self, name: str) -> Optional[Department]:
        ...

    @abstractmethod
    async def get_by_fab_id_and_name(
        self, fab_id: int, name: str
    ) -> Optional[Department]:
        ...

    @abstractmethod
    async def get_multi(self, filters: Dict = {}) -> List[Department]:
        ...

    @abstractmethod
    async def get_paginated_multi(
        self,
        filters: List[Any],
        page: int,
        limit: int,
        sort_field: str,
        sort_order: Literal["asc", "desc"],
    ) -> Tuple[List[Department], Dict[str, Any]]:
        ...

    @abstractmethod
    async def add(self, department: Department) -> Department:
        ...

    @abstractmethod
    async def update(self, department_id: int, fields: dict) -> Optional[Department]:
        ...


class DepartmentRepository(IDepartmentRepository):
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_id(self, department_id: int) -> Optional[Department]:
        return await self.db.get(Department, department_id)

    async def get_by_name(self, name: str) -> Optional[Department]:
        stmt = select(Department).filter_by(name=name)
        res = await self.db.execute(stmt)
        return res.scalars().first()

    async def get_by_fab_id_and_name(
        self, fab_id: int, name: str
    ) -> Optional[Department]:
        stmt = select(Department).filter_by(name=name, fab_id=fab_id)
        res = await self.db.execute(stmt)
        return res.scalars().first()

    async def get_multi(self, filters: Dict = {}) -> List[Department]:
        stmt = select(Department).filter_by(**filters)
        res = await self.db.execute(stmt)
        return res.scalars().all()

    async def get_paginated_multi(
        self,
        filters: List[Any],
        page: int,
        limit: int,
        sort_field: str,
        sort_order: Literal["asc", "desc"],
    ) -> Tuple[List[Department], Dict[str, Any]]:
        return await paginate(
            self.db, Department, filters, page, limit, sort_field, sort_order
        )

    async def add(self, department: Department) -> Department:
        self.db.add(department)
        await self.db.flush()
        await self.db.refresh(department)
        return department

    async def update(self, department_id: int, fields: dict) -> Optional[Department]:
        department = await self.get_by_id(department_id)
        if not department:
            return None
        for k, v in fields.items():
            setattr(department, k, v)
        await self.db.flush()
        await self.db.refresh(department)
        return department
