from abc import ABC, abstractmethod
from typing import Iterable, Optional, List, Tuple
from sqlalchemy import select, and_, delete
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from src.database.models.server import Server
from src.database.models.cam import Cam
from src.database.models.unit import Unit
from src.database.models.stage import Stage
from src.database.models.unit_cam import UnitCam
from src.database.models.object import Object
from src.database.models.fence import Fence
from src.database.models.logic import Logic
from src.database.models.condition import Condition
from src.database.models.condition_object import ConditionObject


class ICamRepository(ABC):
    @abstractmethod
    async def get_cam_by_id(self, cam_id: int) -> Optional[Cam]:
        ...

    @abstractmethod
    async def get_cam_with_units(self, cam_id: int) -> Optional[Cam]:
        ...

    @abstractmethod
    async def get_cam_with_server_fab(self, cam_id: int) -> Optional[Cam]:
        ...

    @abstractmethod
    async def list_cams(
        self,
        fab_id: Optional[int] = None,
        stage_id: Optional[int] = None,
        unit_ids: Optional[List[int]] = None,
    ) -> List[Cam]:
        ...

    @abstractmethod
    async def list_cams_with_unit_name(
        self,
        fab_id: Optional[int] = None,
        stage_id: Optional[int] = None,
        unit_ids: Optional[List[int]] = None,
    ) -> List[Tuple[Cam, Optional[str]]]:
        ...

    # ---------- Entities lookups ----------
    @abstractmethod
    async def get_stage(self, stage_id: int) -> Optional[Stage]:
        ...

    @abstractmethod
    async def get_unit(self, unit_id: int) -> Optional[Unit]:
        ...

    @abstractmethod
    async def get_server(self, server_id: int) -> Optional[Server]:
        ...

    @abstractmethod
    async def get_unit_by_cam_id(self, cam_id: int) -> Optional[Unit]:
        ...

    @abstractmethod
    async def list_cams_in_unit(self, unit_id: int) -> List[Cam]:
        ...

    # ---------- Create / Update / Link ----------
    @abstractmethod
    async def add_cam(self, cam: Cam) -> Cam:
        ...

    @abstractmethod
    async def add_unit_cam(self, cam_id: int, unit_id: int) -> UnitCam:
        ...

    @abstractmethod
    async def get_unit_cam_by_unit_id(self, unit_id: int) -> Optional[UnitCam]:
        ...

    @abstractmethod
    async def get_unit_cam_by_cam_id(self, cam_id: int) -> Optional[UnitCam]:
        ...

    @abstractmethod
    async def delete_unit_cam_by_cam_id(self, cam_id: int) -> None:
        ...

    @abstractmethod
    async def delete_cam(self, cam: Cam) -> None:
        ...

    @abstractmethod
    async def flush(self) -> None:
        ...

    # ---------- Vision config write helpers ----------
    @abstractmethod
    async def find_object_by_name_unit(
        self, name: str, unit_id: int
    ) -> Optional[Object]:
        ...

    @abstractmethod
    async def add_object(self, obj: Object) -> Object:
        ...

    @abstractmethod
    async def add_fence(self, fence: Fence) -> Fence:
        ...

    @abstractmethod
    async def add_logic(self, logic: Logic) -> Logic:
        ...

    @abstractmethod
    async def list_objects_by_unit(self, unit_id: int) -> List[Object]:
        ...

    @abstractmethod
    async def list_fences_by_unit(self, unit_id: int) -> List[Fence]:
        ...

    @abstractmethod
    async def add_condition(self, condition: Condition) -> Condition:
        ...

    @abstractmethod
    async def add_condition_object(
        self, condition_object: ConditionObject
    ) -> ConditionObject:
        ...

    @abstractmethod
    async def list_by_server(self, server_id: int) -> List[Cam]:
        ...

    @abstractmethod
    async def add_many(self, cams: Iterable[Cam]) -> None:
        ...

    @abstractmethod
    async def update_status(self, cam: Cam, status: bool) -> Cam:
        ...

    @abstractmethod
    async def bulk_set_status_by_server(self, server: Server, status: bool) -> None:
        ...

    @abstractmethod
    async def add(self, cam: Cam) -> Cam:
        ...


class CamRepository(ICamRepository):
    def __init__(self, db: AsyncSession):
        self.db = db

    # ---------- Core CAM reads ----------
    async def get_cam_by_id(self, cam_id: int) -> Optional[Cam]:
        return await self.db.get(Cam, cam_id)

    async def get_cam_with_units(self, cam_id: int) -> Optional[Cam]:
        result = await self.db.execute(
            select(Cam).options(selectinload(Cam.units)).where(Cam.id == cam_id)
        )
        return result.scalar_one_or_none()

    async def get_cam_with_server_fab(self, cam_id: int) -> Optional[Cam]:
        result = await self.db.execute(
            select(Cam)
            .options(selectinload(Cam.server).selectinload(Server.fab))
            .where(Cam.id == cam_id)
        )
        return result.scalar_one_or_none()

    async def list_cams(
        self,
        fab_id: Optional[int] = None,
        stage_id: Optional[int] = None,
        unit_ids: Optional[List[int]] = None,
    ) -> List[Cam]:
        stmt = (
            select(Cam)
            .options(
                selectinload(Cam.unit_cams)
                .selectinload(UnitCam.unit)
                .selectinload(Unit.stage)
                .selectinload(Stage.fab),
                selectinload(Cam.server),
            )
            .outerjoin(Cam.unit_cams)
            .outerjoin(UnitCam.unit)
            .outerjoin(Unit.stage)
            .outerjoin(Stage.fab)
        )

        filters = []
        if fab_id is not None:
            filters.append(Stage.fab_id == fab_id)
        if stage_id is not None:
            filters.append(Unit.stage_id == stage_id)
        if unit_ids:
            filters.append(Cam.unit_cams.has(UnitCam.unit.has(Unit.id.in_(unit_ids))))
        if filters:
            stmt = stmt.where(and_(*filters))

        return (await self.db.execute(stmt)).scalars().all()

    async def list_cams_with_unit_name(
        self,
        fab_id: Optional[int] = None,
        stage_id: Optional[int] = None,
        unit_ids: Optional[List[int]] = None,
    ) -> List[Tuple[Cam, Optional[str]]]:
        stmt = (
            select(Cam, Unit.name.label("unit_name"))
            .options(
                selectinload(Cam.unit_cams)
                .selectinload(UnitCam.unit)
                .selectinload(Unit.stage)
                .selectinload(Stage.fab),
                selectinload(Cam.server),
            )
            .outerjoin(Cam.unit_cams)
            .outerjoin(UnitCam.unit)
            .outerjoin(Unit.stage)
            .outerjoin(Stage.fab)
        )

        filters = []
        if fab_id is not None:
            filters.append(Stage.fab_id == fab_id)
        if stage_id is not None:
            filters.append(Unit.stage_id == stage_id)
        if unit_ids:
            filters.append(Cam.unit_cams.has(UnitCam.unit.has(Unit.id.in_(unit_ids))))
        if filters:
            stmt = stmt.where(and_(*filters))

        return (await self.db.execute(stmt)).all()

    # ---------- Entities lookups ----------
    async def get_stage(self, stage_id: int) -> Optional[Stage]:
        return await self.db.get(Stage, stage_id)

    async def get_unit(self, unit_id: int) -> Optional[Unit]:
        return await self.db.get(Unit, unit_id)

    async def get_server(self, server_id: int) -> Optional[Server]:
        return await self.db.get(Server, server_id)

    async def get_unit_by_cam_id(self, cam_id: int) -> Optional[Unit]:
        unit_res = await self.db.execute(
            select(Unit)
            .join(UnitCam, Unit.id == UnitCam.unit_id)
            .where(UnitCam.cam_id == cam_id)
        )
        return unit_res.scalar_one_or_none()

    async def list_cams_in_unit(self, unit_id: int) -> List[Cam]:
        return (
            (
                await self.db.execute(
                    select(Cam)
                    .join(UnitCam, Cam.id == UnitCam.cam_id)
                    .where(UnitCam.unit_id == unit_id)
                )
            )
            .scalars()
            .all()
        )

    # ---------- Create / Update / Link ----------
    async def add_cam(self, cam: Cam) -> Cam:
        self.db.add(cam)
        await self.db.flush()
        return cam

    async def add_unit_cam(self, cam_id: int, unit_id: int) -> UnitCam:
        link = UnitCam(cam_id=cam_id, unit_id=unit_id)
        self.db.add(link)
        await self.db.flush()
        return link

    async def get_unit_cam_by_unit_id(self, unit_id: int) -> Optional[UnitCam]:
        row = await self.db.execute(select(UnitCam).where(UnitCam.unit_id == unit_id))
        return row.scalar_one_or_none()

    async def get_unit_cam_by_cam_id(self, cam_id: int) -> Optional[UnitCam]:
        row = await self.db.execute(select(UnitCam).where(UnitCam.cam_id == cam_id))
        return row.scalar_one_or_none()

    async def delete_unit_cam_by_cam_id(self, cam_id: int) -> None:
        await self.db.execute(delete(UnitCam).where(UnitCam.cam_id == cam_id))

    async def delete_cam(self, cam: Cam) -> None:
        await self.db.delete(cam)

    async def flush(self) -> None:
        await self.db.flush()

    # ---------- Vision config write helpers ----------
    async def find_object_by_name_unit(
        self, name: str, unit_id: int
    ) -> Optional[Object]:
        stmt = select(Object).where(Object.name == name, Object.unit_id == unit_id)
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()

    async def add_object(self, obj: Object) -> Object:
        self.db.add(obj)
        await self.db.flush()
        return obj

    async def add_fence(self, fence: Fence) -> Fence:
        self.db.add(fence)
        await self.db.flush()
        return fence

    async def add_logic(self, logic: Logic) -> Logic:
        self.db.add(logic)
        await self.db.flush()
        return logic

    async def list_objects_by_unit(self, unit_id: int) -> List[Object]:
        return (
            (await self.db.execute(select(Object).where(Object.unit_id == unit_id)))
            .scalars()
            .all()
        )

    async def list_fences_by_unit(self, unit_id: int) -> List[Fence]:
        return (
            (await self.db.execute(select(Fence).where(Fence.unit_id == unit_id)))
            .scalars()
            .all()
        )

    async def add_condition(self, condition: Condition) -> Condition:
        self.db.add(condition)
        await self.db.flush()
        return condition

    async def add_condition_object(
        self, condition_object: ConditionObject
    ) -> ConditionObject:
        self.db.add(condition_object)
        await self.db.flush()
        return condition_object

    async def list_by_server(self, server_id: int) -> List[Cam]:
        result = await self.db.execute(select(Cam).where(Cam.server_id == server_id))
        return list(result.scalars().all())

    async def add_many(self, cams: Iterable[Cam]) -> None:
        for c in cams:
            self.db.add(c)
        await self.db.flush()

    async def update_status(self, cam: Cam, status: bool) -> Cam:
        cam.status = status
        self.db.add(cam)
        await self.db.flush()
        return cam

    async def bulk_set_status_by_server(self, server: Server, status: bool) -> None:
        # 若 server.cams 未載入，則查詢以避免 N+1/None
        cams = list(getattr(server, "cams", []) or [])
        if not cams:
            cams = await self.list_by_server(server.id)
        for cam in cams:
            cam.status = status
            self.db.add(cam)
        await self.db.flush()

    async def add(self, cam: Cam) -> Cam:
        return await self.add_cam(cam)
