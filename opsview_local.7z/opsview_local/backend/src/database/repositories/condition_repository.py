from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple, Literal
from sqlalchemy import select, delete, insert
from sqlalchemy.orm import joinedload, subqueryload
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.models.fence import Fence
from src.database.models.condition import Condition
from src.database.models.condition_object import ConditionObject
from src.utils.pagination import paginate


class IConditionRepository(ABC):
    @abstractmethod
    async def get_by_id(self, condition_id: int) -> Optional[Condition]:
        ...

    @abstractmethod
    async def get_by_unit_id(self, unit_id: int) -> List[Condition]:
        ...

    @abstractmethod
    async def get_multi(
        self,
        filters: Dict[str, Any] = None,
        eager_options: List[Any] = None,
    ) -> List[Condition]:
        ...

    @abstractmethod
    async def get_one(
        self, condition_id: int, eager_options: List[Any] = None
    ) -> Optional[Condition]:
        ...

    @abstractmethod
    async def add(self, condition: Condition) -> Condition:
        ...

    @abstractmethod
    async def update(
        self, condition_id: int, fields: Dict[str, Any]
    ) -> Optional[Condition]:
        ...

    @abstractmethod
    async def bulk_add(self, condition_objects: List[ConditionObject]) -> None:
        ...

    @abstractmethod
    async def update_condition_objects(
        self, condition_id: int, to_add: set, to_remove: set
    ) -> None:
        ...

    @abstractmethod
    async def validate_object_ids(self, object_ids: List[int]) -> List[Tuple[int]]:
        ...

    @abstractmethod
    async def paginate_multi(
        self,
        filters: List[Any],
        page: int,
        limit: int,
        sort_field: str,
        sort_order: Literal["asc", "desc"],
    ) -> Tuple[List[Condition], Dict[str, Any]]:
        ...

    @abstractmethod
    async def delete(self, condition_id: int) -> None:
        ...

    @abstractmethod
    async def delete_by_unit_id(self, unit_id: int) -> None:
        ...


class ConditionRepository(IConditionRepository):
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_id(self, condition_id: int) -> Optional[Condition]:
        return await self.db.get(Condition, condition_id)

    async def get_by_unit_id(self, unit_id: int) -> List[Condition]:
        """
        根據 unit_id 獲取所有相關的 Condition，並一次載入所有關聯，避免 N+1 問題。
        """
        stmt = (
            select(Condition)
            .join(Fence, Fence.id == Condition.fence_id)
            .options(
                subqueryload(Condition.condition_objects).subqueryload(
                    ConditionObject.object
                ),
            )
            .where(Fence.unit_id == unit_id)
        )

        result = await self.db.execute(stmt)
        return result.scalars().all()

    async def get_multi(
        self,
        filters: Dict[str, Any] = None,
        eager_options: List[Any] = None,
    ) -> List[Condition]:
        filters = filters or {}
        eager_options = eager_options or []
        stmt = select(Condition).filter_by(**filters).options(*eager_options)
        res = await self.db.execute(stmt)
        return res.scalars().all()

    async def get_one(
        self, condition_id: int, eager_options: List[Any] = None
    ) -> Optional[Condition]:
        stmt = select(Condition).filter_by(id=condition_id).options(*eager_options)
        res = await self.db.execute(stmt)
        return res.scalar_one_or_none()

    async def add(self, condition: Condition) -> Condition:
        self.db.add(condition)
        await self.db.flush()
        await self.db.refresh(condition)
        return condition

    async def update(
        self, condition_id: int, fields: Dict[str, Any]
    ) -> Optional[Condition]:
        condition = await self.get_by_id(condition_id)
        if not condition:
            return None
        for k, v in fields.items():
            setattr(condition, k, v)
        await self.db.flush()
        await self.db.refresh(condition)
        return condition

    async def bulk_add(self, condition_objects: List[ConditionObject]) -> None:
        self.db.add_all(condition_objects)
        await self.db.flush()

    async def update_condition_objects(
        self, condition_id: int, to_add: set, to_remove: set
    ) -> None:
        if to_remove:
            await self.db.execute(
                delete(ConditionObject).where(
                    ConditionObject.condition_id == condition_id,
                    ConditionObject.object_id.in_(to_remove),
                )
            )
        if to_add:
            await self.db.execute(
                insert(ConditionObject),
                [
                    {"condition_id": condition_id, "object_id": obj_id}
                    for obj_id in to_add
                ],
            )

    async def validate_object_ids(self, object_ids: List[int]) -> List[Tuple[int]]:
        stmt = select(ConditionObject.object_id).where(
            ConditionObject.object_id.in_(object_ids)
        )
        res = await self.db.execute(stmt)
        return res.fetchall()

    async def paginate_multi(
        self,
        filters: List[Any],
        page: int,
        limit: int,
        sort_field: str,
        sort_order: Literal["asc", "desc"],
    ) -> Tuple[List[Condition], Dict[str, Any]]:
        return await paginate(
            self.db, Condition, filters, page, limit, sort_field, sort_order
        )

    async def delete(self, condition_id: int) -> None:
        await self.db.delete(await self.get_by_id(condition_id))

    async def delete_by_unit_id(self, unit_id: int) -> None:
        # 清空 ConditionObject 中介表
        await self.db.execute(
            select(ConditionObject)
            .where(
                ConditionObject.condition_id.in_(
                    select(Condition.id).where(Condition.unit_id == unit_id)
                )
            )
            .delete()
        )

        # 清空 Condition
        await self.db.execute(
            select(Condition).where(Condition.unit_id == unit_id).delete()
        )
