from abc import ABC, abstractmethod
from typing import Any, Optional, List, Tuple, Dict, Literal
from sqlalchemy import select, func, case
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.models.stage import Stage
from src.database.models.unit import Unit
from src.database.schemas.unit import UnitImportStatus
from src.database.models.fab import Fab
from src.utils.pagination import paginate


class IFabRepository(ABC):
    @abstractmethod
    async def get_by_id(self, fab_id: int) -> Optional[Fab]:
        ...

    @abstractmethod
    async def get_by_name(self, name: str) -> Optional[Fab]:
        ...

    @abstractmethod
    async def get_multi(self, filters: Dict = {}) -> List[Fab]:
        ...

    @abstractmethod
    async def get_paginated_multi(
        self,
        filters: List[Any],
        page: int,
        limit: int,
        sort_field: str,
        sort_order: Literal["asc", "desc"],
    ) -> Tuple[List[Fab], Dict[str, Any]]:
        ...

    @abstractmethod
    async def add(self, fab: Fab) -> Fab:
        ...

    @abstractmethod
    async def update(self, fab_id: int, fields: dict) -> Optional[Fab]:
        ...

    @abstractmethod
    async def get_fab_import_stats(self):
        ...


class FabRepository(IFabRepository):
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_id(self, fab_id: int) -> Optional[Fab]:
        return await self.db.get(Fab, fab_id)

    async def get_by_name(self, name: str) -> Optional[Fab]:
        stmt = select(Fab).filter_by(name=name)
        res = await self.db.execute(stmt)
        return res.scalars().first()

    async def get_multi(self, filters: Dict = {}) -> List[Fab]:
        stmt = select(Fab).filter_by(**filters)
        res = await self.db.execute(stmt)
        return res.scalars().all()

    async def get_paginated_multi(
        self,
        filters: List[Any],
        page: int,
        limit: int,
        sort_field: str,
        sort_order: Literal["asc", "desc"],
    ) -> Tuple[List[Fab], Dict[str, Any]]:
        return await paginate(
            self.db, Fab, filters, page, limit, sort_field, sort_order
        )

    async def add(self, fab: Fab) -> Fab:
        self.db.add(fab)
        await self.db.flush()
        await self.db.refresh(fab)
        return fab

    async def update(self, fab_id: int, fields: dict) -> Optional[Fab]:
        fab = await self.get_by_id(fab_id)
        if not fab:
            return None
        for k, v in fields.items():
            setattr(fab, k, v)
        await self.db.flush()
        await self.db.refresh(fab)
        return fab

    async def get_fab_import_stats(self):
        """
        回傳每個 Fab 的：
        - fab_name
        - total_units
        - imported_units
        """
        stmt = (
            select(
                Fab.name.label("fab_name"),
                func.count(Unit.id).label("total_units"),
                func.count(
                    case((Unit.import_status == UnitImportStatus.IMPORTED.value, 1))
                ).label("imported_units"),
            )
            .join(Stage, Stage.fab_id == Fab.id)
            .join(Unit, Unit.stage_id == Stage.id)
            .group_by(Fab.name)
        )

        result = await self.db.execute(stmt)
        # 回傳 Row 物件列表，支援 row.fab_name / row.total_units / row.imported_units 屬性取值
        return result.all()
