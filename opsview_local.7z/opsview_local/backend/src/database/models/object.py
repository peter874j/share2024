from sqlalchemy import Column, String, DateTime, Integer, func, ForeignKey
from sqlalchemy.orm import relationship
from ..session import Base


class Object(Base):
    __tablename__ = "objects"
    # 定義資料庫中的表名稱為 "objects"

    id = Column(Integer, primary_key=True, autoincrement=True, nullable=False)
    # 定義主鍵 id，整數類型，自動遞增，不能為空

    name = Column(String, nullable=False)
    # 定義名稱欄位，字串類型，不能為空

    created_at = Column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    # 定義建立時間欄位，帶時區的日期時間類型，預設為當前時間，不能為空

    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
    # 定義更新時間欄位，帶時區的日期時間類型，更新時自動更新為當前時間，不能為空

    deleted_at = Column(DateTime(timezone=True), nullable=True)
    # 定義刪除時間欄位，帶時區的日期時間類型，允許為空

    unit_id = Column(Integer, ForeignKey("unit.id"))
    # 定義外鍵關聯，關聯到 unit 表的 id 欄位，不能為空

    unit = relationship("Unit", back_populates="objects")
    # 定義與 Unit 模型的關聯

    condition_object = relationship(
        "ConditionObject",
        back_populates="object",
        cascade="all, delete-orphan",
    )
    # 定義與 ConditionObject 模型的一對一關係，使用 back_populates 參數實現雙向關聯，uselist=False 表示一對一

    condition = relationship(
        "Condition",
        secondary="condition_object",
        back_populates="objects",
        viewonly=True,
    )
    # 定義與 Condition 模型的雙向關聯
    # 使用 secondary 參數指定多對多關聯模型 "condition_objects"
    # uselist=False 表示這是一對一關係
    # viewonly=True 表示此關聯僅供查詢，不可修改
