from sqlalchemy import Column, String, DateTime, Integer, func, ForeignKey
from sqlalchemy.orm import relationship
from ..session import Base


class Condition(Base):
    __tablename__ = "conditions"
    # 定義資料庫中的表名稱為 "conditions"

    id = Column(Integer, primary_key=True, autoincrement=True, nullable=False)
    # 定義主鍵 id，整數類型，自動遞增，不能為空

    type = Column(String, nullable=False)
    # 定義類型欄位，字串類型，不能為空

    name = Column(String, nullable=False)
    # 定義名稱欄位，字串類型，不能為空

    created_at = Column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    # 定義建立時間欄位，帶時區的日期時間類型，預設為當前時間，不能為空

    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
    # 定義更新時間欄位，帶時區的日期時間類型，更新時自動更新為當前時間，不能為空

    deleted_at = Column(DateTime(timezone=True), nullable=True)
    # 定義刪除時間欄位，帶時區的日期時間類型，允許為空

    unit_id = Column(Integer, ForeignKey("unit.id"), nullable=False)
    # 定義外鍵關聯，關聯到 unit 表的 id 欄位，不能為空

    fence_id = Column(Integer, ForeignKey("fences.id"), nullable=True)
    # 定義外鍵關聯，關聯到 fence 表的 id 欄位，不能為空

    unit = relationship("Unit", back_populates="conditions")
    # 定義與 Unit 模型的關聯

    fence = relationship("Fence", back_populates="conditions")
    # 定義與 Fence 模型的關聯

    condition_objects = relationship(
        "ConditionObject", back_populates="condition", cascade="all, delete-orphan"
    )
    # 定義與 ConditionObject 模型的一對多關聯，當 Condition 被刪除時，相關的 ConditionObject 也會被刪除

    objects = relationship(
        "Object",
        secondary="condition_object",
        back_populates="condition",
        viewonly=True,
    )
    # 定義與 Object 模型的多對多關聯，通過 condition_object 關聯表，viewonly=True 表示僅用於
