from sqlalchemy import Column, String, DateTime, func
from ..session import Base


class User(Base):
    __tablename__ = "user"
    # 定義資料庫中的表名稱為 "user"

    id = Column(String, primary_key=True, nullable=False)
    # 定義主鍵 id，字串類型，不能為空
    username = Column(String, nullable=False)
    # 定義使用者名稱欄位，字串類型，不能為空
    fullname = Column(String, nullable=False)
    # 定義全名欄位，字串類型，不能為空
    email = Column(String, unique=True, nullable=False)
    # 定義電子郵件欄位，字串類型，必須唯一，不能為空
    deptno = Column(String, nullable=False)
    # 定義部門編號欄位，字串類型，不能為空
    location = Column(String, nullable=True)
    # 定義廠區欄位，字串類型，允許為空
    token = Column(String, nullable=True)
    # 定義令牌欄位，字串類型，允許為空
    role = Column(String, server_default="user", nullable=False)
    # 定義角色欄位，字串類型，預設為 "user"，不能為空
    access_key = Column(String, nullable=True)
    # 定義存取金鑰欄位，字串類型，允許為空
    secret_key = Column(String, nullable=True)
    # 定義密鑰欄位，字串類型，允許為空
    created_at = Column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    # 定義建立時間欄位，帶時區的日期時間類型，預設為當前時間，不能為空
    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
    # 定義更新時間欄位，帶時區的日期時間類型，更新時自動更新為當前時間
