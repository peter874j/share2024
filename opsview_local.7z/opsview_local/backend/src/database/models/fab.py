from sqlalchemy import Column, String, DateTime, Integer, func
from sqlalchemy.orm import relationship
from ..session import Base


class Fab(Base):
    __tablename__ = "fab"
    # 定義資料庫中的表名稱為 "fab"

    id = Column(Integer, primary_key=True, autoincrement=True, nullable=False)
    # 定義主鍵 id，整數類型，自動遞增，不能為空

    name = Column(String, nullable=False)
    # 定義名稱欄位，字串類型，不能為空

    created_at = Column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    # 定義建立時間欄位，帶時區的日期時間類型，預設為當前時間，不能為空

    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
    # 定義更新時間欄位，帶時區的日期時間類型，更新時自動更新為當前時間，不能為空

    deleted_at = Column(DateTime(timezone=True), nullable=True)
    # 定義刪除時間欄位，帶時區的日期時間類型，允許為空（表示未刪除）

    stages = relationship("Stage", back_populates="fab", cascade="all, delete-orphan")
    # 定義與 Stage 模型的一對多關聯，當 Fab 被刪除時，相關的 Stage 也會被刪除

    departments = relationship(
        "Department", back_populates="fab", cascade="all, delete-orphan"
    )
    # 定義與 Department 模型的一對多關聯，當 Fab 被刪除時，相關的 Department 也會被刪除

    server = relationship("Server", back_populates="fab", cascade="all, delete-orphan")
    # 定義與 Server 模型的一對多關聯，當 Fab 被刪除時，相關的 Stage 也會被刪除
