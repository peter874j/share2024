from sqlalchemy import ForeignKey, Column, String, DateTime, Integer, Boolean, func
from sqlalchemy.orm import relationship
from ..session import Base


class Server(Base):
    __tablename__ = "server"
    # 定義資料庫中的表名稱為 "server"

    id = Column(Integer, primary_key=True, autoincrement=True, nullable=False)
    # 定義主鍵 id，整數類型，自動遞增，不能為空

    name = Column(String, nullable=False)
    # 定義名稱欄位，字串類型，不能為空

    ip = Column(String, nullable=False)
    # 定義 IP 位址欄位，字串類型，不能為空

    description = Column(String, nullable=False)
    # 定義描述欄位，字串類型，不能為空

    status = Column(Boolean, nullable=False)
    # 定義狀態欄位，布林類型，不能為空，表示伺服器是否啟用

    created_at = Column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    # 定義建立時間欄位，帶時區的日期時間類型，預設為當前時間，不能為空

    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
    # 定義更新時間欄位，帶時區的日期時間類型，更新時自動更新為當前時間，不能為空

    deleted_at = Column(DateTime(timezone=True), nullable=True)
    # 定義刪除時間欄位，帶時區的日期時間類型，允許為空

    cams = relationship("Cam", back_populates="server", cascade="all, delete-orphan")
    # 定義與 Cam 模型的一對多關聯，當 Server 被刪除時，相關的 Cam 也會被刪除

    fab_id = Column(Integer, ForeignKey("fab.id"), nullable=False)
    # 定義外鍵關聯，關聯到 fab 表的 id 欄位，不能為空

    fab = relationship("Fab", back_populates="server")
    # 定義與 Fab 模型的關係，使用 back_populates 參數實現雙向關聯
