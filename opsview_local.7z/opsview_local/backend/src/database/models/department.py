from sqlalchemy import Column, ForeignKey, String, DateTime, Integer, func
from sqlalchemy.orm import relationship
from ..session import Base


class Department(Base):
    __tablename__ = "department"
    # 定義資料庫中的表名稱為 "department"

    id = Column(Integer, primary_key=True, autoincrement=True, nullable=False)
    # 定義主鍵 id，整數類型，自動遞增，不能為空

    name = Column(String, nullable=False)
    # 定義名稱欄位，字串類型，不能為空

    fab_id = Column(Integer, ForeignKey("fab.id"), nullable=False)
    # 定義 fab_id 欄位，整數類型，不能為空，外鍵關聯至 fab 表的 id 欄位

    created_at = Column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    # 定義 created_at 欄位，帶時區的日期時間類型，不能為空，預設為當前時間，表示建立時間
    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
    # 定義 updated_at 欄位，帶時區的日期時間類型，不能為空，預設為當前時間，更新時自動更新，表示最後更新時間
    deleted_at = Column(DateTime(timezone=True), nullable=True)
    # 定義 deleted_at 欄位，帶時區的日期時間類型，允許為空，表示刪除時間（軟刪除）

    fab = relationship("Fab", back_populates="departments")
    # 定義與 Fab 模型的關係，使用 back_populates 參數實現雙向關聯

    stages = relationship("Stage", back_populates="department")
    # 定義與 Stage 模型的關係，使用 back_populates 參數實現雙向關聯
