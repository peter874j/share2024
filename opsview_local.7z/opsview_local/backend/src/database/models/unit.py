from sqlalchemy import Column, String, DateTime, Integer, func, ForeignKey
from sqlalchemy.orm import relationship
from ..session import Base
from src.database.schemas.unit import UnitImportStatus


class Unit(Base):
    __tablename__ = "unit"
    # 定義資料庫中的表名稱為 "unit"

    id = Column(Integer, primary_key=True, autoincrement=True, nullable=False)
    # 定義主鍵 id，整數類型，自動遞增，不能為空

    name = Column(String, nullable=False)
    # 定義名稱欄位，字串類型，不能為空

    import_status = Column(
        String, server_default=UnitImportStatus.UNDO.value, nullable=False
    )
    # 定義導入狀態欄位，字串類型，預設為 undo，不能為空

    created_at = Column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    # 定義建立時間欄位，帶時區的日期時間類型，預設為當前時間，不能為空

    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
    # 定義更新時間欄位，帶時區的日期時間類型，更新時自動更新為當前時間，不能為空

    deleted_at = Column(DateTime(timezone=True), nullable=True)
    # 定義刪除時間欄位，帶時區的日期時間類型，允許為空

    stage_id = Column(Integer, ForeignKey("stage.id"), nullable=False)
    # 定義外鍵關聯，關聯到 stage 表的 id 欄位，不能為空

    stage = relationship("Stage", back_populates="units")
    # 定義與 Stage 模型的多對一關聯，單個 Unit 關聯到一個 Stage

    reports = relationship(
        "Report", back_populates="unit", cascade="all, delete-orphan"
    )
    # 定義與 Report 模型的一對多關聯，當 Unit 被刪除時，相關的 Report 也會被刪除

    unit_cams = relationship(
        "UnitCam", back_populates="unit", cascade="all, delete-orphan"
    )
    # 定義與 UnitCam 模型的一對多關聯，當 Unit 被刪除時，相關的 UnitCam 也會被刪除

    cams = relationship(
        "Cam", secondary="unit_cam", back_populates="units", viewonly=True
    )
    # 定義與 Cam 模型的多對多關聯，通過 unit_cam 關聯表，viewonly=True 表示僅用於

    objects = relationship(
        "Object", back_populates="unit", cascade="all, delete-orphan"
    )
    # 定義與 Object 模型的多對一關聯

    fences = relationship("Fence", back_populates="unit", cascade="all, delete-orphan")
    # 定義與 Fence 模型的多對一關聯

    conditions = relationship(
        "Condition", back_populates="unit", cascade="all, delete-orphan"
    )
    # 定義與 Condition 模型的多對一關聯

    logics = relationship("Logic", back_populates="unit", cascade="all, delete-orphan")
    # 定義與 Logic 模型的多對一關聯
