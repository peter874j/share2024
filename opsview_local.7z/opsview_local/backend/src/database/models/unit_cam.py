from sqlalchemy import Column, Integer, DateTime, func, ForeignKey, UniqueConstraint
from sqlalchemy.orm import relationship
from ..session import Base


class UnitCam(Base):
    __tablename__ = "unit_cam"
    # 定義資料庫中的表名稱為 "unit_cam"

    id = Column(Integer, primary_key=True, autoincrement=True, nullable=False)
    # 定義主鍵 id，整數類型，自動遞增，不能為空
    unit_id = Column(Integer, ForeignKey("unit.id"), nullable=False)
    # 定義外鍵關聯，關聯到 unit 表的 id 欄位，不能為空
    cam_id = Column(Integer, ForeignKey("cam.id"), nullable=False, unique=True)
    # 定義外鍵關聯，關聯到 cam 表的 id 欄位，不能為空，且必須唯一
    created_at = Column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    # 定義建立時間欄位，帶時區的日期時間類型，預設為當前時間，不能為空
    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
    # 定義更新時間欄位，帶時區的日期時間類型，更新時自動更新為當前時間，不能為空
    deleted_at = Column(DateTime(timezone=True), nullable=True)
    # 定義刪除時間欄位，帶時區的日期時間類型，允許為空

    __table_args__ = (UniqueConstraint("cam_id", name="uq_unit_cam_cam_id"),)
    # 定義表級別的唯一約束，確保 cam_id 在 unit_cam 表中是唯一的

    unit = relationship("Unit", back_populates="unit_cams")
    # 定義與 Unit 模型的多對一關聯，單個 UnitCam 關聯到一個 Unit

    cam = relationship("Cam", back_populates="unit_cams", uselist=False)
    # 定義與 Cam 模型的一對一關聯，單個 UnitCam 關聯到一個 Cam，uselist=False 表示一
