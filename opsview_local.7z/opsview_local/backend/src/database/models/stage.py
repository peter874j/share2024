from sqlalchemy import Column, String, DateTime, Integer, func, ForeignKey
from sqlalchemy.orm import relationship
from ..session import Base


class Stage(Base):
    __tablename__ = "stage"
    # 定義資料庫中的表名稱為 "stage"

    id = Column(Integer, primary_key=True, autoincrement=True, nullable=False)
    # 定義主鍵 id，整數類型，自動遞增，不能為空

    name = Column(String, nullable=False)
    # 定義名稱欄位，字串類型，不能為空

    created_at = Column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    # 定義建立時間欄位，帶時區的日期時間類型，預設為當前時間，不能為空

    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
    # 定義更新時間欄位，帶時區的日期時間類型，更新時自動更新為當前時間，不能為空

    deleted_at = Column(DateTime(timezone=True), nullable=True)
    # 定義刪除時間欄位，帶時區的日期時間類型，允許為空

    fab_id = Column(Integer, ForeignKey("fab.id"), nullable=False)
    # 定義外鍵關聯，關聯到 fab 表的 id 欄位，不能為空

    fab = relationship("Fab", back_populates="stages")
    # 定義與 Fab 模型的多對一關聯，單個 Stage 關聯到一個 Fab

    department_id = Column(Integer, ForeignKey("department.id"), nullable=False)
    # 定義外鍵關聯，關聯到 department 表的 id 欄位，不能為空

    department = relationship("Department", back_populates="stages")
    # 定義與 Department 模型的多對一關聯，單個 Stage 關聯到一個 Department

    units = relationship("Unit", back_populates="stage", cascade="all, delete-orphan")
    # 定義與 Unit 模型的一對多關聯，當 Stage 被刪除時，相關的 Unit 也會被刪除
