from sqlalchemy import Column, String, DateTime, Integer, func, ForeignKey
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship
from ..session import Base


class Fence(Base):
    __tablename__ = "fences"
    # 定義資料庫中的表名稱為 "fences"

    id = Column(Integer, primary_key=True, autoincrement=True, nullable=False)
    # 定義主鍵 id，整數類型，自動遞增，不能為空

    name = Column(String, nullable=False)
    # 定義名稱欄位，字串類型，不能為空

    drawn_area = Column(JSONB, nullable=False)
    # 定義畫出區域欄位，JSONB 類型，不能為空，用於存儲多個座標

    created_at = Column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    # 定義建立時間欄位，帶時區的日期時間類型，預設為當前時間，不能為空

    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
    # 定義更新時間欄位，帶時區的日期時間類型，更新時自動更新為當前時間，不能為空

    deleted_at = Column(DateTime(timezone=True), nullable=True)
    # 定義刪除時間欄位，帶時區的日期時間類型，允許為空

    unit_id = Column(Integer, ForeignKey("unit.id"), nullable=False)
    # 定義外鍵關聯，關聯到 unit 表的 id 欄位，不能為空

    unit = relationship("Unit", back_populates="fences")
    # 定義與 Unit 模型的關聯

    conditions = relationship("Condition", back_populates="fence")
    # 定義與 Condition 模型的關聯
