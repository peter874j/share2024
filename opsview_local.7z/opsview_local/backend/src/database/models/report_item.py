from sqlalchemy import Column, Index, Integer, String, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.mutable import MutableDict
from sqlalchemy.orm import relationship
from ..session import Base
from sqlalchemy.sql import func


class ReportItem(Base):
    __tablename__ = "report_item"

    id = Column(Integer, primary_key=True, autoincrement=True, nullable=False)

    # 關鍵欄位
    cycle_count = Column(Integer, name="cycle_count", nullable=True)  # Cycle Count
    cycle_start_time = Column(
        DateTime(timezone=True), nullable=True, index=True
    )  # Cycle Start Time
    work_id = Column(String, nullable=True, index=True)  # workId

    # 動態屬性
    extra_data = Column(MutableDict.as_mutable(JSONB), nullable=True)

    created_at = Column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    # 多對一關聯到 Report
    report_id = Column(
        Integer, ForeignKey("report.id", ondelete="CASCADE"), nullable=False
    )
    report = relationship("Report", back_populates="items")

    __table_args__ = (
        # 依 report_id + cycle_start_time 建立複合索引
        Index("idx_reportitem_report_time", "report_id", "cycle_start_time"),
        # 如果常用時間範圍 + report_id 反向，也可以加另一個
        Index("idx_reportitem_time_report", "cycle_start_time", "report_id"),
    )
