from sqlalchemy import (
    Column,
    String,
    DateTime,
    Integer,
    Boolean,
    func,
    ForeignKey,
    text,
)
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.mutable import MutableList
from ..session import Base


class Cam(Base):
    __tablename__ = "cam"
    # 定義資料庫中的表名稱為 "cam"

    id = Column(Integer, primary_key=True, autoincrement=True, nullable=False)
    # 定義 id 欄位，整數類型，主鍵，自動遞增，不能為空

    name = Column(String, nullable=False)
    # 定義 name 欄位，字串類型，不能為空，表示攝影機名稱

    ip = Column(String, nullable=False)
    # 定義 ip 欄位，字串類型，不能為空，表示攝影機的 IP 位址

    port = Column(String, nullable=False)
    # 定義 port 欄位，字串類型，不能為空，表示攝影機的連接埠

    status = Column(Boolean, nullable=False)
    # 定義 status 欄位，布林類型，不能為空，表示攝影機的狀態（啟用或停用）

    import_status = Column(Boolean, nullable=False, server_default=text("false"))
    # 定義 import_status 欄位，布林類型，不能為空，表示攝影機的導入狀態（完成或失敗）

    data = Column(MutableList.as_mutable(JSONB), nullable=True)
    # 定義 data 欄位，可變列表類型（JSONB），允許為空，用於儲存攝影機的其他資料

    stream_pre_uri = Column(String, nullable=False)
    # 定義 stream_pre_uri 欄位，字串類型，不能為空，表示預覽串流的 URI

    stream_det_uri = Column(String, nullable=False)
    # 定義 stream_det_uri 欄位，字串類型，不能為空，表示詳細串流的 URI

    obj_name_uri = Column(String, nullable=False)
    # 定義 obj_name_uri 欄位，字串類型，不能為空，表示物件名稱的 URI

    config_uri = Column(String, nullable=False)
    # 定義 config_uri 欄位，字串類型，不能為空，表示攝影機配置的 URI

    created_at = Column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    # 定義 created_at 欄位，帶時區的日期時間類型，不能為空，預設為當前時間，表示建立時間

    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
    # 定義 updated_at 欄位，帶時區的日期時間類型，不能為空，預設為當前時間，更新時自動更新，表示最後更新時間

    deleted_at = Column(DateTime(timezone=True), nullable=True)
    # 定義 deleted_at 欄位，帶時區的日期時間類型，允許為空，表示刪除時間（軟刪除）

    server_id = Column(Integer, ForeignKey("server.id"), nullable=False)
    # 定義 server_id 欄位，整數類型，不能為空，外鍵關聯至 server 表的 id 欄位

    server = relationship("Server", back_populates="cams")
    # 定義與 Server 模型的關係，使用 back_populates 參數實現雙向關聯

    unit_cams = relationship(
        "UnitCam", back_populates="cam", uselist=False, cascade="all, delete"
    )
    # 定義與 UnitCam 模型的一對一關係，使用 back_populates 參數實現雙向關聯，uselist=False 表示一對一

    units = relationship(
        "Unit",
        secondary="unit_cam",
        back_populates="cams",
        uselist=False,
        viewonly=True,
    )
    # 定義與 Unit 模型的多對多關係，通過 unit_cam 關聯表，使用 back_populates 實現雙向關聯
    # uselist=False 表示返回單一物件，viewonly=True 表示該關聯僅用於查詢，不會影響資料庫中的關聯
