from sqlalchemy import Column, Integer, ForeignKey, UniqueConstraint
from sqlalchemy.orm import relationship
from ..session import Base


class ConditionObject(Base):
    __tablename__ = "condition_object"
    # 定義資料庫中的表名稱為 "condition_object"

    id = Column(Integer, primary_key=True, autoincrement=True)
    # 新增一個自動增長的主鍵欄位，唯一標識每一行

    object_id = Column(Integer, ForeignKey("objects.id"), nullable=False)
    # 定義外鍵關聯，關聯到 object 表的 id 欄位，不能為空

    condition_id = Column(Integer, ForeignKey("conditions.id"), nullable=False)
    # 定義外鍵關聯，關聯到 condition 表的 id 欄位，不能為空，且必須唯一

    __table_args__ = (
        UniqueConstraint("object_id", "condition_id", name="uix_object_condition"),
    )
    # 定義唯一約束，防止 object_id 和 condition_id 的組合重複

    object = relationship("Object", back_populates="condition_object")
    # 定義與 Object 模型的多對一關聯，單個 ConditionObject 關聯到一個 Object

    condition = relationship("Condition", back_populates="condition_objects")
    # 定義與 Condition 模型的一對一關聯，單個 ConditionObject 關聯到一個 Condition，uselist=False 表示一
