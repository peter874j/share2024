from sqlalchemy import Column, DateTime, String, Integer, Text, ForeignKey, func
from sqlalchemy.orm import relationship
from ..session import Base


class Logic(Base):
    __tablename__ = "logics"
    # 定義資料庫中的表名稱為 "logics"

    id = Column(Integer, primary_key=True, autoincrement=True, nullable=False)
    # 定義主鍵 id，整數類型，自動遞增，不能為空

    state = Column(String, nullable=False)
    # 定義名稱欄位，字串類型，不能為空

    name = Column(String, nullable=True)
    # 定義名稱欄位，字串類型，允許為空

    mode = Column(String, nullable=True)
    # 定義模式欄位，字串類型，允許為空，應在應用層面驗證其值為 'release' 或 'switch'

    expression = Column(Text, nullable=True)
    # 定義表達式欄位，文本類型，允許為空

    created_at = Column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    # 定義建立時間欄位，帶時區的日期時間類型，預設為當前時間，不能為空

    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
    # 定義更新時間欄位，帶時區的日期時間類型，更新時自動更新為當前時間，不能為空

    deleted_at = Column(DateTime(timezone=True), nullable=True)
    # 定義刪除時間欄位，帶時區的日期時間類型，允許為空

    unit_id = Column(Integer, ForeignKey("unit.id"), nullable=False)
    # 定義外鍵關聯，關聯到 unit 表的 id 欄位，不能為空

    unit = relationship("Unit", back_populates="logics")
    # 定義與 Unit 模型的關聯
