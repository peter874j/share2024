from sqlalchemy import Column, DateTime, Integer, String, func, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.mutable import MutableList
from ..session import Base


class Report(Base):
    __tablename__ = "report"
    # 定義資料庫中的表名稱為 "report"

    id = Column(Integer, primary_key=True, autoincrement=True, nullable=False)
    # 定義主鍵 id，整數類型，自動遞增，不能為空
    data = Column(MutableList.as_mutable(JSONB), nullable=True)
    # 定義 data 欄位，可變列表型態，使用 JSONB 儲存，允許為空
    created_at = Column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    # 定義建立時間欄位，帶時區的日期時間類型，預設為當前時間，不能為空
    unit_id = Column(Integer, ForeignKey("unit.id"), nullable=False)
    # 定義外鍵關聯，關聯到 unit 表的 id 欄位，不能為空
    source = Column(String, nullable=False, default="webhook", server_default="webhook")
    # 區分資料來源('webhook'或'manual')，預設webhook

    unit = relationship("Unit", back_populates="reports")

    # 新增 ReportItem 關聯
    items = relationship(
        "ReportItem",
        back_populates="report",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
    # 定義與 Unit 模型的多對一關聯，單個報告關聯到一個單位
