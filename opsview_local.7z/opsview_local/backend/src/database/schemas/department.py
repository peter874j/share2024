from pydantic import BaseModel, Field, ConfigDict
from enum import Enum


class DepartmentSortField(str, Enum):
    id = "id"
    name = "name"
    created_at = "created_at"
    updated_at = "updated_at"
    deleted_at = "deleted_at"


class DepartmentBase(BaseModel):
    id: int = Field(..., description="部門唯一標識符")
    name: str = Field(..., description="部門名稱")


class DepartmentResponse(BaseModel):
    id: int = Field(..., description="部門唯一標識符")
    name: str = Field(..., description="部門名稱")

    model_config = ConfigDict(from_attributes=True)  # 替代 orm_mode
