from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime


class IdleDetail(BaseModel):
    Times: float
    Counts: int


class Idle(BaseModel):
    OP_Idle: IdleDetail = Field(..., alias="OP Idle")
    EQ_Idle: IdleDetail = Field(..., alias="EQ Idle")
    Total: IdleDetail


class StepDetail(BaseModel):
    Times: float
    Counts: int


class StepTime(BaseModel):
    Step_Time: float = Field(..., alias="Step Time")
    Step_Name: Optional[str] = Field(None, alias="Step Name")


class Work(BaseModel):
    Time: float
    Avg: StepTime
    Max: StepTime
    Min: StepTime
    # snScanning: StepDetail
    # contactInspection: StepDetail
    # prePostWork: StepDetail
    # nonContactInspection: StepDetail

    class Config:
        extra = "allow"  # 允許額外的屬性


class Cycle(BaseModel):
    Time: float
    Idle: Idle
    Work: Work


class CameraReportData(BaseModel):
    Server_IP: str = Field(..., alias="Server IP")
    Cam_IP: str = Field(..., alias="Cam IP")
    Cam_Port: str = Field(..., alias="Cam Port")
    Cycle_Count: int = Field(..., alias="Cycle Count")
    Cycle_Start_Time: datetime = Field(..., alias="Cycle Start Time")
    workId: str
    Cycle: Cycle

    class Config:
        populate_by_name = True  # 允許使用欄位名稱或 alias 來初始化
