from pydantic import BaseModel, Field, ConfigDict, model_validator
from enum import Enum

from src.database.schemas.stage import StageResponse
from typing import List, Optional


class StreamResponse(BaseModel):
    id: int = Field(..., description="攝影機唯一標識符")
    name: str = Field(..., description="攝影機名稱")
    stream_pre_uri: str = Field(..., description="預覽串流的 URI")
    stream_det_uri: str = Field(..., description="詳細串流的 URI")

    model_config = ConfigDict(from_attributes=True)  # 替代 orm_mode


class UnitImportStatus(Enum):
    IMPORTED = "imported"
    UNDO = "undo"
    ERROR = "error"


class UnitSortField(str, Enum):
    id = "id"
    fab = "fab"
    department = "department"
    stage = "stage"
    unit = "unit"
    import_status = "import_status"


class UnitList(BaseModel):
    location: Optional[str] = Field(None, description="廠區名稱")
    stage_name: Optional[str] = Field(None, description="站點名稱")


class UnitBase(BaseModel):
    id: int = Field(..., description="站點唯一標識符")
    name: str = Field(..., description="站點名稱")


class UnitResponse(BaseModel):
    id: int = Field(..., description="站點唯一標識符")
    name: str = Field(..., description="站點名稱")
    import_status: UnitImportStatus = Field(..., description="導入狀態")
    stage: Optional[StageResponse] = Field(..., description="關聯的Stage資料")
    cams: Optional[List[StreamResponse]] = Field(..., description="關聯的Cam資料")

    model_config = ConfigDict(from_attributes=True)  # 替代 orm_mode


class UnitListResponse(UnitResponse):
    server_status: bool = Field(..., description="程式狀態")


class UnitCreate(BaseModel):
    fab_name: str = Field(..., description="廠區名稱")
    department_name: str = Field(..., description="崗位部門名稱")
    stage_name: str = Field(..., description="站點名稱")
    unit_name: str = Field(..., description="崗位名稱")


class UnitUpdate(BaseModel):
    fab_name: Optional[str] = None
    department_name: Optional[str] = None
    stage_name: Optional[str] = None
    unit_name: Optional[str] = None

    @model_validator(mode="before")
    @classmethod
    def check_at_least_one(cls, values):
        if not any(values.values()):
            raise ValueError("至少需要提供一個欄位進行更新")
        return values


class FabImportRateResponse(BaseModel):
    fab_name: str
    total_units: int
    imported_units: int
    import_rate: float  # 0~1 的比例 or 百分比

    model_config = ConfigDict(from_attributes=True)  # 替代 orm_mode
