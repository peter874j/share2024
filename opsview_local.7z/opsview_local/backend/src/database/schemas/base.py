from pydantic import BaseModel
from typing import List, Generic, TypeVar
from enum import Enum


T = TypeVar("T")


class PaginatedResponse(BaseModel, Generic[T]):
    success: bool
    data: List[T]
    total_count: int
    page: int
    limit: int
    message: str


class SortOrder(str, Enum):
    ASC = "asc"
    DESC = "desc"
