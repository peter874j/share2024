from pydantic import BaseModel, ConfigDict
from typing import List, Optional
from datetime import datetime
from enum import Enum


class ObjectType(str, Enum):
    exists = "exists"
    in_fence = "in_fence"
    overlap = "overlap"
    overlap_in_fence = "overlap_in_fence"


class ObjectResponse(BaseModel):
    id: int
    name: str
    unit_id: Optional[int] = None
    created_at: datetime
    updated_at: datetime
    deleted_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)  # 替代 orm_mode


class ConditionBase(BaseModel):
    name: str
    unit_id: int
    fence_id: Optional[int]


class ConditionCreate(BaseModel):
    name: str = None
    unit_id: Optional[int] = None
    object_ids: Optional[List[int]] = None
    fence_id: Optional[int] = None


class ConditionUpdate(BaseModel):
    name: Optional[str] = None
    unit_id: Optional[int] = None
    object_ids: Optional[List[int]] = None
    fence_id: Optional[int] = None


class ConditionResponse(ConditionBase):
    id: int
    created_at: datetime
    updated_at: datetime
    deleted_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


class ConditionWithObjectsResponse(ConditionResponse):
    objects: List[ObjectResponse]
