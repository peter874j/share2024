from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional


class CamBase(BaseModel):
    id: int = Field(..., description="攝影機唯一標識符")
    name: str = Field(..., description="攝影機名稱")
    ip: str = Field(..., description="攝影機的 IP 位址")
    port: str = Field(..., description="攝影機的連接埠")
    status: bool = Field(..., description="攝影機的狀態（啟用或停用）")
    data: Optional[List] = Field(..., description="攝影機的其他資料")
    stream_pre_uri: str = Field(..., description="預覽串流的 URI")
    stream_det_uri: str = Field(..., description="詳細串流的 URI")
    obj_name_uri: str = Field(..., description="物件名稱的 URI")
    config_uri: str = Field(..., description="攝影機配置的 URI")


class CreateCam(BaseModel):
    stage_id: int = Field(..., description="站點 ID")
    unit_id: int = Field(..., description="崗位 ID")
    server_id: int = Field(..., description="主機 ID")
    ip: str = Field(..., description="攝影機的 IP 位址")
    port: str = Field(..., description="攝影機的連接埠")


class UpdateCam(BaseModel):
    stage_id: Optional[int] = Field(None, description="站點 ID")
    unit_id: Optional[int] = Field(None, description="崗位 ID")
    ip: Optional[str] = Field(None, description="攝影機的 IP 位址")
    port: Optional[str] = Field(None, description="攝影機的連接埠")


class StreamResponse(BaseModel):
    id: int = Field(..., description="攝影機唯一標識符")
    name: str = Field(..., description="攝影機名稱")
    stream_pre_uri: str = Field(..., description="預覽串流的 URI")
    stream_det_uri: str = Field(..., description="詳細串流的 URI")
    unit_name: Optional[str] = Field(..., description="崗位名稱")

    model_config = ConfigDict(from_attributes=True)  # 替代 orm_mode
