from pydantic import BaseModel, Field


class ConfigSync(BaseModel):
    unit_id: int = Field(..., description="崗位 ID")
