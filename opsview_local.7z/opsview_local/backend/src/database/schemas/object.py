from pydantic import BaseModel, ConfigDict, Field
from datetime import datetime
from typing import List, Optional


class ConditionResponse(BaseModel):
    id: int
    name: str
    unit_id: int
    fence_id: Optional[int]
    created_at: datetime
    updated_at: datetime
    deleted_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


class ObjectBase(BaseModel):
    name: str
    unit_id: Optional[int] = None


class ObjectCreate(ObjectBase):
    pass


class ObjectUpdate(BaseModel):
    name: Optional[str] = None
    unit_id: Optional[int] = None


class ObjectResponse(ObjectBase):
    id: int
    created_at: datetime
    updated_at: datetime
    deleted_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)  # 替代 orm_mode


class ObjectWithConditionResponse(ObjectResponse):
    condition: Optional[List[ConditionResponse]] = Field([], description="關聯條件")
