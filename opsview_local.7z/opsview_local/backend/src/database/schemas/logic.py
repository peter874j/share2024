from pydantic import BaseModel, ConfigDict, field_validator
from typing import Optional
from datetime import datetime


class LogicBase(BaseModel):
    state: str
    name: str
    mode: str
    expression: str
    unit_id: int

    @field_validator("mode")
    @classmethod
    def check_mode(cls, v):
        if v not in ("release", "switch"):
            raise ValueError("mode must be 'release' or 'switch'")
        return v


class LogicCreate(LogicBase):
    pass


class LogicUpdate(BaseModel):
    name: Optional[str] = None
    mode: Optional[str] = None
    expression: Optional[str] = None
    unit_id: Optional[int] = None

    @field_validator("mode")
    @classmethod
    def check_mode(cls, v):
        if v is None:
            return v
        if v not in ("release", "switch"):
            raise ValueError("mode must be 'release' or 'switch'")
        return v


class LogicResponse(LogicBase):
    id: int
    created_at: datetime
    updated_at: datetime
    deleted_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)
