import re

from typing import Any, Dict, List, Optional, Union
from pydantic import BaseModel, ConfigDict, model_validator, field_validator
from datetime import datetime

from src.database.schemas.unit import UnitResponse

# 只匹配 step_ 前綴
TIMES = re.compile(r"^step_(?P<name>.+)_times$")
COUNTS = re.compile(r"^step_(?P<name>.+)_counts$")


class CombinedData(BaseModel):
    workId: str
    cycle_start_time: datetime
    cycle_time: float
    work_time: float

    eq_idle_time: float
    eq_idle_counts: int
    op_idle_time: float
    op_idle_counts: int
    total_idle_times: float
    total_idle_counts: int

    avg_step_time: float
    max_step_name: str
    max_step_time: float
    min_step_name: str
    min_step_time: float
    avg_cycle_time: float

    # 動態蒐集 step_XXX_times/counts
    steps: Dict[str, Dict[str, Any]]

    @field_validator("workId", mode="before")
    def replace_none_with_empty_list(cls, v):
        if v is None:
            return "empty_list"
        return v

    @model_validator(mode="before")
    @classmethod
    def gather_steps(cls, data: Dict[str, Any]) -> Dict[str, Any]:
        steps: Dict[str, Dict[str, Any]] = {}
        removed: set[str] = set()

        for key, val in list(data.items()):
            if m := TIMES.match(key):
                name = m.group("name")
                steps.setdefault(name, {})["times"] = val
                removed.add(key)

            elif m := COUNTS.match(key):
                name = m.group("name")
                steps.setdefault(name, {})["counts"] = val
                removed.add(key)

        # 注入 steps
        data["steps"] = steps

        # 移除原始 step_XXX_times/counts
        for key in removed:
            data.pop(key, None)

        return data


class ReportItemOut(BaseModel):
    id: int
    cycle_start_time: Optional[datetime]
    cycle_count: Optional[float]
    work_id: Optional[str]
    extra_data: Optional[Dict]

    model_config = ConfigDict(from_attributes=True)


class ReportBase(BaseModel):
    id: int
    unit_id: int
    # data: List[CombinedData]
    items: Optional[List[ReportItemOut]]
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class CreateReport(BaseModel):
    unit_id: int
    data: List[Dict]


class StageAnalysisBoxplotReportResponse(BaseModel):
    q1: float
    median: float
    q3: float
    minimum: float
    maximum: float

    model_config = ConfigDict(from_attributes=True)  # 替代 orm_mode


class StageAnalysisReportResponse(BaseModel):
    eq_idle: float
    op_idle: float
    work: float
    baseline: float

    model_config = ConfigDict(from_attributes=True)  # 替代 orm_mode


class StageAnalysisReportResponseList(BaseModel):
    unit_name: str
    boxplot_worktime_stats: StageAnalysisBoxplotReportResponse
    avg_worktime_stats: StageAnalysisReportResponse


class UnitAnalysisReportCycleTimeComponent(BaseModel):
    Work: float
    OP_Idle: float
    EQ_Idle: float


class UnitAnalysisReportWorkTimeComponent(BaseModel):
    steps: Dict[str, float]

    model_config = {
        "extra": "allow",  # 允許接收除了 steps 以外的動態欄位
        "populate_by_name": True,
    }

    @model_validator(mode="before")
    @classmethod
    def gather_steps(cls, data: Dict[str, Any]) -> Dict[str, Any]:
        step_fields: Dict[str, float] = {}

        for key, val in list(data.items()):
            if key.startswith("Step_"):
                step_fields[key] = val
                # 移除原始欄位，交給 steps dict 管理
                data.pop(key)

        data["steps"] = step_fields
        return data


class UnitAnalysisReportIdleTimeComponent(BaseModel):
    OP_Idle: float
    EQ_Idle: float


class UnitAnalysisReportCycleTimeData(BaseModel):
    Cycle_Start_Time: datetime
    Work: float
    OP_Idle: float
    EQ_Idle: float
    Work_Ratio: float
    EQ_Idle_Ratio: float
    OP_Idle_Ratio: float
    Baseline: float


class UnitAnalysisReportCycleTimeList(BaseModel):
    unit_name: str
    data: List[UnitAnalysisReportCycleTimeData]


class UnitAnalysisReportWorkTimeData(BaseModel):
    Cycle_Start_Time: datetime
    steps: Dict[str, Dict[str, Union[float, int]]]

    model_config = {
        "extra": "allow",  # 允許接收額外的 StepX_* 欄位
    }

    @model_validator(mode="before")
    @classmethod
    def _gather_steps(cls, data: Dict[str, Any]) -> Dict[str, Any]:
        step_map: Dict[str, Dict[str, Union[float, int]]] = {}
        to_remove: set[str] = set()

        for key, val in data.items():
            # 只匹配 Step_X_Time / Step_X_Count / Step_X_AVG_Time
            m = re.compile(
                r"^Step_(?P<name>[^_]+)_(?P<kind>Time|Count|AVG_Time)$"
            ).match(key)
            if not m:
                continue

            name = m.group("name")
            kind = m.group("kind")
            step_map.setdefault(name, {})[kind] = val
            to_remove.add(key)

        # 注入並清理原始 StepX_* 欄位
        data["steps"] = step_map

        return data


class UnitAnalysisReportWorkTimeList(BaseModel):
    unit_name: str
    data: List[UnitAnalysisReportWorkTimeData]


class UnitAnalysisReportIdleTimeData(BaseModel):
    Cycle_Start_Time: datetime
    OP_Idle: float
    EQ_Idle: float
    OP_Base: float
    EQ_Base: float


class UnitAnalysisReportIdleTimeList(BaseModel):
    unit_name: str
    data: List[UnitAnalysisReportIdleTimeData]


class UnitAnalysisResponse(BaseModel):
    cycle_time_component: UnitAnalysisReportCycleTimeComponent
    work_time_component: UnitAnalysisReportWorkTimeComponent
    idle_time_component: UnitAnalysisReportIdleTimeComponent
    cycle_time_data_list: List[UnitAnalysisReportCycleTimeList]
    work_time_data_list: List[UnitAnalysisReportWorkTimeList]
    idle_time_data_list: List[UnitAnalysisReportIdleTimeList]


class UnitAnalysisCycleDetailResponse(BaseModel):
    id: int
    Cycle_Start_Time: datetime
    Video_Url: str
    Cycle_Time: float
    Work_Time: float
    OP_Idle_Time: float
    EQ_Idle_Time: float
    WorkId: str
    unit: UnitResponse

    model_config = ConfigDict(from_attributes=True)  # 替代 orm_mode


class UpdateWorkIdRequest(BaseModel):
    work_id: str
    cycle_start_time: str
