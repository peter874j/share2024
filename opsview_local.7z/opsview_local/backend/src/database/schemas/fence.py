# src/database/schemas/fence.py

from pydantic import BaseModel, ConfigDict, field_validator
from typing import Optional, List
from datetime import datetime


class FenceBase(BaseModel):
    name: str

    # 明確宣告：List of List of float
    drawn_area: List[List[float]]
    unit_id: int

    # 驗證每個子清單長度必須是 2
    @field_validator("drawn_area", mode="before")
    @classmethod
    def check_drawn_area(cls, v):
        if not isinstance(v, list):
            raise ValueError("drawn_area 必須是 list of list")
        for idx, point in enumerate(v):
            if (
                not isinstance(point, list)
                or len(point) != 2
                or not all(isinstance(x, (int, float)) for x in point)
            ):
                raise ValueError(f"第 {idx} 個座標格式不正確，應為 [x, y]，got {point}")
        return v


class FenceCreate(FenceBase):
    pass


class FenceUpdate(BaseModel):
    name: Optional[str] = None
    drawn_area: Optional[List[List[float]]] = None
    unit_id: Optional[int] = None

    # 同樣加上驗證
    @field_validator("drawn_area", mode="before")
    @classmethod
    def check_drawn_area(cls, v):
        if v is None:
            return v
        if not isinstance(v, list):
            raise ValueError("drawn_area 必須是 list of list")
        for idx, point in enumerate(v):
            if (
                not isinstance(point, list)
                or len(point) != 2
                or not all(isinstance(x, (int, float)) for x in point)
            ):
                raise ValueError(f"第 {idx} 個座標格式不正確，應為 [x, y]，got {point}")
        return v


class FenceResponse(FenceBase):
    id: int
    created_at: datetime
    updated_at: datetime
    deleted_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)
