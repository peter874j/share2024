from pydantic import BaseModel, Field


class AuthLoginRequest(BaseModel):
    username: str = Field(..., description="UAC 用戶名")
    password: str = Field(..., description="UAC 密碼")


class AuthTokenPayload(BaseModel):
    sub: str
    token_type: str
    jti: str


class AuthTokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expire_in: int


class RefreshTokenRequest(BaseModel):
    refresh_token: str
