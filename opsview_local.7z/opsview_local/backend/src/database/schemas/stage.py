from pydantic import BaseModel, Field, ConfigDict
from enum import Enum

from src.database.schemas.fab import FabResponse
from typing import Optional

from src.database.schemas.department import DepartmentResponse


class StageSortField(str, Enum):
    id = "id"
    name = "name"
    created_at = "created_at"
    updated_at = "updated_at"
    deleted_at = "deleted_at"


class StageList(BaseModel):
    location: Optional[str] = Field(..., description="廠區名稱")


class StageBase(BaseModel):
    id: int = Field(..., description="站點唯一標識符")
    name: str = Field(..., description="站點名稱")


class StageResponse(BaseModel):
    id: int = Field(..., description="站點唯一標識符")
    name: str = Field(..., description="站點名稱")
    fab: Optional[FabResponse] = Field(..., description="關聯的Fab資料")
    department: Optional[DepartmentResponse] = Field(..., description="關聯的Department資料")

    model_config = ConfigDict(from_attributes=True)  # 替代 orm_mode
