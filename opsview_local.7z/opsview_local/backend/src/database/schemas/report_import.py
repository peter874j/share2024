from typing import List, Optional, Literal
from datetime import datetime
from pydantic import BaseModel, ConfigDict


# 僅做「底線 -> 空白」的 alias 對齊，其他不變
def underscore_to_space(field_name: str) -> str:
    return field_name.replace("_", " ")


class AliasModel(BaseModel):
    model_config = ConfigDict(
        populate_by_name=True,
        alias_generator=underscore_to_space,
    )


class ManualIdleItem(AliasModel):
    """
    單一「閒置」統計項目的資料結構。
    - Times：該類型閒置所累積的時間量（時間單位請與來源/系統設定一致）
    - Counts：該類型閒置的發生次數
    """

    Times: float  # 累積時間量（例如：分鐘或秒，依系統設定）
    Counts: int  # 發生次數（應為非負整數）


class ManualIdle(AliasModel):
    """
    「閒置」統計集合。
    - OP_Idle：人員（操作）相關的閒置時間/次數
    - EQ_Idle：設備（機台）相關的閒置時間/次數
    - Total：上述各項加總（時間與次數）
    """

    OP_Idle: ManualIdleItem
    EQ_Idle: ManualIdleItem
    Total: ManualIdleItem


class ManualWorkAvg(AliasModel):
    """
    「作業」的平均統計資料。
    - Step_Time：每步驟平均耗時
    """

    Step_Time: float  # 平均步驟時間（單位依系統設定）


class ManualWorkExt(AliasModel):
    """
    「作業」的極值統計資料。
    - Step_Time：極值（最大/最小）時的步驟耗時
    - Step_Name：對應該極值的步驟名稱（例如：Print、Expose 等）
    """

    Step_Time: float  # 極值步驟時間
    Step_Name: str  # 極值對應步驟名稱


class ManualWork(AliasModel):
    """
    「作業」統計集合。
    - Time：作業總時間
    - Avg：平均統計
    - Max：最大值統計
    - Min：最小值統計
    - 動態步驟欄位：允許額外的鍵值對，鍵為步驟名稱（例：Print、Expose...），值為 { "Times": float, "Counts": int }
      用於表達各步驟的累積時間與次數。
    """

    # 基本統計
    Time: float
    Avg: ManualWorkAvg
    Max: ManualWorkExt
    Min: ManualWorkExt

    # 允許動態步驟名稱，例如 "snScanning", "contactInspection" ... 其值為 { "Times": float, "Counts": int }
    model_config = ConfigDict(
        populate_by_name=True,
        alias_generator=underscore_to_space,
        extra="allow",
    )


class ManualCycle(AliasModel):
    """
    整體「週期」統計資料。
    - Time：該生產週期的總時間
    - Idle：該週期的閒置統計（人員/設備/總計）
    - Work：該週期的作業統計（含平均/極值與動態步驟明細）
    """

    Time: float
    Idle: ManualIdle
    Work: ManualWork


class ManualReportData(AliasModel):
    """
    人工匯入之單筆生產資料，欄位命名與 webhook 對齊。
    注意：
    - Cycle_Start_Time：建議使用 timezone-aware 的 UTC 時間（例如：2025-08-21T03:15:42Z）。
      導入時通常會檢核「與檔名日期一致」以及「同日衝突」等規則。
    - Cycle_Count：該週期的序號或計數（整數）
    - workId：可選的工單編號或追蹤識別碼
    - Cycle：該週期的統計內容（含作業與閒置）
    """

    Cycle_Start_Time: datetime
    Cycle_Count: int
    workId: Optional[str] = None
    Cycle: ManualCycle

    # 允許以欄位名稱填值（即使未定義 alias），便於與外部資料對齊
    model_config = ConfigDict(
        populate_by_name=True,
        alias_generator=underscore_to_space,
    )


class ReportBatchImportFileResult(AliasModel):
    """
    批次導入「單一檔案」的處理結果。
    - filename：原始檔名
    - date：自檔名解析出的 ISO 日期字串（YYYY-MM-DD），若無法解析則為 None
    - total：該檔案解析出的資料總筆數
    - inserted：成功寫入資料庫的筆數
    - skipped：因規則（如重複、日期不符等）而略過的筆數
    - errors：處理過程中的錯誤訊息（若多筆錯誤，將累積）
    - status：檔案處理狀態
        • "success"：成功（通常 inserted > 0，且無阻斷性錯誤）
        • "failed"：失敗（解析或寫入過程出現阻斷性錯誤）
        • "skipped"：整體略過（例如：與既有資料衝突或日期不符，未進行寫入）
    """

    filename: str
    date: Optional[str]  # ISO 日期字串，或 None（檔名無法解析）
    total: int
    inserted: int
    skipped: int
    errors: List[str] = []
    status: Literal["success", "failed", "skipped"]


class ReportBatchImportResponse(AliasModel):
    """
    批次導入的整體回應。
    - total_files：本次上傳/處理的檔案總數
    - success_files：成功處理完成的檔案數
    - skipped_files：被整體略過的檔案數
    - failed_files：處理失敗的檔案數
    - results：各檔案的詳細處理結果清單（對應 ReportBatchImportFileResult）
    """

    total_files: int
    success_files: int
    skipped_files: int
    failed_files: int
    results: List[ReportBatchImportFileResult]
