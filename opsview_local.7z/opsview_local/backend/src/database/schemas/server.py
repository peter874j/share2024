from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List
from datetime import datetime


class ServerBase(BaseModel):
    id: int
    name: str
    ip: str
    port: str
    status: bool
    created_at: datetime
    updated_at: datetime


class CreateServer(BaseModel):
    fab_id: int = Field(..., description="廠區 ID")
    name: str = Field(..., description="伺服器名稱")
    ip: str = Field(..., description="伺服器 IP 位址")
    description: str = Field(..., description="描述")
    status: bool = Field(..., description="是否啟用")


class UpdateServer(BaseModel):
    fab_id: Optional[int] = Field(None, description="廠區 ID")
    name: Optional[str] = Field(None, description="伺服器名稱")
    ip: Optional[str] = Field(None, description="伺服器 IP 位址")
    description: Optional[str] = Field(None, description="描述")
    status: Optional[bool] = Field(None, description="是否啟用")


class ServerList(BaseModel):
    fab_id: Optional[int] = Field(..., description="廠區 ID")


class StageInUnit(BaseModel):
    name: Optional[str] = Field(None, description="站點名稱")

    model_config = ConfigDict(from_attributes=True)


class UnitInCam(BaseModel):
    name: Optional[str] = Field(None, description="崗位名稱")
    stage: StageInUnit = Field(default_factory=StageInUnit, alias="stage")

    model_config = ConfigDict(from_attributes=True)


class CamInServer(BaseModel):
    id: int
    name: str
    ip: str
    port: str
    status: bool
    created_at: datetime
    updated_at: datetime
    units: Optional[UnitInCam] = None

    model_config = ConfigDict(from_attributes=True)


class ServerResponse(BaseModel):
    id: int
    fab_id: int
    name: str
    ip: str
    description: str
    status: bool
    created_at: datetime
    updated_at: datetime
    cams: List[CamInServer] = []  # 伺服器底下的攝影機列表

    model_config = ConfigDict(from_attributes=True)
