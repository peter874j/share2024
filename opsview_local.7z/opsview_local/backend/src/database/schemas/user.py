from typing import Optional, List
from pydantic import BaseModel, EmailStr, Field, ConfigDict
from enum import Enum


class UserRole(str, Enum):
    super_admin = "super_admin"
    admin = "admin"
    user = "user"


class UserSortField(str, Enum):
    id = "id"
    fullname = "fullname"
    location = "location"
    deptno = "deptno"
    role = "role"


class UserCreateRequest(BaseModel):
    id: str
    email: str
    username: str
    fullname: str
    deptno: str
    location: Optional[str] = None
    role: UserRole = UserRole.user


# 用於 PATCH/更新：全部欄位皆可選，搭配 model_dump(exclude_unset=True)
class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    username: Optional[str] = None
    fullname: Optional[str] = None
    deptno: Optional[str] = None
    location: Optional[str] = None
    role: Optional[UserRole] = None
    token: Optional[str] = None


# 用於列表查詢的過濾條件
class UserFilter(BaseModel):
    location: Optional[str] = None


class UpdateUserRoleRequest(BaseModel):
    role: UserRole


class UserResponse(BaseModel):
    id: str
    email: str
    username: str
    fullname: str
    deptno: str
    location: Optional[str]
    role: UserRole

    model_config = ConfigDict(from_attributes=True)


class UserListResponse(BaseModel):
    total: int
    items: List[UserResponse]
