from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from src.config.settings import settings

# 創建異步引擎，連接到異步資料庫
async_engine = create_async_engine(
    settings.database_url_async,
    echo=False,  # 設置為 False，不輸出 SQLAlchemy 的日誌訊息
    future=True,
)

# 創建同步引擎，供 Alembic 遷移工具使用
engine = create_engine(
    settings.database_url_sync,
    echo=False,  # 設置為 False，不輸出 SQLAlchemy 的日誌訊息
    future=True,
)

# 創建 ORM 模型的基礎類，所有的模型類都將繼承自這個 Base
Base = declarative_base()

# 創建異步會話，用於生成異步資料庫會話
async_session = sessionmaker(
    async_engine,
    expire_on_commit=False,  # 禁用提交時自動過期，以避免在事務結束後屬性被設置為過期
    class_=AsyncSession,  # 指定會話類型為異步會話 AsyncSession
)

# 獲取異步資料庫會話的異步生成器函數，用於依賴注入
async def get_db():
    async with async_session() as session:
        yield session
        # 使用異步上下文管理器，確保會話在使用後正確關閉


# 創建後續遷移: alembic revision --autogenerate -m "<CAPTION>"
# 應用新遷移: alembic upgrade head
