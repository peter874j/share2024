from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger

from src.scheduler.jobs import check_server_status


def create_scheduler():
    scheduler = AsyncIOScheduler()
    scheduler.add_job(
        check_server_status, IntervalTrigger(minutes=30), id="check_status"
    )
    return scheduler
