import asyncio
from datetime import datetime
from sqlalchemy import select

from src.database.session import get_db
from src.database.models.server import Server
from src.api.orchestrators.server_orchestrator import ServerOrchestrator
from src.config.settings import settings


def sync_task():
    print(f"[{datetime.now()}] 執行同步任務")


async def async_task():
    print(f"[{datetime.now()}] 執行異步任務開始")
    await asyncio.sleep(1)
    print(f"[{datetime.now()}] 異步任務完成")


async def check_server_status():
    """巡檢目前所有狀態為線上的 Server，若處於非除錯模式，則透過 ServerController 檢查每台主機的真實運作狀態，並輸出檢查過程資訊。

    Returns:
        None
    """
    async for db in get_db():
        orchestrator: ServerOrchestrator = ServerOrchestrator(db)
        stmt = select(Server)
        result = await db.execute(stmt)
        servers = result.scalars().all()

        for server in servers:
            # if not settings.app_debug:
            await orchestrator.check_client_server_status(server_id=server.id)
            print(f"Checking server status: server {server.id}")
