from __future__ import annotations
from typing import Optional, Literal, Any
from pathlib import Path
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent
ENV_PATH = BASE_DIR / ".env"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=str(ENV_PATH),
        extra="ignore",
        case_sensitive=False,
    )

    # Application
    app_name: str = Field("OpsView API", env="APP_NAME")
    app_debug: bool = Field(False, env="APP_DEBUG")
    app_env: Literal["development", "staging", "production"] = Field(
        "development", env="APP_ENV"
    )

    host: str = Field("0.0.0.0", env="HOST")
    port: int = Field(8000, env="PORT")

    # Database
    database_url_sync: str = Field(
        "postgresql://postgres:admin@127.0.0.1:5432/opsview", env="DATABASE_URL_SYNC"
    )
    database_url_async: str = Field(
        "postgresql+asyncpg://postgres:admin@127.0.0.1:5432/opsview",
        env="DATABASE_URL_ASYNC",
    )

    # MinIO
    minio_endpoint: Optional[str] = Field(None, env="MINIO_ENDPOINT")
    minio_admin_access_key: Optional[str] = Field(None, env="MINIO_ADMIN_ACCESS_KEY")
    minio_admin_secret_key: Optional[str] = Field(None, env="MINIO_ADMIN_SECRET_KEY")
    minio_report_video_bucket: str = Field(
        "rollcall-test", env="MINIO_REPORT_VIDEO_BUCKET"
    )

    # Log
    log_level: str = Field("INFO", env="LOG_LEVEL")

    # JWT
    jwt_secret_key: str = Field("test_key", env="JWT_SECRET_KEY")
    algorithm: str = Field("HS256", env="ALGORITHM")
    access_token_expire_seconds: int = Field(15 * 60, env="ACCESS_TOKEN_EXPIRE_SECONDS")
    refresh_token_expire_seconds: int = Field(
        7 * 86400, env="REFRESH_TOKEN_EXPIRE_SECONDS"
    )

    # Webhook
    webhook_secret: str = Field("your_shared_secret_key", env="WEBHOOK_SECRET")

    # UAC
    uac_login_domain: str = Field(
        "http://autcpmoweb01.corpnet.auo.com/api/UACAccount/UACLogin",
        env="UAC_LOGIN_DOMAIN",
    )
    uac_check_domain: str = Field(
        "http://autcpmoweb01.corpnet.auo.com/api/UACAccount/CheckAuthToken",
        env="UAC_CHECK_DOMAIN",
    )

    # Super Admin
    super_admin_email: str = Field("", env="SUPER_ADMIN_EMAIL")
    super_admin_pw_hash: str = Field("", env="SUPER_ADMIN_PW_HASH")

    def model_post_init(self, __context: Any) -> None:
        # Production safety checks
        if self.is_production():
            if (
                not self.jwt_secret_key
                or self.jwt_secret_key == "test_key"
                or len(self.jwt_secret_key) < 16
            ):
                raise RuntimeError(
                    "JWT_SECRET_KEY is invalid for production. Provide a strong, non-default secret."
                )

    def is_production(self) -> bool:
        return self.app_env.lower() == "production"


settings = Settings()
