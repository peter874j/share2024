# OpsView 崗位監控後台管理系統（FastAPI）

OpsView 是一套以 FastAPI 構建的後台管理與崗位監控系統，聚焦使用者與權限管理、即時設備整合、與報表匯整。此 README 提供快速開始、環境變數、架構與分層、資料庫與排程、部署與規範等說明。

參考主要進入點：[app.py](app.py)，設定來源：[src/config/settings.py](src/config/settings.py)，路由綁定：[src/api/routers.py](src/api/routers.py).

## 功能概覽

- 登入與驗證（JWT）
- 角色與權限管理
- 資料查詢、分頁與模糊搜尋
- 報表統計與分析
- 即時監控與外部 Client 整合
- 崗位（Unit）與設備（Cam）CRUD 與關聯維護
- Webhook 事件接收與處理
- 背景排程與伺服器健康檢查

## 快速開始

1. 安裝相依套件
   ```bash
   pip install -r requirements.txt
   ```
2. 準備環境變數檔（可參考範例）：[src/config/.env.example](src/config/.env.example)
3. 啟動開發伺服器（文件路徑為 `/`）
   ```bash
   uvicorn app:app --reload
   ```
4. 若 APP_DEBUG=true 且 APP_ENV!=production，可於根目錄瀏覽互動式 API 文件（OpenAPI/Swagger）：http://localhost:8000/（其他環境不提供 /docs 與 /openapi.json）

## 環境設定（Environment Variables）

可於 [src/config/settings.py](src/config/settings.py) 查看完整清單，常見鍵值：
- APP_NAME、APP_DEBUG、HOST、PORT
- DATABASE_URL_SYNC、DATABASE_URL_ASYNC
- MINIO_ENDPOINT、MINIO_ADMIN_ACCESS_KEY、MINIO_ADMIN_SECRET_KEY、MINIO_REPORT_VIDEO_BUCKET
- JWT_SECRET_KEY、ALGORITHM、ACCESS_TOKEN_EXPIRE_SECONDS、REFRESH_TOKEN_EXPIRE_SECONDS
- WEBHOOK_SECRET
- UAC_LOGIN_DOMAIN、UAC_CHECK_DOMAIN
- SUPER_ADMIN_EMAIL、SUPER_ADMIN_PW_HASH

範例可參考：[src/config/.env.example](src/config/.env.example)

## 專案結構（重點目錄）

```
.
├── app.py
├── requirements.txt
├── src/
│   ├── api/
│   │   ├── controllers/
│   │   ├── orchestrators/
│   │   ├── routes/
│   │   └── services/
│   ├── config/
│   ├── database/
│   │   ├── models/
│   │   ├── repositories/
│   │   ├── schemas/
│   │   └── migration/ (Alembic)
│   ├── scheduler/
│   └── utils/
├── docs/
├── Dockerfile-api
├── Dockerfile-scheduler
└── .gitlab-ci.yml
```

主要檔案連結：
- 應用進入點：[app.py](app.py)
- 設定檔：[src/config/settings.py](src/config/settings.py)
- 路由聚合：[src/api/routers.py](src/api/routers.py)
- 路由模組：  
  - [src/api/routes/auth.py](src/api/routes/auth.py)  
  - [src/api/routes/user.py](src/api/routes/user.py)  
  - [src/api/routes/fab.py](src/api/routes/fab.py)  
  - [src/api/routes/department.py](src/api/routes/department.py)  
  - [src/api/routes/stage.py](src/api/routes/stage.py)  
  - [src/api/routes/unit.py](src/api/routes/unit.py)  
  - [src/api/routes/object.py](src/api/routes/object.py)  
  - [src/api/routes/fence.py](src/api/routes/fence.py)  
  - [src/api/routes/condition.py](src/api/routes/condition.py)  
  - [src/api/routes/logic.py](src/api/routes/logic.py)  
  - [src/api/routes/report.py](src/api/routes/report.py)  
  - [src/api/routes/cam.py](src/api/routes/cam.py)  
  - [src/api/routes/server.py](src/api/routes/server.py)  
  - [src/api/routes/client.py](src/api/routes/client.py)  
  - [src/api/routes/test.py](src/api/routes/test.py)  
- 控制器（Controllers）：[src/api/controllers/](src/api/controllers/)
- 協作層（Orchestrators）：[src/api/orchestrators/](src/api/orchestrators/)
- 服務層（Services）：[src/api/services/](src/api/services/)
- 資料層（Models/Repositories/Schemas）：[src/database/](src/database/)
- 公用工具（Utils）：[src/utils/](src/utils/)
- 背景排程（Scheduler）：[src/scheduler/](src/scheduler/)

## 架構與分層

本專案遵循 Clean Structure 與 RORO（Receive an Object, Return an Object）設計

分層重點：
- Controllers：僅處理輸入/輸出與參數驗證，薄層呼叫 Orchestrator 或 Service。
- Orchestrators：協調多個 Service 的 Use-Case 流程與交易邊界。
- Services：單一聚合的業務規則與交易控制（commit）。
- Repositories：純資料存取（flush 不 commit）。
- Schemas：Pydantic v2 的請求/回應資料模型。

中介軟體與跨切面能力建議放於 [src/middlewares/](src/middlewares/) 與 [src/utils/](src/utils/)。

## 啟動與執行

- 啟動 API 服務（預設 8000 埠）：  
  ```bash
  uvicorn app:app --reload
  ```
- API 文件路徑：根目錄（已於 [app.py](app.py) 設定）
- API 前綴：/api（見 [src/api/routers.py](src/api/routers.py) 於 [app.py](app.py) 綁定）
- Webhook 路徑前綴：/webhook（見 [src/api/routes/webhook.py](src/api/routes/webhook.py) 並由 [app.py](app.py) 掛載）
- 測試路由：見 [src/api/routes/test.py](src/api/routes/test.py)

背景排程：  
- 排程入口：[run_scheduler.py](run_scheduler.py)  
- 排程設定與工作：[src/scheduler/scheduler.py](src/scheduler/scheduler.py)、[src/scheduler/jobs.py](src/scheduler/jobs.py)

## 資料庫與遷移

- ORM：SQLAlchemy 2.x（同步/非同步連線於 [src/config/settings.py](src/config/settings.py)）  
- 連線與 Session 管理：[src/database/session.py](src/database/session.py)  
- 模型定義：[src/database/models/](src/database/models/)  
- 資料存取（Repositories）：[src/database/repositories/](src/database/repositories/)  
- 資料結構（Schemas/DTO）：[src/database/schemas/](src/database/schemas/)  
- 資料庫遷移（Alembic）：[src/database/migration/](src/database/migration/)

常用 Alembic 指令（請先設定 DATABASE_URL_*）：  
```bash
# 初始化（已存在可略過）
alembic -c src/database/migration/alembic.ini init src/database/migration/alembic

# 產生遷移腳本
alembic -c src/database/migration/alembic.ini revision -m "your message"

# 套用遷移
alembic -c src/database/migration/alembic.ini upgrade head
```

## 認證與授權

- 設定：見 [src/config/settings.py](src/config/settings.py)  
- 產生與驗證：見 [src/utils/auth.py](src/utils/auth.py)、[src/utils/security.py](src/utils/security.py)  
- 黑名單：見 [src/utils/token_blacklist.py](src/utils/token_blacklist.py)  
- 相關路由：見 [src/api/routes/auth.py](src/api/routes/auth.py)、[src/api/controllers/auth.py](src/api/controllers/auth.py)

## 外部服務整合

- MinIO 物件儲存：路由 [src/api/routes/minio.py](src/api/routes/minio.py)，設定於 [src/config/settings.py](src/config/settings.py)  
- Client 整合請求工具：見 [src/utils/client_requests.py](src/utils/client_requests.py)  
- 伺服器健康檢查與同步：見 [src/api/services/server_service.py](src/api/services/server_service.py)、[src/api/orchestrators/server_orchestrator.py](src/api/orchestrators/server_orchestrator.py)  
- Webhook：見 [src/api/routes/webhook.py](src/api/routes/webhook.py)、[src/api/orchestrators/webhook_orchestrator.py](src/api/orchestrators/webhook_orchestrator.py)

## 報表與批次匯入

- 報表服務：見 [src/api/services/report_service.py](src/api/services/report_service.py)  
- 匯入協作：見 [src/api/orchestrators/report_import_orchestrator.py](src/api/orchestrators/report_import_orchestrator.py)  
- 設計與規格文件：  
  - [docs/report_import_technical_spec.md](docs/report_import_technical_spec.md)  
  - [docs/report_batch_import_design.md](docs/report_batch_import_design.md)

## Docker 部署

- API 映像檔範本：[Dockerfile-api](Dockerfile-api)  
- Scheduler 映像檔範本：[Dockerfile-scheduler](Dockerfile-scheduler)  
- 範例（請依實際環境調整）：
  ```bash
  # API
  docker build -f Dockerfile-api -t opsview-api .
  docker run --env-file src/config/.env.example -p 8000:8000 opsview-api

  # Scheduler
  docker build -f Dockerfile-scheduler -t opsview-scheduler .
  docker run --env-file src/config/.env.example opsview-scheduler
  ```

## CI/CD

GitLab CI 設定檔：[.gitlab-ci.yml](.gitlab-ci.yml)

## 開發規範與風格

- Python 3.8+、FastAPI、Pydantic v2  
- I/O 密集路徑採用非同步處理  
- 早返回與防衛式程式，錯誤統一以 HTTP 例外回應  
- 導入 FastAPI 依賴注入與中介軟體  

## 疑難排解

- 無法連線資料庫：確認 DATABASE_URL_* 與資料庫服務狀態。  
- JWT 驗證失敗：確認 JWT_SECRET_KEY 與時間同步。  
- MinIO 存取異常：核對憑證與 bucket 名稱。  
- Alembic 執行錯誤：確認 [src/database/migration/alembic.ini](src/database/migration/alembic.ini) 與目前 migration 版本。